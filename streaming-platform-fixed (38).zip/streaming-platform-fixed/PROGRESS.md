# Backend ↔ frontend connection — complete

Every page that previously showed mock/hardcoded data now talks to a real
backend endpoint. Nothing in the live route tree (the pages wired into
`App.tsx`) uses fabricated data anymore.

## Backend additions

- **Models** (`app/models.py`): `UserPreference`, `Notification`,
  `Download`, `Category`, `Report`, plus `plan` / `is_active` /
  `last_active_at` on `User`.
- **`app/routers/account.py`**: preferences, subscription, notifications,
  downloads, watch history — all scoped to the signed-in user.
- **`app/routers/admin.py`**: user management, categories, reports —
  all behind `require_admin`.
- **`app/routers/videos.py`**: added `POST /videos/{id}/report`.
- **`app/worker/tasks.py`**: transcoding success/failure now creates a real
  notification for the video's owner.
- **`app/migrate.py`**: best-effort column migration so your existing
  `streamverse.db` picks up the new `users` columns without losing data.
- **`app/dependencies.py`**: `get_current_user` now also enforces
  `is_active`, so an admin disabling a user actually locks them out.

## Frontend additions

- **`services/account-api.ts`**, **`services/admin-api.ts`** (new) — thin
  fetch wrappers following the same pattern as `content-api.ts`.
- **`features/account/queries.ts`** — extended with hooks for preferences,
  subscription, notifications, downloads, and history.
- **`features/admin/queries.ts`** (new) — hooks for admin users, categories,
  reports.
- **`pages/SettingsPage.tsx`** — loads real preferences via
  `GET /account/preferences`, saves via `PUT /account/preferences`.
- **`pages/UtilityPage.tsx`** — rewritten per-tab: Downloads, Watch history,
  and Notifications each load/mutate real data; Subscription persists your
  plan choice; Help remains static support copy (there's nothing to fetch
  there — it's genuinely just informational content).
- **`pages/AdminWorkspacePage.tsx`** — rewritten: Users (list + toggle
  active/disabled + change plan), Categories (create/list/delete, counts
  computed from real genre matches), Reports (list + change status), and
  Uploads (reuses the existing catalog query filtered to non-`ready`
  statuses — no separate backend model needed there).
- **`pages/TitleDetailsPage.tsx`** — added working "Download" and "Report an
  issue" buttons wired to the new endpoints.
- **`pages/AccountPage.tsx`** — the Watch history / Downloads / Privacy
  panels now link to their real pages instead of being inert buttons.

## What I could not verify in this sandbox

This environment has no network access, so I could not `pip install` the
backend dependencies or `npm install` the frontend ones to actually boot
either half and click through it. What I did do:

- Every backend `.py` file passes `python -m py_compile` (syntax-valid).
- I manually re-read every new/edited TypeScript file for type consistency
  between the API response shapes, the mapper functions, and what each
  component destructures.

Before you deploy, please run:

```
cd backend && pip install -r requirements.txt && uvicorn app.main:app --reload
cd backend/frontend && npm install && npm run dev
# and, ideally:
cd backend/frontend && npx tsc --noEmit
```

If `tsc` turns up anything, it'll almost certainly be a small type mismatch
rather than a structural issue — the endpoint shapes and the frontend
mappers were written together from the same schema.

## One more thing (carried over from before)

Your uploaded `.env` has live AWS access keys in plaintext. Worth rotating
those and keeping `.env` out of anything you share or commit.
