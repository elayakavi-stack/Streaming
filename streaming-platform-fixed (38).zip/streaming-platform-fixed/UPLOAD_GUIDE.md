# Adding your own titles

The catalog starts empty. Add every title through the authenticated upload API.

1. Start PostgreSQL, Redis, API, and worker:

   ```powershell
   docker compose up --build
   ```

2. Register, then sign in at `http://localhost:5173/login`. Copy the JWT saved as
   `access_token` in browser storage, or obtain it from `POST /auth/login`.

3. Create a title. `poster_url` and `backdrop_url` are optional public HTTPS URLs;
   upload your thumbnail/backdrop to your S3 bucket first and paste their URLs here.

   ```http
   POST /videos
   Authorization: Bearer <token>
   Content-Type: application/json

   {
     "title": "My Film",
     "description": "Your own description",
     "category": "Movie",
     "genre": "Drama",
     "rating": "U/A 13+",
     "release_year": 2026,
     "cast_members": "Name One, Name Two",
     "director": "Director Name",
     "poster_url": "https://<bucket>.s3.<region>.amazonaws.com/art/my-film-poster.jpg",
     "backdrop_url": "https://<bucket>.s3.<region>.amazonaws.com/art/my-film-backdrop.jpg",
     "filename": "my-film.mp4",
     "content_type": "video/mp4"
   }
   ```

4. The response contains `upload_url`. Upload the video bytes to that URL with an
   HTTP `PUT` and the same `Content-Type`.

5. Notify the API after the upload succeeds:

   ```http
   POST /videos/<video_id>/complete-upload
   Authorization: Bearer <token>
   ```

The Celery worker downloads the original from S3, creates 360p/720p/1080p HLS,
uploads HLS back to S3, and marks the title `ready`. Ensure the S3 bucket CORS allows
your frontend origin to `PUT` and exposes `Content-Type`.

Never commit `.env`; rotate any cloud keys that were previously committed or shared.
