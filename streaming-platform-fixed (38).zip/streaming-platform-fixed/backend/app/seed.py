"""Database bootstrap helpers.

The catalog is intentionally empty on a new installation. Titles are added by
authorized users through the upload API; no sample movies are inserted.
"""
from sqlalchemy.orm import Session

from app.models import User
from app.security import hash_password


def seed_database_if_empty(db: Session) -> None:
    """Create only the local development account required by guest-compatible APIs."""
    user = db.query(User).filter(User.email == "guest@streamverse.com").first()
    if not user:
        db.add(User(email="guest@streamverse.com", hashed_password=hash_password("guest123"), is_admin=True))
        db.commit()
