from datetime import datetime
from typing import Annotated
from uuid import UUID

from pydantic import BaseModel, BeforeValidator, Field
from app.models import VideoStatus, SubscriptionPlan, ReportStatus, LiveStreamStatus


def _stringify_uuid(value):
    """Many DB columns are UUID(as_uuid=True), so SQLAlchemy hands back real
    uuid.UUID objects. Pydantic v2 won't silently coerce those to `str`, so
    every id/`*_id` field uses this type instead of plain `str` to accept
    either a UUID object or an already-stringified id transparently."""
    return str(value) if isinstance(value, UUID) else value


UUIDStr = Annotated[str, BeforeValidator(_stringify_uuid)]


class UserCreate(BaseModel):
    email: str
    password: str = Field(min_length=8, max_length=128)


class UserOut(BaseModel):
    id: UUIDStr
    email: str
    is_admin: bool = False
    plan: SubscriptionPlan = SubscriptionPlan.essential
    can_stream: bool = False
    stream_requested_at: datetime | None = None

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class VideoCreateRequest(BaseModel):
    title: str
    description: str | None = None
    category: str | None = "Movie"
    genre: str | None = "Action"
    sub_genre: str | None = None
    rating: str | None = "U/A 16+"
    imdb_score: str | None = "8.5"
    release_year: int | None = 2024
    cast_members: str | None = None
    director: str | None = None
    poster_url: str | None = None
    backdrop_url: str | None = None
    # ISO 639 code (e.g. "te", "en") for the language of the video file's own
    # embedded audio. Most source files have no language tag ffprobe can
    # read, so without this the primary audio track shows up as "Unknown" in
    # the player's audio menu — see app/worker/transcode.py.
    original_language: str | None = None
    # Comma-separated mood tags, e.g. "Feel-good,Uplifting" — see
    # Video.moods in app/models.py.
    moods: str | None = None
    filename: str
    content_type: str = "video/mp4"


class VideoCreateResponse(BaseModel):
    video_id: UUIDStr
    upload_url: str
    upload_fields: dict | None = None
    raw_s3_key: str


class AssetUploadRequest(BaseModel):
    filename: str = Field(min_length=1, max_length=255)
    content_type: str = Field(pattern=r"^image/(jpeg|png|webp)$")
    purpose: str = Field(pattern=r"^(poster|backdrop)$")


class AssetUploadResponse(BaseModel):
    upload_url: str
    asset_url: str
    key: str


class AudioTrackOut(BaseModel):
    """One selectable audio language, detected from the source at transcode
    time. Only ever more than one entry when the upload actually had
    multiple audio streams — see app/worker/transcode.py."""
    language: str
    name: str


class SubtitleOut(BaseModel):
    id: UUIDStr
    language: str
    label: str
    url: str
    is_default: bool = False

    class Config:
        from_attributes = True


class AudioSourceOut(BaseModel):
    """A raw dub/audio-track file attached to a title — see
    app/models.py:VideoAudioSource. Queued for the transcode pipeline; only
    actually muxed into the streaming files once the video finishes
    processing (initial upload) or is reprocessed (added after the fact)."""
    id: UUIDStr
    language: str
    label: str
    is_default: bool = False

    class Config:
        from_attributes = True


class VideoOut(BaseModel):
    id: UUIDStr
    title: str
    description: str | None = None
    category: str | None = "Movie"
    genre: str | None = "Action"
    sub_genre: str | None = None
    rating: str | None = "U/A 16+"
    imdb_score: str | None = "8.5"
    release_year: int | None = 2024
    cast_members: str | None = None
    director: str | None = None
    poster_url: str | None = None
    backdrop_url: str | None = None
    original_language: str | None = None
    moods: str | None = None
    status: VideoStatus
    playback_url: str | None = None
    is_in_watchlist: bool = False
    progress_seconds: float = 0.0
    duration_seconds: float | None = None
    average_rating: float | None = None
    rating_count: int = 0
    user_rating: int | None = None
    user_review: str | None = None
    audio_tracks: list[AudioTrackOut] = []
    subtitles: list[SubtitleOut] = []
    # Raw dub files attached but not yet baked into the streaming files —
    # populated whether the title is still pending its first upload or
    # already ready/failed (see /videos/{id}/audio-tracks). Once a
    # reprocess picks them up they'll also start showing in audio_tracks.
    pending_audio_sources: list[AudioSourceOut] = []

    class Config:
        from_attributes = True


class SubtitleUploadRequest(BaseModel):
    filename: str = Field(min_length=1, max_length=255)
    content_type: str = Field(pattern=r"^(text/vtt|text/plain|application/x-subrip|application/octet-stream)$")


class SubtitleUploadResponse(BaseModel):
    upload_url: str
    subtitle_url: str
    key: str
    content_type: str


class SubtitleCreateRequest(BaseModel):
    language: str = Field(min_length=2, max_length=12)
    label: str = Field(min_length=1, max_length=60)
    url: str
    is_default: bool = False


class AudioSourceUploadRequest(BaseModel):
    filename: str = Field(min_length=1, max_length=255)
    content_type: str = "audio/mpeg"


class AudioSourceUploadResponse(BaseModel):
    upload_url: str
    key: str


class AudioSourceCreateRequest(BaseModel):
    language: str = Field(min_length=2, max_length=12)
    label: str = Field(min_length=1, max_length=60)
    raw_s3_key: str
    is_default: bool = False


class ProgressUpdate(BaseModel):
    progress_seconds: float
    duration_seconds: float | None = None


class WatchlistToggleResponse(BaseModel):
    video_id: UUIDStr
    is_in_watchlist: bool
    message: str


class ProfileCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    avatar_url: str | None = None
    is_kids: bool = False
    maturity_rating: str = "A"


class ProfileOut(ProfileCreate):
    id: UUIDStr

    class Config:
        from_attributes = True


class RatingRequest(BaseModel):
    value: int = Field(ge=1, le=5)
    review: str | None = Field(default=None, max_length=2000)


class RatingOut(BaseModel):
    video_id: UUIDStr
    value: int
    average_rating: float
    rating_count: int


class CatalogPage(BaseModel):
    items: list[VideoOut]
    total: int
    page: int
    page_size: int


class HomeRail(BaseModel):
    title: str
    key: str
    subtitle: str | None = None
    items: list[VideoOut]


# ---- Account preferences ----

class PreferencesUpdate(BaseModel):
    autoplay: bool = True
    autoplay_previews: bool = True
    data_saver: bool = False
    email_notifications: bool = True


class PreferencesOut(PreferencesUpdate):
    class Config:
        from_attributes = True


# ---- Subscription ----

class SubscriptionUpdate(BaseModel):
    plan: SubscriptionPlan


class SubscriptionOut(BaseModel):
    plan: SubscriptionPlan
    price_per_month: int
    perks: list[str]


# ---- Notifications ----

class NotificationOut(BaseModel):
    id: UUIDStr
    kind: str
    title: str
    message: str | None = None
    is_read: bool
    created_at: datetime
    video_id: UUIDStr | None = None

    class Config:
        from_attributes = True


# ---- Downloads ----

class DownloadCreate(BaseModel):
    video_id: str


class DownloadOut(BaseModel):
    id: UUIDStr
    created_at: datetime
    video: VideoOut

    class Config:
        from_attributes = True


# ---- Watch history ----

class HistoryEntryOut(BaseModel):
    video: VideoOut
    progress_seconds: float
    duration_seconds: float | None = None
    updated_at: datetime

    class Config:
        from_attributes = True


# ---- Admin: users ----

class AdminUserOut(BaseModel):
    id: UUIDStr
    email: str
    is_admin: bool
    is_active: bool
    plan: SubscriptionPlan
    can_stream: bool = False
    stream_requested_at: datetime | None = None
    created_at: datetime
    last_active_at: datetime | None = None
    titles_uploaded: int = 0

    class Config:
        from_attributes = True


class AdminUserUpdate(BaseModel):
    is_admin: bool | None = None
    is_active: bool | None = None
    plan: SubscriptionPlan | None = None
    can_stream: bool | None = None


# ---- Admin: categories ----

class CategoryCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    is_public: bool = True


class CategoryUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    is_public: bool | None = None


class CategoryOut(BaseModel):
    id: UUIDStr
    name: str
    is_public: bool
    updated_at: datetime
    title_count: int = 0

    class Config:
        from_attributes = True


# ---- Reports ----

class ReportCreate(BaseModel):
    subject: str = Field(min_length=1, max_length=200)
    message: str | None = Field(default=None, max_length=2000)
    video_id: str | None = None


class ReportUpdate(BaseModel):
    status: ReportStatus


class ReportOut(BaseModel):
    id: UUIDStr
    subject: str
    message: str | None = None
    status: ReportStatus
    created_at: datetime
    resolved_at: datetime | None = None
    video_id: UUIDStr | None = None
    video_title: str | None = None
    reporter_email: str | None = None

    class Config:
        from_attributes = True


# ---- Live streaming ----

class LiveStreamCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=2000)
    poster_url: str | None = None


class LiveStreamOut(BaseModel):
    id: UUIDStr
    title: str
    description: str | None = None
    poster_url: str | None = None
    # Whether poster_url was set by the broadcaster (at creation or via
    # PATCH .../thumbnail) rather than auto-captured from the live feed —
    # lets the frontend show "auto" vs "custom" in the thumbnail control.
    poster_is_manual: bool = False
    status: LiveStreamStatus
    hls_url: str
    dash_url: str | None = None
    owner_email: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    ended_at: datetime | None = None

    class Config:
        from_attributes = True


class LiveStreamThumbnailUpdate(BaseModel):
    poster_url: str = Field(min_length=1)


class LiveAssetUploadRequest(BaseModel):
    filename: str
    content_type: str = Field(pattern=r"^image/(jpeg|png|webp)$")


class LiveStreamIngest(BaseModel):
    """Only ever returned to the broadcaster (owner/admin) — it carries the
    RTMP server address, the WHIP endpoint for in-browser broadcasting, and
    the private stream key (e.g. for OBS's "Server" and "Stream Key"
    fields), which anyone with it could stream into."""
    id: UUIDStr
    rtmp_url: str
    whip_url: str
    stream_key: str


class StreamAccessStatus(BaseModel):
    """Whether the signed-in user can go live, and whether they have a
    pending request awaiting admin approval."""
    can_stream: bool
    stream_requested_at: datetime | None = None
