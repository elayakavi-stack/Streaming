"""S3 integration for direct browser uploads and worker processing."""
from pathlib import PurePosixPath

import boto3
from botocore.config import Config

from app.config import settings

s3_client = boto3.client(
    "s3",
    region_name=settings.aws_region,
    aws_access_key_id=settings.aws_access_key_id or None,
    aws_secret_access_key=settings.aws_secret_access_key or None,
    config=Config(signature_version="s3v4"),
)


def _safe_filename(filename: str) -> str:
    name = PurePosixPath(filename.replace("\\", "/")).name
    return "".join(char for char in name if char.isalnum() or char in {".", "-", "_"}) or "upload.mp4"


def raw_key_for(video_id: str, filename: str) -> str:
    return f"raw/{video_id}/{_safe_filename(filename)}"


def hls_prefix_for(video_id: str) -> str:
    return f"hls/{video_id}/"


def asset_key_for(purpose: str, filename: str) -> str:
    import uuid
    return f"art/{purpose}/{uuid.uuid4()}-{_safe_filename(filename)}"


def subtitle_key_for(video_id: str, filename: str) -> str:
    import uuid
    return f"subtitles/{video_id}/{uuid.uuid4()}-{_safe_filename(filename)}"


def audio_source_key_for(video_id: str, filename: str) -> str:
    """Raw (untranscoded) dub/audio-track file uploaded alongside a video —
    lives next to raw/ since it needs the same worker-side download-and-encode
    treatment, just kept in its own prefix so it's obviously not the main
    video file."""
    import uuid
    return f"raw-audio/{video_id}/{uuid.uuid4()}-{_safe_filename(filename)}"


def public_asset_url(key: str) -> str:
    if settings.cloudfront_domain:
        return f"https://{settings.cloudfront_domain}/{key}"
    return f"https://{settings.s3_bucket}.s3.{settings.aws_region}.amazonaws.com/{key}"


def presign_put(key: str, content_type: str, expires_in: int = 900) -> str:
    if not settings.s3_bucket:
        raise RuntimeError("S3_BUCKET is required for uploads")
    return s3_client.generate_presigned_url(
        "put_object",
        Params={"Bucket": settings.s3_bucket, "Key": key, "ContentType": content_type},
        ExpiresIn=expires_in,
    )
