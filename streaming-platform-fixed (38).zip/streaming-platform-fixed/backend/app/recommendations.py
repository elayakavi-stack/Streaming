"""Builds the "Recommended for you" rail: figures out which genres a user
is actually interested in from their ratings (star value + review
sentiment, see `sentiment.py`), watchlist adds, and watch history, then
surfaces unwatched titles in those genres.

This deliberately isn't collaborative filtering (recommending based on what
*similar users* liked) — with a catalog and user base this size, there
usually isn't enough overlapping rating data yet for that to beat simple
noise. Content-based, single-user genre affinity is the more reliable
signal here, and it's also the one sentiment analysis actually feeds into:
a review's sentiment only tells you something about the genres of *that*
title, not about other users.
"""
from __future__ import annotations

from collections import defaultdict

from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.models import Video, VideoRating, VideoStatus, Watchlist, WatchHistory
from app.sentiment import analyze_sentiment

# Star ratings are already an explicit, reliable interest signal, but
# reviews carry additional nuance a bare number doesn't — a 3-star "it was
# fine, nothing special" reads very differently from a 3-star "loved the
# cast but the pacing dragged". When a review is present, blend it
# half-and-half with the normalized star score rather than letting either
# one dominate.
_STAR_WEIGHT = 0.5
_TEXT_WEIGHT = 0.5

# Implicit signals count for less than an explicit rating, since adding to
# a watchlist or starting an episode doesn't necessarily mean the person
# ended up enjoying it.
_WATCHLIST_WEIGHT = 0.35
_WATCH_STARTED_WEIGHT = 0.2


def _split_genres(raw: str | None) -> list[str]:
    if not raw:
        return []
    import re
    return [p.strip() for p in re.split(r"[,/&]", raw) if p.strip()]


def _video_genres(video: Video) -> list[str]:
    """A title's full set of genre tags — main genre AND sub-genre
    combined. Every genre-affinity/matching computation below should use
    this instead of `_split_genres(video.genre)` alone: a user who rates
    an Action(main)/Crime(sub) title highly is showing interest in Crime
    too, and a candidate whose only genre match is via its sub-genre
    should still be eligible for genre-based recommendations."""
    return _split_genres(video.genre) + _split_genres(video.sub_genre)


def _split_moods(raw: str | None) -> list[str]:
    """Video.moods is stored comma-separated, e.g. 'Feel-good,Uplifting'.
    Unlike genre there's no need to also split on '/' or '&' since moods
    are picked from a fixed checkbox list on the frontend (COMMON_MOODS),
    not typed freely — so no risk of a single mood name containing a
    comma, but names like 'Tense/Thrilling' deliberately keep their slash
    intact as one tag."""
    if not raw:
        return []
    return [p.strip() for p in raw.split(",") if p.strip()]


def _normalize_stars(value: int) -> float:
    """Maps the 1-5 star scale onto the same [-1, 1] range sentiment
    scores use, so the two can be blended directly. 3 stars ("it was
    okay") sits at 0 — neutral, not mildly positive."""
    return (value - 3) / 2.0


def genre_interest_scores(db: Session, user_id: str) -> dict[str, float]:
    """Returns {genre: score}, roughly in [-1, 1] but unclamped for
    videos tagged with several genres a user has repeated signal on.
    Positive means "recommend more of this", negative means "seen enough /
    didn't land" — callers typically only care about the positive end."""
    scores: dict[str, float] = defaultdict(float)

    rated = (
        db.query(VideoRating, Video)
        .join(Video, Video.id == VideoRating.video_id)
        .filter(VideoRating.user_id == user_id)
        .all()
    )
    for rating, video in rated:
        star_score = _normalize_stars(rating.value)
        text_score = analyze_sentiment(rating.review)
        combined = star_score * _STAR_WEIGHT + text_score * _TEXT_WEIGHT if rating.review else star_score
        for genre in _video_genres(video):
            scores[genre] += combined

    watchlisted = (
        db.query(Video)
        .join(Watchlist, Watchlist.video_id == Video.id)
        .filter(Watchlist.user_id == user_id)
        .all()
    )
    for video in watchlisted:
        for genre in _video_genres(video):
            scores[genre] += _WATCHLIST_WEIGHT

    watched = (
        db.query(Video)
        .join(WatchHistory, WatchHistory.video_id == Video.id)
        .filter(WatchHistory.user_id == user_id, WatchHistory.progress_seconds > 30)
        .all()
    )
    for video in watched:
        for genre in _video_genres(video):
            scores[genre] += _WATCH_STARTED_WEIGHT

    return dict(scores)


def mood_interest_scores(db: Session, user_id: str) -> dict[str, float]:
    """Same idea as `genre_interest_scores` but for mood tags — lets
    "Recommended for you" require a mood match in addition to a genre
    match, not just genre alone, so a user who has consistently
    rated/watched dark, tense titles highly doesn't get a merely
    same-genre but tonally unrelated title (e.g. a lighthearted comedy
    that happens to share a genre tag) surfaced as a top pick."""
    scores: dict[str, float] = defaultdict(float)

    rated = (
        db.query(VideoRating, Video)
        .join(Video, Video.id == VideoRating.video_id)
        .filter(VideoRating.user_id == user_id)
        .all()
    )
    for rating, video in rated:
        star_score = _normalize_stars(rating.value)
        text_score = analyze_sentiment(rating.review)
        combined = star_score * _STAR_WEIGHT + text_score * _TEXT_WEIGHT if rating.review else star_score
        for mood in _split_moods(video.moods):
            scores[mood] += combined

    watchlisted = (
        db.query(Video)
        .join(Watchlist, Watchlist.video_id == Video.id)
        .filter(Watchlist.user_id == user_id)
        .all()
    )
    for video in watchlisted:
        for mood in _split_moods(video.moods):
            scores[mood] += _WATCHLIST_WEIGHT

    watched = (
        db.query(Video)
        .join(WatchHistory, WatchHistory.video_id == Video.id)
        .filter(WatchHistory.user_id == user_id, WatchHistory.progress_seconds > 30)
        .all()
    )
    for video in watched:
        for mood in _split_moods(video.moods):
            scores[mood] += _WATCH_STARTED_WEIGHT

    return dict(scores)


def recommend_videos(db: Session, user_id: str, limit: int = 20) -> tuple[list[Video], list[str]]:
    """Returns (videos, top_genres_used). Falls back to highest-rated
    catalog-wide when there isn't enough signal yet for this user (a new
    account, or one that hasn't rated/watchlisted/watched anything) —
    genre affinity has nothing to work with until there's at least one
    signal to learn from.

    Beyond genre, this also requires a mood match once there's enough
    mood signal to work with (see `mood_interest_scores`): a candidate
    has to land in a genre the user likes AND carry a mood tag the user
    responds well to, not genre alone. Two titles can share a genre tag
    and still feel nothing alike (a genre like "Drama" spans everything
    from a tearjerker to a courtroom thriller) — the mood requirement is
    what keeps this rail actually similar to what the user has liked,
    rather than just same-shelf."""
    scores = genre_interest_scores(db, user_id)
    liked_genres = sorted((g for g, s in scores.items() if s > 0.05), key=lambda g: scores[g], reverse=True)

    mood_scores = mood_interest_scores(db, user_id)
    liked_moods = sorted((m for m, s in mood_scores.items() if s > 0.05), key=lambda m: mood_scores[m], reverse=True)

    exclude_ids = {
        row[0]
        for row in db.query(VideoRating.video_id).filter(VideoRating.user_id == user_id).all()
    } | {
        row[0]
        for row in db.query(WatchHistory.video_id)
        .filter(WatchHistory.user_id == user_id, WatchHistory.progress_seconds > 30)
        .all()
    }

    if liked_genres:
        top_genres = liked_genres[:5]
        top_moods = liked_moods[:5]
        query = db.query(Video).filter(Video.status == VideoStatus.ready)
        if exclude_ids:
            query = query.filter(~Video.id.in_(exclude_ids))
        genre_filter = None
        for genre in top_genres:
            # Match a liked genre against BOTH a candidate's main genre and
            # its sub-genre, so a title that's only a Crime *sub*-genre
            # match (main genre Action, say) is still eligible.
            clause = or_(Video.genre.ilike(f"%{genre}%"), Video.sub_genre.ilike(f"%{genre}%"))
            genre_filter = clause if genre_filter is None else (genre_filter | clause)
        if genre_filter is not None:
            query = query.filter(genre_filter)
        if top_moods:
            mood_filter = None
            for mood in top_moods:
                clause = Video.moods.ilike(f"%{mood}%")
                mood_filter = clause if mood_filter is None else (mood_filter | clause)
            query = query.filter(mood_filter)
        candidates = query.order_by(Video.created_at.desc()).limit(200).all()

        def rank(video: Video) -> float:
            video_genres = _video_genres(video)
            video_moods = _split_moods(video.moods)
            return sum(scores.get(g, 0) for g in video_genres) + sum(mood_scores.get(m, 0) for m in video_moods)

        candidates.sort(key=rank, reverse=True)

        if not candidates and top_moods:
            # The AND of genre + mood came up empty (can happen with a
            # sparse catalog) — relax back to genre-only rather than
            # showing nothing, since genre is still a real, explicit
            # signal on its own.
            query = db.query(Video).filter(Video.status == VideoStatus.ready)
            if exclude_ids:
                query = query.filter(~Video.id.in_(exclude_ids))
            query = query.filter(genre_filter)
            candidates = query.order_by(Video.created_at.desc()).limit(200).all()
            candidates.sort(key=rank, reverse=True)

        # Deliberately no catalog-wide top-up here: this rail is meant to
        # only ever show titles that actually match a genre (and, where
        # there's mood signal, a mood) the user has shown interest in. If
        # there aren't `limit` of those yet, the rail is just shorter —
        # better than padding it with unrelated popular titles that have
        # nothing to do with the user's taste.
        return candidates[:limit], top_genres

    # Cold start: no rating/watchlist/watch-history signal at all yet.
    query = db.query(Video, func.avg(VideoRating.value).label("avg_rating")).outerjoin(
        VideoRating, VideoRating.video_id == Video.id
    ).filter(Video.status == VideoStatus.ready)
    if exclude_ids:
        query = query.filter(~Video.id.in_(exclude_ids))
    popular = (
        query.group_by(Video.id)
        .order_by(func.avg(VideoRating.value).desc().nullslast(), Video.created_at.desc())
        .limit(limit)
        .all()
    )
    return [v for v, _ in popular], []


def similar_mood_videos(db: Session, video: Video, limit: int = 12) -> list[Video]:
    """"More like this mood" — other ready titles that strictly share
    BOTH the mood and the genre of `video`, not just one or the other.
    An OR match (either mood or genre) let a completely different-genre
    title onto the rail just because it happened to share one mood tag,
    or a wildly different-tone title on just because it shared a genre —
    neither reads as "more like this mood" to a viewer. Candidates now
    have to overlap on at least one mood tag AND at least one genre tag
    to even be considered, and are ranked by mood overlap first, genre
    overlap second, IMDb score last as a tiebreaker. (If the playing
    title itself has no moods or no genre set, that half of the
    requirement is dropped since there's nothing to strictly match on —
    but for titles with both set, both must match.) Meant for the player
    page (a rail shown alongside/after the title currently playing),
    which is a different use case from the home-page "Recommended for
    you" rail: that one is about a user's overall taste, this one is
    about what this *specific* title feels like, regardless of who's
    watching."""
    moods = set(_split_moods(video.moods))
    genres = set(_video_genres(video))
    if not moods and not genres:
        return []

    query = db.query(Video).filter(Video.status == VideoStatus.ready, Video.id != video.id)
    if moods:
        mood_filter = None
        for mood in moods:
            clause = Video.moods.ilike(f"%{mood}%")
            mood_filter = clause if mood_filter is None else (mood_filter | clause)
        query = query.filter(mood_filter)
    if genres:
        genre_filter = None
        for genre in genres:
            clause = or_(Video.genre.ilike(f"%{genre}%"), Video.sub_genre.ilike(f"%{genre}%"))
            genre_filter = clause if genre_filter is None else (genre_filter | clause)
        query = query.filter(genre_filter)

    candidates = query.order_by(Video.created_at.desc()).limit(200).all()

    def overlap(candidate: Video) -> tuple[int, int, float]:
        candidate_moods = set(_split_moods(candidate.moods))
        candidate_genres = set(_video_genres(candidate))
        try:
            score = float(candidate.imdb_score) if candidate.imdb_score else 0.0
        except (TypeError, ValueError):
            score = 0.0
        return (len(moods & candidate_moods), len(genres & candidate_genres), score)

    # Strict AND: with both moods and genres set on the playing title, a
    # candidate must actually overlap on both (the ilike filters above
    # only guarantee an OR at the SQL level since ilike can't express
    # "this row matches every clause independently" cleanly — this is
    # the real strict check).
    def passes(candidate: Video) -> bool:
        mood_hit, genre_hit, _ = overlap(candidate)
        if moods and genres:
            return mood_hit > 0 and genre_hit > 0
        if moods:
            return mood_hit > 0
        return genre_hit > 0

    candidates = [c for c in candidates if passes(c)]
    candidates.sort(key=overlap, reverse=True)
    return candidates[:limit]


def _split_people(raw: str | None) -> list[str]:
    """Video.cast_members and Video.director are stored comma-separated,
    e.g. 'Name One, Name Two'."""
    if not raw:
        return []
    return [p.strip() for p in raw.split(",") if p.strip()]


def because_you_watched_videos(db: Session, video: Video, limit: int = 12) -> list[Video]:
    """"Because you watched X" — other ready titles led by the same
    director or sharing a cast member with `video`, i.e. "same hero" or
    "same director" picks a viewer would actually recognize as related.
    Deliberately cast/director only, with no genre fallback: a genre
    fallback is what made this rail indistinguishable from "More like
    this mood" / generic recommendations before — a viewer who watched a
    specific actor's film expects this rail to be about that actor (or
    the director), not "well, it's also an action movie". If a title has
    no cast/director credits on file, or nothing else in the catalog
    shares one, the rail is simply empty rather than padded out with
    unrelated genre matches."""
    cast = set(_split_people(video.cast_members))
    director = (video.director or "").strip()

    if not cast and not director:
        return []

    people_filter = None
    for name in cast:
        clause = Video.cast_members.ilike(f"%{name}%")
        people_filter = clause if people_filter is None else (people_filter | clause)
    if director:
        clause = Video.director.ilike(f"%{director}%")
        people_filter = clause if people_filter is None else (people_filter | clause)

    def score(candidate: Video) -> tuple[int, int, float]:
        candidate_cast = set(_split_people(candidate.cast_members))
        same_director = 1 if director and candidate.director and director.lower() == candidate.director.strip().lower() else 0
        try:
            imdb = float(candidate.imdb_score) if candidate.imdb_score else 0.0
        except (TypeError, ValueError):
            imdb = 0.0
        return (same_director, len(cast & candidate_cast), imdb)

    candidates = (
        db.query(Video)
        .filter(Video.status == VideoStatus.ready, Video.id != video.id, people_filter)
        .order_by(Video.created_at.desc())
        .limit(200)
        .all()
    )
    candidates = [c for c in candidates if score(c)[0] > 0 or score(c)[1] > 0]
    candidates.sort(key=score, reverse=True)
    return candidates[:limit]


def recent_mood_recommendations(db: Session, user_id: str, limit: int = 20, lookback: int = 15) -> tuple[list[Video], list[str]]:
    """Returns (videos, top_moods_used) for a home rail built from the
    moods of the last `lookback` titles this user actually watched into
    (WatchHistory, most recent first) — distinct from `recommend_videos`'s
    genre-affinity rail, which weighs *all* historical signal (ratings,
    watchlist, watch history) evenly rather than leaning on what's recent.
    A user who's been on a comfort-watch kick this week should see that
    reflected quickly, not diluted by months of unrelated history."""
    recent_history = (
        db.query(WatchHistory, Video)
        .join(Video, Video.id == WatchHistory.video_id)
        .filter(WatchHistory.user_id == user_id, WatchHistory.progress_seconds > 30)
        .order_by(WatchHistory.updated_at.desc())
        .limit(lookback)
        .all()
    )

    mood_counts: dict[str, int] = defaultdict(int)
    watched_ids = set()
    for _history, video in recent_history:
        watched_ids.add(video.id)
        for mood in _split_moods(video.moods):
            mood_counts[mood] += 1

    if not mood_counts:
        return [], []

    top_moods = sorted(mood_counts, key=lambda m: mood_counts[m], reverse=True)[:3]

    mood_filter = None
    for mood in top_moods:
        clause = Video.moods.ilike(f"%{mood}%")
        mood_filter = clause if mood_filter is None else (mood_filter | clause)

    candidates = (
        db.query(Video)
        .filter(Video.status == VideoStatus.ready, ~Video.id.in_(watched_ids), mood_filter)
        .order_by(Video.created_at.desc())
        .limit(200)
        .all()
    )

    def rank(candidate: Video) -> int:
        candidate_moods = _split_moods(candidate.moods)
        return sum(mood_counts.get(m, 0) for m in candidate_moods)

    candidates.sort(key=rank, reverse=True)
    return candidates[:limit], top_moods
