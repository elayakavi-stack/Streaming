"""Self-hosted RTMP live streaming, via MediaMTX.

Live broadcasting works differently from the VOD upload path (see s3.py /
cdn.py / worker/transcode.py): there's no finished file to transcode, just a
continuous feed. Here the broadcaster publishes with RTMP-capable software
(OBS Studio, ffmpeg, Streamlabs, ...) straight to a self-hosted MediaMTX
server, MediaMTX re-publishes that feed as an HLS manifest, and viewers watch
it with the same hls.js player already used for on-demand titles.

MediaMTX runs alongside the API as the "rtmp" service in docker-compose (see
mediamtx.yml). Each stream gets a random per-broadcast "stream key" that
becomes both the RTMP publish path (rtmp://<host>:1935/live/<key>) and the
HLS path (<hls_base_url>/live/<key>/index.m3u8) — knowing the key is what
lets someone publish, so it's only ever handed to the stream's owner (see
LiveStreamIngest in app/schemas.py). There's no external account or API
token required, unlike the Cloudflare Stream integration this replaced.
"""
from __future__ import annotations

import secrets

import httpx

from app.config import settings


class RtmpStreamError(RuntimeError):
    pass


def generate_stream_key() -> str:
    """A random per-broadcast path segment. Functions like a password —
    anyone who has it can publish to that RTMP path — so it's generated
    server-side rather than chosen by the broadcaster."""
    return secrets.token_hex(16)


def build_ingest_urls(stream_key: str) -> dict:
    """The RTMP server address (paired with the stream key in broadcasting
    software like OBS: "Server" and "Stream Key" fields), the WHIP endpoint
    for in-browser camera broadcasting (see BroadcastCamera in the
    frontend — publishes over WebRTC instead of RTMP, since browsers can't
    open a raw RTMP socket), and the public HLS playback URL. Both RTMP and
    WHIP publish to the same "live/<stream_key>" path in MediaMTX, so either
    one fires the same runOnReady/runOnNotReady hooks in routers/live.py."""
    rtmp_url = f"rtmp://{settings.rtmp_ingest_host}:{settings.rtmp_ingest_port}/live"
    whip_url = f"{settings.webrtc_base_url.rstrip('/')}/live/{stream_key}/whip"
    hls_url = f"{settings.hls_base_url.rstrip('/')}/live/{stream_key}/index.m3u8"
    return {"rtmp_url": rtmp_url, "whip_url": whip_url, "hls_url": hls_url}


def get_stream_status(stream_key: str) -> str | None:
    """Ask MediaMTX's control API whether this path currently has an active
    publisher. Returns 'connected' / 'disconnected', or None if the status
    can't be determined right now (e.g. MediaMTX unreachable) — callers
    should treat that as "unknown", not "disconnected".

    This is a fallback/manual-check path; day-to-day status changes are
    driven by the runOnReady/runOnNotReady webhooks in routers/live.py.
    """
    try:
        response = httpx.get(
            f"{settings.mediamtx_api_url.rstrip('/')}/v3/paths/get/live/{stream_key}",
            timeout=5,
        )
        if response.status_code == 404:
            return "disconnected"
        response.raise_for_status()
        result = response.json()
        return "connected" if result.get("ready") else "disconnected"
    except httpx.HTTPError:
        return None


def kick_stream(stream_key: str) -> None:
    """Best-effort teardown, called when a broadcast ends — forcibly
    disconnects the publisher (if any), whether it came in over RTMP (OBS/
    ffmpeg) or WHIP (in-browser camera broadcasting), so a stale session
    can't keep publishing to a path the platform now considers ended. Safe
    to call even if nobody is currently publishing, since callers shouldn't
    fail an already-successful 'end stream' action over cleanup.
    """
    path = f"live/{stream_key}"
    base = settings.mediamtx_api_url.rstrip("/")
    for kind in ("rtmpconns", "webrtcsessions"):
        try:
            response = httpx.get(f"{base}/v3/{kind}/list", timeout=5)
            response.raise_for_status()
            for item in response.json().get("items", []):
                if item.get("path") == path:
                    httpx.post(f"{base}/v3/{kind}/kick/{item['id']}", timeout=5)
        except httpx.HTTPError:
            pass
