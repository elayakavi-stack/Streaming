import enum
import uuid

from sqlalchemy import (
    Column,
    String,
    DateTime,
    Enum,
    ForeignKey,
    func,
    Float,
    Integer,
    Boolean,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from app.database import Base


class VideoStatus(str, enum.Enum):
    pending_upload = "pending_upload"
    processing = "processing"
    ready = "ready"
    failed = "failed"


class SubscriptionPlan(str, enum.Enum):
    essential = "essential"
    premium = "premium"
    ultimate = "ultimate"


class ReportStatus(str, enum.Enum):
    open = "open"
    in_review = "in_review"
    resolved = "resolved"


class LiveStreamStatus(str, enum.Enum):
    idle = "idle"      # created, broadcaster hasn't started publishing yet
    live = "live"       # currently broadcasting
    ended = "ended"      # broadcast finished


def gen_uuid():
    return uuid.uuid4()


class User(Base):
    __tablename__ = "users"

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=gen_uuid
    )

    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)

    is_admin = Column(
        Boolean,
        default=False,
        nullable=False
    )

    plan = Column(
        Enum(SubscriptionPlan),
        default=SubscriptionPlan.essential,
        nullable=False
    )

    is_active = Column(
        Boolean,
        default=True,
        nullable=False
    )

    # Live-streaming permission. Regular users can't create a broadcast
    # until an admin flips this on (via PATCH /admin/users/{id}); admins
    # can always stream regardless of this flag. See require_streamer.
    can_stream = Column(
        Boolean,
        default=False,
        nullable=False
    )

    # Set when a user asks for streaming access (POST /live/request-access),
    # cleared when an admin approves them. Lets the admin console show a
    # "pending" badge without a separate requests table.
    stream_requested_at = Column(
        DateTime(timezone=True),
        nullable=True
    )

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )

    last_active_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )

    videos = relationship(
        "Video",
        back_populates="owner"
    )

    watchlist_items = relationship(
        "Watchlist",
        back_populates="user",
        cascade="all, delete-orphan"
    )

    watch_history = relationship(
        "WatchHistory",
        back_populates="user",
        cascade="all, delete-orphan"
    )

    profiles = relationship(
        "Profile",
        back_populates="user",
        cascade="all, delete-orphan"
    )

    ratings = relationship(
        "VideoRating",
        back_populates="user",
        cascade="all, delete-orphan"
    )

    preference = relationship(
        "UserPreference",
        back_populates="user",
        uselist=False,
        cascade="all, delete-orphan"
    )

    notifications = relationship(
        "Notification",
        back_populates="user",
        cascade="all, delete-orphan"
    )

    downloads = relationship(
        "Download",
        back_populates="user",
        cascade="all, delete-orphan"
    )


class Video(Base):
    __tablename__ = "videos"

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=gen_uuid
    )

    owner_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )

    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)

    category = Column(String, default="Movie")
    genre = Column(String, default="Action")

    # Optional secondary genre tag ("main genre" stays in `genre` above).
    # Kept separate from `genre` rather than appended into one comma string
    # so home-page rails can group strictly by main genre without a title's
    # sub-genre pulling it into a second, duplicate rail.
    sub_genre = Column(String, nullable=True)
    rating = Column(String, default="U/A 16+")

    # Comma-separated emotional/mood tags (e.g. "Feel-good,Uplifting"),
    # distinct from genre/sub_genre which describe subject matter rather
    # than how a title feels to watch. Powers mood-based recommendations —
    # see app/recommendations.py — both "more like this mood" while
    # watching and a home rail built from the moods in recent watch
    # history. Kept as a small fixed vocabulary (COMMON_MOODS on the
    # frontend) rather than free text so it stays usable for grouping/
    # ranking instead of fragmenting into near-duplicate tags.
    moods = Column(String, nullable=True)

    imdb_score = Column(String, default="8.5")

    release_year = Column(Integer, default=2024)

    cast_members = Column(String)
    director = Column(String)

    poster_url = Column(String)
    backdrop_url = Column(String)

    raw_s3_key = Column(
        String,
        nullable=False
    )

    hls_prefix = Column(String)

    status = Column(
        Enum(VideoStatus),
        default=VideoStatus.pending_upload,
        nullable=False
    )

    duration_seconds = Column(String)

    # JSON-encoded list of {index, language, name} — only populated when the
    # source had more than one audio stream (e.g. an English + Hindi dub);
    # see app/worker/transcode.py. Null/empty means "single audio track",
    # which is the common case and needs no language switcher in the player.
    audio_tracks_json = Column(Text, nullable=True)

    # ISO 639 code (e.g. "te", "en") for the language of the video's own
    # embedded audio track, set explicitly at upload time. Most source files
    # carry no `language` tag in their container metadata at all, so ffprobe
    # has nothing to detect — without this, the primary track falls back to
    # "und"/"Unknown" in the player's audio menu (see
    # app/worker/transcode.py:probe_audio_streams). Null means the uploader
    # didn't set one, so the pipeline still falls back to whatever (if
    # anything) ffprobe finds embedded in the file.
    original_language = Column(String, nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )


    owner = relationship(
        "User",
        back_populates="videos"
    )

    watchlist_entries = relationship(
        "Watchlist",
        back_populates="video",
        cascade="all, delete-orphan"
    )

    history_entries = relationship(
        "WatchHistory",
        back_populates="video",
        cascade="all, delete-orphan"
    )

    subtitles = relationship(
        "VideoSubtitle",
        back_populates="video",
        cascade="all, delete-orphan",
        order_by="VideoSubtitle.label"
    )

    audio_sources = relationship(
        "VideoAudioSource",
        back_populates="video",
        cascade="all, delete-orphan",
        order_by="VideoAudioSource.label"
    )


class VideoAudioSource(Base):
    """A raw (untranscoded) dub/audio-track file attached to a video before
    processing — e.g. a separate Hindi audio file for an otherwise
    English-only upload. The transcode pipeline downloads each of these and
    encodes them into their own audio-only HLS rendition alongside the
    video's own embedded audio, then references all of them from the master
    playlist as selectable EXT-X-MEDIA tracks. Only meaningful before the
    video finishes processing — added via presign+create the same way a raw
    video upload is, just scoped under the video that isn't queued yet."""
    __tablename__ = "video_audio_sources"

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=gen_uuid
    )

    video_id = Column(
        UUID(as_uuid=True),
        ForeignKey("videos.id"),
        nullable=False
    )

    language = Column(String, nullable=False)
    label = Column(String, nullable=False)
    raw_s3_key = Column(String, nullable=False)

    is_default = Column(
        Boolean,
        default=False,
        nullable=False
    )

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )

    video = relationship(
        "Video",
        back_populates="audio_sources"
    )


class VideoSubtitle(Base):
    """A single caption/subtitle track (WebVTT) attached to a video. Kept as
    its own table rather than a JSON column on Video since a title can have
    any number of languages, each added/removed independently."""
    __tablename__ = "video_subtitles"

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=gen_uuid
    )

    video_id = Column(
        UUID(as_uuid=True),
        ForeignKey("videos.id"),
        nullable=False
    )

    language = Column(String, nullable=False)
    label = Column(String, nullable=False)
    url = Column(String, nullable=False)

    is_default = Column(
        Boolean,
        default=False,
        nullable=False
    )

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )

    video = relationship(
        "Video",
        back_populates="subtitles"
    )


class Watchlist(Base):
    __tablename__ = "watchlist"


    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=gen_uuid
    )


    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )


    video_id = Column(
        UUID(as_uuid=True),
        ForeignKey("videos.id"),
        nullable=False
    )


    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )


    user = relationship(
        "User",
        back_populates="watchlist_items"
    )


    video = relationship(
        "Video",
        back_populates="watchlist_entries"
    )



class WatchHistory(Base):
    __tablename__ = "watch_history"


    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=gen_uuid
    )


    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )


    video_id = Column(
        UUID(as_uuid=True),
        ForeignKey("videos.id"),
        nullable=False
    )


    progress_seconds = Column(
        Float,
        default=0.0
    )


    duration_seconds = Column(
        Float,
        default=0.0
    )


    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )


    user = relationship(
        "User",
        back_populates="watch_history"
    )


    video = relationship(
        "Video",
        back_populates="history_entries"
    )



class Profile(Base):
    __tablename__ = "profiles"


    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=gen_uuid
    )


    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False,
        index=True
    )


    name = Column(
        String(80),
        nullable=False
    )


    avatar_url = Column(String)


    is_kids = Column(
        Boolean,
        default=False
    )


    maturity_rating = Column(
        String(20),
        default="A"
    )


    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )


    user = relationship(
        "User",
        back_populates="profiles"
    )



class VideoRating(Base):
    __tablename__ = "video_ratings"


    __table_args__ = (
        UniqueConstraint(
            "user_id",
            "video_id",
            name="uq_video_rating_user_video"
        ),
    )


    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=gen_uuid
    )


    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False,
        index=True
    )


    video_id = Column(
        UUID(as_uuid=True),
        ForeignKey("videos.id"),
        nullable=False,
        index=True
    )


    value = Column(
        Integer,
        nullable=False
    )


    review = Column(Text)


    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )


    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )


    user = relationship(
        "User",
        back_populates="ratings"
    )


class UserPreference(Base):
    __tablename__ = "user_preferences"

    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        primary_key=True
    )

    autoplay = Column(Boolean, default=True, nullable=False)
    autoplay_previews = Column(Boolean, default=True, nullable=False)
    data_saver = Column(Boolean, default=False, nullable=False)
    email_notifications = Column(Boolean, default=True, nullable=False)

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )

    user = relationship("User", back_populates="preference")


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(UUID(as_uuid=True), primary_key=True, default=gen_uuid)

    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False,
        index=True
    )

    video_id = Column(
        UUID(as_uuid=True),
        ForeignKey("videos.id"),
        nullable=True
    )

    kind = Column(String, default="info", nullable=False)
    title = Column(String, nullable=False)
    message = Column(Text, nullable=True)
    is_read = Column(Boolean, default=False, nullable=False)

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )

    user = relationship("User", back_populates="notifications")


class Download(Base):
    __tablename__ = "downloads"

    __table_args__ = (
        UniqueConstraint("user_id", "video_id", name="uq_download_user_video"),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=gen_uuid)

    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False,
        index=True
    )

    video_id = Column(
        UUID(as_uuid=True),
        ForeignKey("videos.id"),
        nullable=False
    )

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )

    user = relationship("User", back_populates="downloads")
    video = relationship("Video")


class Category(Base):
    __tablename__ = "categories"

    id = Column(UUID(as_uuid=True), primary_key=True, default=gen_uuid)

    name = Column(String(120), unique=True, nullable=False)
    is_public = Column(Boolean, default=True, nullable=False)

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )


class Report(Base):
    __tablename__ = "reports"

    id = Column(UUID(as_uuid=True), primary_key=True, default=gen_uuid)

    reporter_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )

    video_id = Column(
        UUID(as_uuid=True),
        ForeignKey("videos.id"),
        nullable=True
    )

    subject = Column(String(200), nullable=False)
    message = Column(Text, nullable=True)

    status = Column(
        Enum(ReportStatus),
        default=ReportStatus.open,
        nullable=False
    )

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now()
    )

    resolved_at = Column(DateTime(timezone=True), nullable=True)

    reporter = relationship("User")
    video = relationship("Video")


class LiveStream(Base):
    __tablename__ = "live_streams"

    id = Column(UUID(as_uuid=True), primary_key=True, default=gen_uuid)

    owner_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False,
        index=True,
    )

    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    poster_url = Column(String)
    # False once a frame has been auto-captured from the live feed (see
    # app/worker/tasks.py:capture_live_thumbnail) or the broadcaster never
    # set one at all — in either case the auto-capture job is free to keep
    # refreshing poster_url on its own. True as soon as the broadcaster sets
    # one themselves (at creation or via PATCH /live/{id}/thumbnail), which
    # permanently stops auto-capture from overwriting their choice.
    poster_is_manual = Column(Boolean, nullable=False, default=False)

    status = Column(
        Enum(LiveStreamStatus),
        default=LiveStreamStatus.idle,
        nullable=False,
        index=True,
    )

    # Self-hosted RTMP ingest backing this broadcast (see app/rtmp_stream.py).
    # stream_key is the private per-broadcast RTMP path segment — paired with
    # the public RTMP server address and only ever returned to the owner/admin;
    # hls_url is the public playback manifest, served by MediaMTX.
    stream_key = Column(String, nullable=False)
    hls_url = Column(String, nullable=False)
    dash_url = Column(String)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    started_at = Column(DateTime(timezone=True), nullable=True)
    ended_at = Column(DateTime(timezone=True), nullable=True)

    owner = relationship("User")