"""Lightweight sentiment analysis for review text, used to power
recommendations (see `recommendations.py`).

Deliberately lexicon-based rather than a trained model: it needs no extra
service, no model download/weights, and no GPU/CPU-heavy inference for what
is ultimately a small amount of short review text per user. A curated
positive/negative word list with simple negation and intensifier handling
gets a reasonable directional signal ("really loved this" vs "didn't like
it") without the operational cost of something like a transformer-based
classifier — which would be overkill for nudging a recommendation rail.
"""
from __future__ import annotations

import re

_POSITIVE_WORDS = {
    "love", "loved", "loves", "amazing", "excellent", "great", "good",
    "fantastic", "brilliant", "wonderful", "awesome", "incredible",
    "perfect", "masterpiece", "beautiful", "enjoyed", "enjoyable", "fun",
    "gripping", "captivating", "compelling", "thrilling", "moving",
    "outstanding", "superb", "favorite", "favourite", "best", "recommend",
    "recommended", "solid", "impressive", "hilarious", "heartwarming",
    "satisfying", "engaging", "beautifully", "well-acted", "well", "top",
    "stunning", "phenomenal", "delightful", "charming", "riveting",
}

_NEGATIVE_WORDS = {
    "hate", "hated", "hates", "awful", "terrible", "bad", "boring", "dull",
    "poor", "disappointing", "disappointed", "waste", "worst", "mediocre",
    "bland", "flat", "confusing", "annoying", "cringe", "cliche",
    "overrated", "forgettable", "predictable", "slow", "weak", "messy",
    "unwatchable", "painful", "poorly", "unconvincing", "flop", "dreadful",
    "lame", "stale", "underwhelming",
}

_NEGATIONS = {"not", "no", "never", "n't", "isn't", "wasn't", "didn't", "doesn't", "don't", "hardly", "barely"}
_INTENSIFIERS = {"very", "really", "extremely", "so", "incredibly", "absolutely", "truly"}

_WORD_RE = re.compile(r"[a-z']+")


def analyze_sentiment(text: str | None) -> float:
    """Returns a score in [-1, 1]: negative is unfavorable, positive is
    favorable, 0 is neutral/no signal (including empty/missing text).

    Simple bag-of-words scan with a one-token lookback: a negation flips the
    following sentiment word's polarity, an intensifier scales it up. This
    is intentionally naive (no real parsing, no sarcasm handling) — it's
    tuned for "good enough directional signal from a two-sentence review",
    not general-purpose NLP accuracy.
    """
    if not text:
        return 0.0
    words = _WORD_RE.findall(text.lower())
    if not words:
        return 0.0

    score = 0.0
    hits = 0
    negate_next = False
    intensify_next = False
    for word in words:
        if word in _NEGATIONS:
            negate_next = True
            continue
        if word in _INTENSIFIERS:
            intensify_next = True
            continue

        polarity = 1 if word in _POSITIVE_WORDS else -1 if word in _NEGATIVE_WORDS else 0
        if polarity:
            magnitude = 1.5 if intensify_next else 1.0
            score += -polarity * magnitude if negate_next else polarity * magnitude
            hits += 1
        negate_next = False
        intensify_next = False

    if not hits:
        return 0.0
    # Normalize by hits (not word count) so a short, clearly-worded review
    # doesn't score weaker than a long, mostly-neutral one, then clamp.
    return max(-1.0, min(1.0, score / hits))
