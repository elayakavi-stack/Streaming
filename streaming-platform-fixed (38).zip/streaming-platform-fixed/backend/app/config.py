from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "postgresql://streaming:streaming@localhost:5432/streaming"
    redis_url: str = "redis://localhost:6379/0"

    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60

    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_region: str = "us-east-1"
    s3_bucket: str = "my-streaming-platform"

    cloudfront_domain: str = ""
    cloudfront_key_pair_id: str = ""
    cloudfront_private_key_path: str = ""

    # Live streaming: self-hosted RTMP ingest (OBS/ffmpeg/any RTMP-capable
    # broadcaster) -> HLS playback, served by MediaMTX. See app/rtmp_stream.py.
    # rtmp_ingest_host/port are what's handed to the broadcaster as the
    # "server" address; hls_base_url is the public HLS origin; webrtc_base_url
    # is MediaMTX's WHIP endpoint, used for in-browser camera broadcasting
    # (no external software) — see BroadcastCamera in the frontend;
    # mediamtx_api_url is MediaMTX's internal control API (status checks,
    # kicking publishers); rtmp_hook_secret authenticates MediaMTX's
    # runOnReady/runOnNotReady webhook calls back into this API.
    rtmp_ingest_host: str = "localhost"
    rtmp_ingest_port: int = 1935
    hls_base_url: str = "http://localhost:8888"
    webrtc_base_url: str = "http://localhost:8889"
    mediamtx_api_url: str = "http://localhost:9997"
    rtmp_hook_secret: str = "change-me"

    class Config:
        env_file = ".env"


settings = Settings()
