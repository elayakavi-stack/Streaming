import json
import os
import subprocess
import tempfile

from app.config import settings
from app.s3 import s3_client

# Each rendition: (name, output width, output height, video bitrate, audio bitrate)
RENDITIONS = [
    ("360p", 640, 360, "800k", "96k"),
    ("720p", 1280, 720, "2800k", "128k"),
    ("1080p", 1920, 1080, "5000k", "192k"),
]

# ISO 639-1/639-2 language codes we know a friendly display name for. Any
# other tag (or a track with no language tag at all) just falls back to
# "Audio Track N" so an unrecognized tag never breaks the pipeline.
LANGUAGE_NAMES = {
    "eng": "English", "en": "English",
    "hin": "Hindi", "hi": "Hindi",
    "tam": "Tamil", "ta": "Tamil",
    "tel": "Telugu", "te": "Telugu",
    "kan": "Kannada", "kn": "Kannada",
    "mal": "Malayalam", "ml": "Malayalam",
    "spa": "Spanish", "es": "Spanish",
    "fra": "French", "fre": "French", "fr": "French",
    "deu": "German", "ger": "German", "de": "German",
    "jpn": "Japanese", "ja": "Japanese",
    "kor": "Korean", "ko": "Korean",
    "zho": "Chinese", "chi": "Chinese", "zh": "Chinese",
    "ara": "Arabic", "ar": "Arabic",
    "por": "Portuguese", "pt": "Portuguese",
    "rus": "Russian", "ru": "Russian",
    "und": "Unknown",
}

MASTER_PLAYLIST_HEADER = "#EXTM3U\n#EXT-X-VERSION:3\n"


def _display_name_for(lang_code: str) -> str:
    lang_code = (lang_code or "").lower() or "und"
    return LANGUAGE_NAMES.get(lang_code, lang_code.upper() if lang_code != "und" else "Unknown")


def download_raw(raw_s3_key: str, dest_path: str) -> None:
    s3_client.download_file(settings.s3_bucket, raw_s3_key, dest_path)


def probe_audio_streams(source_path: str) -> list[dict]:
    """Return one entry per audio stream in the source: {index, language, name}.

    `index` is the 0-based position *among audio streams* (suitable for
    ffmpeg's `-map 0:a:N`), not the absolute stream index in the container.
    """
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index:stream_tags=language", "-of", "json", source_path],
            check=True, capture_output=True, text=True,
        )
        streams = json.loads(result.stdout).get("streams", [])
    except (subprocess.CalledProcessError, json.JSONDecodeError):
        streams = []

    tracks = []
    seen_names: dict[str, int] = {}
    for position, stream in enumerate(streams):
        lang_code = (stream.get("tags", {}) or {}).get("language", "").lower() or "und"
        name = _display_name_for(lang_code)
        # Two tracks tagged with the same language (rare, but not impossible)
        # still need distinct display names in the player's menu.
        if name in seen_names:
            seen_names[name] += 1
            display_name = f"{name} {seen_names[name]}"
        else:
            seen_names[name] = 1
            display_name = name
        tracks.append({"index": position, "language": lang_code, "name": display_name})
    return tracks


def _encode_video_rendition(source_path: str, rendition_dir: str, height: int, v_bitrate: str, mux_audio: bool, a_bitrate: str) -> None:
    os.makedirs(rendition_dir, exist_ok=True)
    playlist_path = os.path.join(rendition_dir, "index.m3u8")
    cmd = ["ffmpeg", "-y", "-i", source_path, "-map", "0:v:0"]
    if mux_audio:
        cmd += ["-map", "0:a:0?", "-c:a", "aac", "-b:a", a_bitrate, "-ac", "2"]
    else:
        cmd += ["-an"]
    cmd += [
        "-vf", f"scale=-2:{height}", "-pix_fmt", "yuv420p",
        "-c:v", "libx264", "-profile:v", "main", "-crf", "20",
        "-b:v", v_bitrate, "-maxrate", v_bitrate, "-bufsize", str(int(v_bitrate[:-1]) * 2) + "k",
        "-f", "hls", "-hls_time", "6", "-hls_playlist_type", "vod",
        "-hls_segment_filename", os.path.join(rendition_dir, "seg_%03d.ts"),
        playlist_path,
    ]
    subprocess.run(cmd, check=True, capture_output=True)


def _encode_audio_rendition(source_path: str, rendition_dir: str, stream_index: int, a_bitrate: str) -> None:
    os.makedirs(rendition_dir, exist_ok=True)
    playlist_path = os.path.join(rendition_dir, "index.m3u8")
    cmd = [
        "ffmpeg", "-y", "-i", source_path,
        "-map", f"0:a:{stream_index}",
        "-c:a", "aac", "-b:a", a_bitrate, "-ac", "2",
        "-f", "hls", "-hls_time", "6", "-hls_playlist_type", "vod",
        "-hls_segment_filename", os.path.join(rendition_dir, "seg_%03d.ts"),
        playlist_path,
    ]
    subprocess.run(cmd, check=True, capture_output=True)


def transcode_to_hls(source_path: str, output_dir: str, extra_audio_tracks: list[dict] | None = None, original_language: str | None = None):
    """Runs ffmpeg once per video rendition (always all of RENDITIONS, so
    every upload ends up stored in multiple qualities), then writes a master
    playlist referencing each rendition's own .m3u8. Returns
    (master_path, audio_tracks).

    Multi-audio can come from two places, and both are combined into the
    same EXT-X-MEDIA AUDIO group:
      1. The source file itself having more than one embedded audio stream
         (e.g. a dual-audio container).
      2. Separate raw audio files uploaded alongside the video (`extra_audio_tracks`
         — see app/models.py:VideoAudioSource), each becoming its own
         selectable language/dub track.

    Whenever there's more than one track from either source, every track is
    encoded as its own audio-only HLS rendition and referenced via an
    EXT-X-MEDIA AUDIO group, so hls.js's audioTracks API — and the player's
    language switcher — sees every language as a real, independently
    selectable track. With a single audio stream and no extras (the common
    case) the audio stays muxed directly into each video rendition, exactly
    as before, so there's no extra encoding cost for ordinary uploads.
    """
    extra_audio_tracks = extra_audio_tracks or []
    embedded_tracks = probe_audio_streams(source_path)
    multi_audio = bool(extra_audio_tracks) or len(embedded_tracks) > 1
    variant_lines = []
    audio_tracks_meta: list[dict] = []

    if multi_audio:
        # Build one combined list covering the video's own embedded audio
        # (if any) plus every separately-uploaded dub, each carrying its own
        # ffmpeg source path and in-file stream index.
        combined = []
        if embedded_tracks:
            primary = embedded_tracks[0]
            primary_language = primary["language"]
            primary_name = primary["name"]
            if original_language:
                # An explicit language set at upload time (see
                # Video.original_language) always wins over what ffprobe
                # detected — most source files simply have no `language` tag
                # in their container metadata for ffprobe to find at all,
                # which is what left this track showing as "Unknown" in the
                # player's audio menu.
                primary_language = original_language
                primary_name = _display_name_for(original_language)
            combined.append({
                "source_path": source_path,
                "stream_index": primary["index"],
                "language": primary_language,
                "name": primary_name,
                "is_default": False,
            })
        for extra in extra_audio_tracks:
            combined.append({
                "source_path": extra["path"],
                "stream_index": 0,
                "language": extra["language"],
                "name": extra["name"],
                "is_default": bool(extra.get("is_default")),
            })

        # Exactly one DEFAULT=YES: honor an explicit default if one was set
        # at upload time, otherwise fall back to the video's own audio (or
        # the first track if the video itself was silent).
        if not any(track["is_default"] for track in combined):
            combined[0]["is_default"] = True
        else:
            seen_default = False
            for track in combined:
                if track["is_default"] and not seen_default:
                    seen_default = True
                elif track["is_default"]:
                    track["is_default"] = False

        # Re-encoding audio per track lets us hand each language its own
        # bandwidth-appropriate AAC stream instead of reusing whatever
        # codec/bitrate the source happened to use.
        audio_bitrate = "128k"
        slug_counts: dict[str, int] = {}
        for track in combined:
            slug_base = track["language"] or "und"
            slug_counts[slug_base] = slug_counts.get(slug_base, 0) + 1
            slug = slug_base if slug_counts[slug_base] == 1 else f"{slug_base}{slug_counts[slug_base]}"
            rendition_dir = os.path.join(output_dir, f"audio_{slug}")
            _encode_audio_rendition(track["source_path"], rendition_dir, track["stream_index"], audio_bitrate)
            default = "YES" if track["is_default"] else "NO"
            variant_lines.append(
                f'#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",NAME="{track["name"]}",'
                f'LANGUAGE="{track["language"]}",DEFAULT={default},AUTOSELECT=YES,'
                f'URI="audio_{slug}/index.m3u8"\n'
            )
            audio_tracks_meta.append({"language": track["language"], "name": track["name"]})

    for name, width, height, v_bitrate, a_bitrate in RENDITIONS:
        rendition_dir = os.path.join(output_dir, name)
        _encode_video_rendition(source_path, rendition_dir, height, v_bitrate, mux_audio=not multi_audio, a_bitrate=a_bitrate)
        bandwidth = int(v_bitrate[:-1]) * 1000 + int(a_bitrate[:-1]) * 1000
        audio_group = ',AUDIO="audio"' if multi_audio else ""
        variant_lines.append(
            f"#EXT-X-STREAM-INF:BANDWIDTH={bandwidth},RESOLUTION={width}x{height}{audio_group}\n{name}/index.m3u8\n"
        )

    master_path = os.path.join(output_dir, "master.m3u8")
    with open(master_path, "w") as f:
        f.write(MASTER_PLAYLIST_HEADER + "".join(variant_lines))

    return master_path, audio_tracks_meta


def clear_hls_prefix(hls_prefix: str) -> None:
    """Delete every existing object under this video's HLS prefix before a
    (re)transcode uploads fresh ones.

    Segment and rendition-playlist filenames are deterministic
    (360p/index.m3u8, seg_000.ts, ...), so a reprocess reuses the exact same
    S3 keys as the original run. Combined with the long-lived, immutable
    Cache-Control now set on segments (see upload_hls_output), leaving old
    objects in place could let a stale segment survive under a key a fresh
    run no longer writes to (e.g. if segment count changes between runs),
    or briefly serve a mix of old and new bytes for the same key mid-upload.
    Clearing first guarantees whatever ends up at this prefix came entirely
    from the run that just finished.
    """
    paginator = s3_client.get_paginator("list_objects_v2")
    keys_to_delete = []
    for page in paginator.paginate(Bucket=settings.s3_bucket, Prefix=hls_prefix):
        for obj in page.get("Contents", []):
            keys_to_delete.append({"Key": obj["Key"]})
    for i in range(0, len(keys_to_delete), 1000):
        batch = keys_to_delete[i:i + 1000]
        if batch:
            s3_client.delete_objects(Bucket=settings.s3_bucket, Delete={"Objects": batch})


def upload_hls_output(output_dir: str, hls_prefix: str) -> None:
    for root, _dirs, files in os.walk(output_dir):
        for file_name in files:
            local_path = os.path.join(root, file_name)
            relative = os.path.relpath(local_path, output_dir).replace(os.sep, "/")
            key = f"{hls_prefix}{relative}"
            is_manifest = file_name.endswith(".m3u8")
            content_type = "application/vnd.apple.mpegurl" if is_manifest else "video/mp2t"
            # Manifests (especially master.m3u8) change in place on a
            # reprocess — the S3 key is identical before and after, only its
            # contents differ. Without an explicit no-cache header, browsers
            # apply heuristic caching to a 200 response with no
            # Cache-Control at all, and a fronting CDN would cache it for
            # its default TTL — either way viewers can keep getting the old
            # manifest indefinitely after a reprocess. Segments (.ts), by
            # contrast, are content-addressed enough in practice (same
            # rendition + sequence number = same encode) to cache
            # aggressively.
            cache_control = "no-cache, no-store, must-revalidate" if is_manifest else "public, max-age=31536000, immutable"
            s3_client.upload_file(
                local_path, settings.s3_bucket, key,
                ExtraArgs={"ContentType": content_type, "CacheControl": cache_control},
            )


def run_pipeline(raw_s3_key: str, hls_prefix: str, extra_audio_sources: list[dict] | None = None, original_language: str | None = None) -> list[dict]:
    """Full pipeline for one video: download -> transcode to multi-bitrate HLS -> upload.

    `extra_audio_sources`, if given, is a list of {raw_s3_key, language,
    label, is_default} for dub/audio-track files uploaded separately from
    the video itself (see app/models.py:VideoAudioSource) — each is
    downloaded here and encoded into the same multi-audio HLS output as the
    video's own embedded audio.

    Returns the detected/attached audio tracks (empty list if there was
    ultimately just one audio track) so the caller can persist them for
    display purposes. Every upload always ends up stored in all of
    RENDITIONS' qualities regardless of audio track count — see
    transcode_to_hls.
    """
    with tempfile.TemporaryDirectory() as tmp:
        source_path = os.path.join(tmp, "source")
        output_dir = os.path.join(tmp, "hls")
        os.makedirs(output_dir, exist_ok=True)

        download_raw(raw_s3_key, source_path)

        downloaded_extra_tracks = []
        for position, extra in enumerate(extra_audio_sources or []):
            local_path = os.path.join(tmp, f"extra_audio_{position}")
            download_raw(extra["raw_s3_key"], local_path)
            downloaded_extra_tracks.append({
                "path": local_path,
                "language": extra["language"],
                "name": extra["label"],
                "is_default": extra.get("is_default", False),
            })

        _master_path, audio_tracks = transcode_to_hls(source_path, output_dir, downloaded_extra_tracks, original_language)
        clear_hls_prefix(hls_prefix)
        upload_hls_output(output_dir, hls_prefix)
        return audio_tracks
