"""Celery tasks: transcode an S3 upload to adaptive HLS, and capture live
thumbnails from an in-progress broadcast."""
import json
import os
import subprocess
import tempfile
import uuid

from app.database import SessionLocal
from app.models import Video, VideoStatus, Notification, LiveStream, LiveStreamStatus
from app.config import settings
from app.s3 import s3_client, public_asset_url
from app.worker.celery_app import celery_app
from app.worker.transcode import run_pipeline


def _notify_owner(db, video: Video, kind: str, title: str, message: str) -> None:
    db.add(Notification(user_id=video.owner_id, video_id=video.id, kind=kind, title=title, message=message))
    db.commit()


@celery_app.task(name="app.worker.tasks.transcode_video", bind=True, max_retries=2)
def transcode_video(self, video_id: str):
    db = SessionLocal()
    try:
        video = db.query(Video).filter(Video.id == video_id).first()
        if not video:
            return
        video.status = VideoStatus.processing
        db.commit()
        try:
            extra_audio_sources = [
                {
                    "raw_s3_key": source.raw_s3_key,
                    "language": source.language,
                    "label": source.label,
                    "is_default": source.is_default,
                }
                for source in video.audio_sources
            ]
            audio_tracks = run_pipeline(video.raw_s3_key, video.hls_prefix, extra_audio_sources, video.original_language)
            video.status = VideoStatus.ready
            video.audio_tracks_json = json.dumps(audio_tracks) if audio_tracks else None
            db.commit()
            _notify_owner(db, video, "success", "Title is ready to stream", f'"{video.title}" finished processing and is now live.')
        except Exception as exc:
            video.status = VideoStatus.failed
            db.commit()
            _notify_owner(db, video, "error", "Processing failed", f'"{video.title}" could not be processed. You can re-upload it.')
            raise self.retry(exc=exc, countdown=30)
    finally:
        db.close()


# How often the auto-capture job re-grabs a fresh frame while a broadcast
# stays live, in seconds. Frequent enough that the "Live now" rail doesn't
# show a stale/black frame for long, infrequent enough not to hammer
# ffmpeg/S3 for a broadcast that might run for hours.
LIVE_THUMBNAIL_REFRESH_SECONDS = 90
# Give MediaMTX a moment to actually have an HLS segment ready after
# runOnReady fires — grabbing a frame the instant the hook lands can hit an
# empty/not-yet-published playlist.
LIVE_THUMBNAIL_INITIAL_DELAY_SECONDS = 8


def _grab_frame(hls_url: str, out_path: str) -> None:
    """Pull a single frame from a live HLS manifest via ffmpeg and write it
    as a small JPEG. Raises CalledProcessError/TimeoutExpired on failure —
    callers decide whether/how to retry."""
    subprocess.run(
        [
            "ffmpeg", "-y",
            "-i", hls_url,
            "-frames:v", "1",
            "-q:v", "4",
            "-vf", "scale=640:-2",
            out_path,
        ],
        check=True,
        capture_output=True,
        timeout=20,
    )


@celery_app.task(name="app.worker.tasks.capture_live_thumbnail", bind=True, max_retries=3)
def capture_live_thumbnail(self, stream_id: str):
    """Auto-generate a broadcast's thumbnail by grabbing a frame straight
    from its own live HLS feed — so a broadcaster who doesn't set one by
    hand still gets a real preview instead of a generic icon in the "Live
    now" rail. Re-schedules itself every LIVE_THUMBNAIL_REFRESH_SECONDS for
    as long as the stream stays live, so the thumbnail keeps tracking
    what's actually on screen; stops on its own once the stream ends or the
    broadcaster sets a thumbnail manually (see poster_is_manual)."""
    db = SessionLocal()
    try:
        stream = db.query(LiveStream).filter(LiveStream.id == stream_id).first()
        if not stream or stream.status != LiveStreamStatus.live:
            return
        if stream.poster_is_manual:
            return

        with tempfile.TemporaryDirectory() as tmp_dir:
            out_path = os.path.join(tmp_dir, "thumb.jpg")
            try:
                _grab_frame(stream.hls_url, out_path)
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
                # The publisher can take a few seconds to actually produce a
                # playable segment after runOnReady fires — retry a handful
                # of times before giving up on this cycle (the next
                # refresh cycle, once the stream is truly flowing, will
                # succeed on its own even if every retry here fails).
                if self.request.retries < self.max_retries:
                    raise self.retry(exc=exc, countdown=5)
                return

            key = f"live-thumbs/{stream.id}/{uuid.uuid4().hex}.jpg"
            s3_client.upload_file(
                out_path, settings.s3_bucket, key,
                ExtraArgs={"ContentType": "image/jpeg", "CacheControl": "no-cache, no-store, must-revalidate"},
            )

        # Re-check status/manual flag right before writing — a lot can
        # happen during the ffmpeg call + upload above (stream ended,
        # broadcaster uploaded their own thumbnail mid-capture).
        db.refresh(stream)
        if stream.status == LiveStreamStatus.live and not stream.poster_is_manual:
            stream.poster_url = public_asset_url(key)
            db.commit()
    finally:
        db.close()

    # Keep refreshing on a steady cadence while the broadcast continues.
    # Re-query status fresh (this session is closed) via a light check
    # inside a new one, to avoid scheduling forever after a stream ends.
    db = SessionLocal()
    try:
        stream = db.query(LiveStream).filter(LiveStream.id == stream_id).first()
        if stream and stream.status == LiveStreamStatus.live:
            capture_live_thumbnail.apply_async(args=[stream_id], countdown=LIVE_THUMBNAIL_REFRESH_SECONDS)
    finally:
        db.close()
