"""Celery application used by the transcoding worker."""
from celery import Celery

from app.config import settings

celery_app = Celery(
    "streamverse",
    broker=settings.redis_url,
    backend=settings.redis_url,
    include=["app.worker.tasks"],
)

celery_app.conf.update(
    task_default_queue="transcode",
    task_routes={
        "app.worker.tasks.transcode_video": {"queue": "transcode"},
        # Runs on the same worker/queue as transcode_video — it's a quick
        # ffmpeg + S3 call, not worth a dedicated queue/worker process.
        "app.worker.tasks.capture_live_thumbnail": {"queue": "transcode"},
    },
    task_track_started=True,
    broker_connection_retry_on_startup=True,
    timezone="UTC",
)
