from app.config import settings


def signed_playback_url(hls_prefix: str, cache_bust: str | None = None) -> str:
    """Return the playback URL for a title's master playlist.

    `cache_bust` should change whenever the underlying HLS files have been
    re-written (e.g. after /videos/{id}/reprocess) — typically the video's
    `updated_at` timestamp. Without it, the URL for a given title's master
    playlist never changes, so a CDN edge cache (or even just the browser's
    own HTTP cache) can keep serving the *old* manifest — the one from
    before a reprocess — even though the S3 object underneath it was
    successfully overwritten with fresh, multi-quality renditions. This
    silent staleness was previously mistaken for the transcode pipeline
    itself not producing multiple qualities; the pipeline was fine, the
    *URL* just never asked for a fresh copy. Appending it as a query
    parameter forces a cache miss without needing CloudFront invalidation
    permissions (this app only holds a CloudFront *domain*/signing key, not
    a distribution ID to call CreateInvalidation with).
    """
    if hls_prefix and (hls_prefix.startswith("http://") or hls_prefix.startswith("https://")):
        return f"{hls_prefix}?v={cache_bust}" if cache_bust else hls_prefix
    base = (
        f"https://{settings.cloudfront_domain}/{hls_prefix}master.m3u8"
        if settings.cloudfront_domain
        else f"https://{settings.s3_bucket}.s3.{settings.aws_region}.amazonaws.com/{hls_prefix}master.m3u8"
    )
    return f"{base}?v={cache_bust}" if cache_bust else base