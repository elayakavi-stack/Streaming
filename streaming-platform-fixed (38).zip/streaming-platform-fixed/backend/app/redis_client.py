"""
Redis client stub for local development.
Falls back to an in-memory dict when Redis is not available.
"""
import json

_cache: dict = {}


def cache_get(key: str):
    return _cache.get(key)


def cache_set(key: str, value: str, ttl_seconds: int = 300):
    _cache[key] = value


def cache_invalidate(key: str):
    _cache.pop(key, None)
