from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import require_admin
from app.models import User, Video, Category, Report
from app.schemas import (
    AdminUserOut,
    AdminUserUpdate,
    CategoryCreate,
    CategoryUpdate,
    CategoryOut,
    ReportCreate,
    ReportUpdate,
    ReportOut,
)

router = APIRouter(prefix="/admin", tags=["admin"])


# ---- Users ----

@router.get("/users", response_model=list[AdminUserOut])
def list_users(db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    users = db.query(User).order_by(User.created_at.desc()).all()
    counts = dict(db.query(Video.owner_id, func.count(Video.id)).group_by(Video.owner_id).all())
    return [
        AdminUserOut(
            id=str(u.id),
            email=u.email,
            is_admin=u.is_admin,
            is_active=u.is_active,
            plan=u.plan,
            can_stream=u.can_stream,
            stream_requested_at=u.stream_requested_at,
            created_at=u.created_at,
            last_active_at=u.last_active_at,
            titles_uploaded=counts.get(u.id, 0),
        )
        for u in users
    ]


@router.patch("/users/{user_id}", response_model=AdminUserOut)
def update_user(
    user_id: str,
    payload: AdminUserUpdate,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.id == admin.id and payload.is_admin is False:
        raise HTTPException(status_code=400, detail="You can't remove your own admin access")

    updates = payload.model_dump(exclude_none=True)
    for field, value in updates.items():
        setattr(target, field, value)
    # Approving a streaming request resolves it — clear the pending marker
    # so the admin console stops showing it as awaiting action.
    if updates.get("can_stream") is True:
        target.stream_requested_at = None
    db.commit()
    db.refresh(target)

    titles = db.query(func.count(Video.id)).filter(Video.owner_id == target.id).scalar() or 0
    return AdminUserOut(
        id=str(target.id),
        email=target.email,
        is_admin=target.is_admin,
        is_active=target.is_active,
        plan=target.plan,
        can_stream=target.can_stream,
        stream_requested_at=target.stream_requested_at,
        created_at=target.created_at,
        last_active_at=target.last_active_at,
        titles_uploaded=titles,
    )


@router.delete("/users/{user_id}")
def delete_user(
    user_id: str,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.id == admin.id:
        raise HTTPException(status_code=400, detail="You can't delete your own account")

    titles = db.query(func.count(Video.id)).filter(Video.owner_id == target.id).scalar() or 0
    if titles:
        raise HTTPException(
            status_code=400,
            detail=f"This user owns {titles} title(s) — delete or reassign them first",
        )

    db.delete(target)
    db.commit()
    return {"status": "deleted", "user_id": user_id}


# ---- Categories ----

@router.get("/categories", response_model=list[CategoryOut])
def list_categories(db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    categories = db.query(Category).order_by(Category.updated_at.desc()).all()
    result = []
    for category in categories:
        count = db.query(func.count(Video.id)).filter(func.lower(Video.genre) == category.name.lower()).scalar() or 0
        result.append(CategoryOut(id=str(category.id), name=category.name, is_public=category.is_public, updated_at=category.updated_at, title_count=count))
    return result


@router.post("/categories", response_model=CategoryOut, status_code=201)
def create_category(payload: CategoryCreate, db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    if db.query(Category).filter(func.lower(Category.name) == payload.name.lower()).first():
        raise HTTPException(status_code=400, detail="A category with that name already exists")
    category = Category(name=payload.name, is_public=payload.is_public)
    db.add(category)
    db.commit()
    db.refresh(category)
    count = db.query(func.count(Video.id)).filter(func.lower(Video.genre) == category.name.lower()).scalar() or 0
    return CategoryOut(id=str(category.id), name=category.name, is_public=category.is_public, updated_at=category.updated_at, title_count=count)


@router.patch("/categories/{category_id}", response_model=CategoryOut)
def update_category(category_id: str, payload: CategoryUpdate, db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    category = db.query(Category).filter(Category.id == category_id).first()
    if not category:
        raise HTTPException(status_code=404, detail="Category not found")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(category, field, value)
    db.commit()
    db.refresh(category)
    count = db.query(func.count(Video.id)).filter(func.lower(Video.genre) == category.name.lower()).scalar() or 0
    return CategoryOut(id=str(category.id), name=category.name, is_public=category.is_public, updated_at=category.updated_at, title_count=count)


@router.delete("/categories/{category_id}")
def delete_category(category_id: str, db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    category = db.query(Category).filter(Category.id == category_id).first()
    if not category:
        raise HTTPException(status_code=404, detail="Category not found")
    db.delete(category)
    db.commit()
    return {"status": "deleted"}


# ---- Reports ----

@router.get("/reports", response_model=list[ReportOut])
def list_reports(db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    reports = db.query(Report).order_by(Report.created_at.desc()).all()
    return [
        ReportOut(
            id=str(r.id),
            subject=r.subject,
            message=r.message,
            status=r.status,
            created_at=r.created_at,
            resolved_at=r.resolved_at,
            video_id=str(r.video_id) if r.video_id else None,
            video_title=r.video.title if r.video else None,
            reporter_email=r.reporter.email if r.reporter else None,
        )
        for r in reports
    ]


@router.patch("/reports/{report_id}", response_model=ReportOut)
def update_report(report_id: str, payload: ReportUpdate, db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    from datetime import datetime, timezone

    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    report.status = payload.status
    report.resolved_at = datetime.now(timezone.utc) if payload.status.value == "resolved" else None
    db.commit()
    db.refresh(report)
    return ReportOut(
        id=str(report.id),
        subject=report.subject,
        message=report.message,
        status=report.status,
        created_at=report.created_at,
        resolved_at=report.resolved_at,
        video_id=str(report.video_id) if report.video_id else None,
        video_title=report.video.title if report.video else None,
        reporter_email=report.reporter.email if report.reporter else None,
    )
