from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.dependencies import get_current_user, require_admin, require_streamer
from app.models import User, LiveStream, LiveStreamStatus, Notification
from app.schemas import (
    LiveStreamCreate,
    LiveStreamOut,
    LiveStreamIngest,
    StreamAccessStatus,
    LiveStreamThumbnailUpdate,
    LiveAssetUploadRequest,
    AssetUploadResponse,
)
from app.rtmp_stream import generate_stream_key, build_ingest_urls, kick_stream
from app.s3 import asset_key_for, presign_put, public_asset_url
from app.worker.tasks import capture_live_thumbnail, LIVE_THUMBNAIL_INITIAL_DELAY_SECONDS

router = APIRouter(prefix="/live", tags=["live"])


def _to_out(stream: LiveStream) -> LiveStreamOut:
    return LiveStreamOut(
        id=str(stream.id),
        title=stream.title,
        description=stream.description,
        poster_url=stream.poster_url,
        poster_is_manual=stream.poster_is_manual,
        status=stream.status,
        hls_url=stream.hls_url,
        dash_url=stream.dash_url,
        owner_email=stream.owner.email if stream.owner else None,
        created_at=stream.created_at,
        started_at=stream.started_at,
        ended_at=stream.ended_at,
    )


def _get_or_404(stream_id: str, db: Session) -> LiveStream:
    stream = db.query(LiveStream).filter(LiveStream.id == stream_id).first()
    if not stream:
        raise HTTPException(status_code=404, detail="Live stream not found")
    return stream


def _require_owner_or_admin(stream: LiveStream, user: User) -> None:
    if stream.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Only the broadcaster can do this")


@router.get("", response_model=list[LiveStreamOut])
def list_live_streams(db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    """Currently-live broadcasts, newest first — powers the "Live now" rail."""
    streams = (
        db.query(LiveStream)
        .filter(LiveStream.status == LiveStreamStatus.live)
        .order_by(LiveStream.started_at.desc())
        .all()
    )
    return [_to_out(s) for s in streams]


@router.post("", response_model=LiveStreamOut, status_code=201)
def create_stream(
    payload: LiveStreamCreate,
    db: Session = Depends(get_db),
    broadcaster: User = Depends(require_streamer),
):
    """Provision a new broadcast slot: generates a private RTMP stream key
    and a matching DB record in 'idle' status. The broadcaster then fetches
    the RTMP server address + stream key from /ingest, points OBS (or any
    RTMP-capable software) at it, and the stream flips to 'live' on its own
    once MediaMTX's runOnReady hook confirms media is actually flowing (see
    /hooks/ready below) — /start remains available as a manual override.

    Open to admins and to any user an admin has approved via `can_stream`
    (see require_streamer)."""
    stream_key = generate_stream_key()
    urls = build_ingest_urls(stream_key)

    stream = LiveStream(
        owner_id=broadcaster.id,
        title=payload.title,
        description=payload.description,
        poster_url=payload.poster_url,
        # A poster supplied up front is a deliberate choice — never let
        # auto-capture (see /hooks/ready below) silently replace it once
        # the broadcast goes live.
        poster_is_manual=bool(payload.poster_url),
        status=LiveStreamStatus.idle,
        stream_key=stream_key,
        hls_url=urls["hls_url"],
    )
    db.add(stream)
    db.commit()
    db.refresh(stream)
    return _to_out(stream)


@router.post("/assets/presign", response_model=AssetUploadResponse)
def presign_thumbnail_upload(
    payload: LiveAssetUploadRequest,
    broadcaster: User = Depends(require_streamer),
):
    """Issue a direct S3 upload URL for a broadcaster-supplied live
    thumbnail image. Open to any approved streamer (not just admins) —
    unlike /videos/assets/presign, which backs the admin-only catalog."""
    key = asset_key_for("live", payload.filename)
    return AssetUploadResponse(
        upload_url=presign_put(key, payload.content_type),
        asset_url=public_asset_url(key),
        key=key,
    )


@router.get("/mine", response_model=list[LiveStreamOut])
def my_streams(db: Session = Depends(get_db), broadcaster: User = Depends(require_streamer)):
    streams = (
        db.query(LiveStream)
        .filter(LiveStream.owner_id == broadcaster.id)
        .order_by(LiveStream.created_at.desc())
        .limit(20)
        .all()
    )
    return [_to_out(s) for s in streams]


@router.get("/access/status", response_model=StreamAccessStatus)
def streaming_access_status(user: User = Depends(get_current_user)):
    """Lets the frontend know whether the signed-in user can go live yet,
    and whether they already have a pending request awaiting approval."""
    return StreamAccessStatus(
        can_stream=user.is_admin or user.can_stream,
        stream_requested_at=user.stream_requested_at,
    )


@router.post("/access/request", response_model=StreamAccessStatus)
def request_streaming_access(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """A regular user asks to be allowed to go live. Records the request
    timestamp and notifies every admin so they can approve it from the
    Users tab of the admin console."""
    if user.is_admin or user.can_stream:
        return StreamAccessStatus(can_stream=True, stream_requested_at=user.stream_requested_at)

    user.stream_requested_at = datetime.now(timezone.utc)
    db.add(user)

    admins = db.query(User).filter(User.is_admin.is_(True)).all()
    for admin in admins:
        db.add(
            Notification(
                user_id=admin.id,
                kind="stream_request",
                title="Streaming access requested",
                message=f"{user.email} asked for permission to go live.",
            )
        )

    db.commit()
    db.refresh(user)
    return StreamAccessStatus(can_stream=False, stream_requested_at=user.stream_requested_at)


@router.get("/{stream_id}", response_model=LiveStreamOut)
def get_stream(stream_id: str, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    return _to_out(_get_or_404(stream_id, db))


@router.get("/{stream_id}/ingest", response_model=LiveStreamIngest)
def get_ingest(stream_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """The RTMP server address and private stream key — only exposed to the
    stream's owner or an admin."""
    stream = _get_or_404(stream_id, db)
    _require_owner_or_admin(stream, user)
    urls = build_ingest_urls(stream.stream_key)
    return LiveStreamIngest(id=str(stream.id), rtmp_url=urls["rtmp_url"], whip_url=urls["whip_url"], stream_key=stream.stream_key)


@router.patch("/{stream_id}/thumbnail", response_model=LiveStreamOut)
def set_thumbnail(
    stream_id: str,
    payload: LiveStreamThumbnailUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Broadcaster sets (or replaces) the broadcast's thumbnail by hand —
    works before, during, or after the stream, pairs with
    POST /live/assets/presign for uploading the image itself. Marks the
    poster as manual so the auto-capture job (see /hooks/ready) stops
    touching it."""
    stream = _get_or_404(stream_id, db)
    _require_owner_or_admin(stream, user)
    stream.poster_url = payload.poster_url
    stream.poster_is_manual = True
    db.commit()
    db.refresh(stream)
    return _to_out(stream)


@router.post("/{stream_id}/start", response_model=LiveStreamOut)
def start_stream(stream_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Manual override to mark a broadcast live. Normally unnecessary — the
    stream flips to 'live' on its own via /hooks/ready as soon as MediaMTX
    confirms the broadcaster is actually publishing."""
    stream = _get_or_404(stream_id, db)
    _require_owner_or_admin(stream, user)
    if stream.status == LiveStreamStatus.ended:
        raise HTTPException(status_code=400, detail="This stream has already ended — create a new one")
    was_live = stream.status == LiveStreamStatus.live
    stream.status = LiveStreamStatus.live
    stream.started_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(stream)
    if not was_live:
        capture_live_thumbnail.apply_async(args=[str(stream.id)], countdown=LIVE_THUMBNAIL_INITIAL_DELAY_SECONDS)
    return _to_out(stream)


@router.post("/{stream_id}/end", response_model=LiveStreamOut)
def end_stream(stream_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    stream = _get_or_404(stream_id, db)
    _require_owner_or_admin(stream, user)
    stream.status = LiveStreamStatus.ended
    stream.ended_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(stream)
    kick_stream(stream.stream_key)
    return _to_out(stream)


@router.delete("/{stream_id}")
def delete_stream(stream_id: str, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    stream = _get_or_404(stream_id, db)
    kick_stream(stream.stream_key)
    db.delete(stream)
    db.commit()
    return {"status": "deleted"}


@router.post("/hooks/ready", include_in_schema=False)
def stream_ready_hook(path: str, secret: str, db: Session = Depends(get_db)):
    """Called by MediaMTX's runOnReady hook (see mediamtx.yml) the instant a
    broadcaster's RTMP publish is accepted, so a stream only shows as 'live'
    once media is actually flowing — no reliance on the broadcasting
    software calling our API back, since OBS has no idea this platform
    exists. `secret` authenticates the call as coming from our own MediaMTX
    instance rather than an outsider hitting this URL directly."""
    if secret != settings.rtmp_hook_secret:
        raise HTTPException(status_code=403, detail="Invalid hook secret")
    stream_key = path.rsplit("/", 1)[-1]
    stream = db.query(LiveStream).filter(LiveStream.stream_key == stream_key).first()
    if not stream:
        raise HTTPException(status_code=404, detail="Unknown stream key")
    # Ignore reconnects to an already-ended broadcast's key rather than
    # resurrecting it — the owner has to create a new stream instead.
    if stream.status == LiveStreamStatus.idle:
        stream.status = LiveStreamStatus.live
        stream.started_at = datetime.now(timezone.utc)
        db.commit()
        capture_live_thumbnail.apply_async(args=[str(stream.id)], countdown=LIVE_THUMBNAIL_INITIAL_DELAY_SECONDS)
    return {"status": "ok"}


@router.post("/hooks/not-ready", include_in_schema=False)
def stream_not_ready_hook(path: str, secret: str, db: Session = Depends(get_db)):
    """Called by MediaMTX's runOnNotReady hook when the publisher
    disconnects — broadcast ended, OBS crashed, network dropped, etc."""
    if secret != settings.rtmp_hook_secret:
        raise HTTPException(status_code=403, detail="Invalid hook secret")
    stream_key = path.rsplit("/", 1)[-1]
    stream = db.query(LiveStream).filter(LiveStream.stream_key == stream_key).first()
    if not stream:
        raise HTTPException(status_code=404, detail="Unknown stream key")
    if stream.status == LiveStreamStatus.live:
        stream.status = LiveStreamStatus.ended
        stream.ended_at = datetime.now(timezone.utc)
        db.commit()
    return {"status": "ok"}
