from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user
from app.models import (
    User,
    UserPreference,
    Notification,
    Download,
    WatchHistory,
    Video,
    SubscriptionPlan,
)
from app.schemas import (
    PreferencesOut,
    PreferencesUpdate,
    SubscriptionOut,
    SubscriptionUpdate,
    NotificationOut,
    DownloadCreate,
    DownloadOut,
    HistoryEntryOut,
)
from app.routers.videos import _to_video_out

router = APIRouter(prefix="/account", tags=["account"])

PLAN_DETAILS = {
    SubscriptionPlan.essential: {"price_per_month": 149, "perks": ["HD streaming", "1 screen at a time"]},
    SubscriptionPlan.premium: {"price_per_month": 299, "perks": ["Full HD streaming", "2 screens at a time"]},
    SubscriptionPlan.ultimate: {"price_per_month": 499, "perks": ["4K UHD streaming", "4 screens at a time"]},
}


def _get_or_create_preference(db: Session, user: User) -> UserPreference:
    pref = db.query(UserPreference).filter(UserPreference.user_id == user.id).first()
    if not pref:
        pref = UserPreference(user_id=user.id)
        db.add(pref)
        db.commit()
        db.refresh(pref)
    return pref


@router.get("/preferences", response_model=PreferencesOut)
def get_preferences(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return _get_or_create_preference(db, user)


@router.put("/preferences", response_model=PreferencesOut)
def update_preferences(
    payload: PreferencesUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    pref = _get_or_create_preference(db, user)
    for field, value in payload.model_dump().items():
        setattr(pref, field, value)
    db.commit()
    db.refresh(pref)
    return pref


@router.get("/subscription", response_model=SubscriptionOut)
def get_subscription(user: User = Depends(get_current_user)):
    detail = PLAN_DETAILS[user.plan]
    return SubscriptionOut(plan=user.plan, price_per_month=detail["price_per_month"], perks=detail["perks"])


@router.put("/subscription", response_model=SubscriptionOut)
def update_subscription(
    payload: SubscriptionUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    user.plan = payload.plan
    db.commit()
    db.refresh(user)
    detail = PLAN_DETAILS[user.plan]
    return SubscriptionOut(plan=user.plan, price_per_month=detail["price_per_month"], perks=detail["perks"])


@router.get("/notifications", response_model=list[NotificationOut])
def list_notifications(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return (
        db.query(Notification)
        .filter(Notification.user_id == user.id)
        .order_by(Notification.created_at.desc())
        .limit(50)
        .all()
    )


@router.post("/notifications/{notification_id}/read", response_model=NotificationOut)
def mark_notification_read(notification_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    notification = db.query(Notification).filter(Notification.id == notification_id, Notification.user_id == user.id).first()
    if not notification:
        raise HTTPException(status_code=404, detail="Notification not found")
    notification.is_read = True
    db.commit()
    db.refresh(notification)
    return notification


@router.post("/notifications/read-all")
def mark_all_notifications_read(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    db.query(Notification).filter(Notification.user_id == user.id, Notification.is_read.is_(False)).update({"is_read": True})
    db.commit()
    return {"status": "ok"}


@router.delete("/notifications/{notification_id}")
def delete_notification(notification_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    notification = db.query(Notification).filter(Notification.id == notification_id, Notification.user_id == user.id).first()
    if not notification:
        raise HTTPException(status_code=404, detail="Notification not found")
    db.delete(notification)
    db.commit()
    return {"status": "deleted"}


@router.get("/downloads", response_model=list[DownloadOut])
def list_downloads(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    items = db.query(Download).filter(Download.user_id == user.id).order_by(Download.created_at.desc()).all()
    return [
        DownloadOut(id=str(item.id), created_at=item.created_at, video=_to_video_out(item.video, user.id, db))
        for item in items
        if item.video
    ]


@router.post("/downloads", response_model=DownloadOut, status_code=201)
def add_download(payload: DownloadCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    video = db.query(Video).filter(Video.id == payload.video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    existing = db.query(Download).filter(Download.user_id == user.id, Download.video_id == payload.video_id).first()
    if existing:
        return DownloadOut(id=str(existing.id), created_at=existing.created_at, video=_to_video_out(video, user.id, db))
    download = Download(user_id=user.id, video_id=payload.video_id)
    db.add(download)
    db.commit()
    db.refresh(download)
    return DownloadOut(id=str(download.id), created_at=download.created_at, video=_to_video_out(video, user.id, db))


@router.delete("/downloads/{video_id}")
def remove_download(video_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    download = db.query(Download).filter(Download.user_id == user.id, Download.video_id == video_id).first()
    if not download:
        raise HTTPException(status_code=404, detail="Download not found")
    db.delete(download)
    db.commit()
    return {"status": "deleted"}


@router.get("/history", response_model=list[HistoryEntryOut])
def get_history(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    entries = (
        db.query(WatchHistory)
        .filter(WatchHistory.user_id == user.id)
        .order_by(WatchHistory.updated_at.desc())
        .limit(50)
        .all()
    )
    result = []
    for entry in entries:
        video = db.query(Video).filter(Video.id == entry.video_id).first()
        if video:
            result.append(
                HistoryEntryOut(
                    video=_to_video_out(video, user.id, db),
                    progress_seconds=entry.progress_seconds,
                    duration_seconds=entry.duration_seconds,
                    updated_at=entry.updated_at,
                )
            )
    return result


@router.delete("/history/{video_id}")
def delete_history_entry(video_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    entry = db.query(WatchHistory).filter(WatchHistory.user_id == user.id, WatchHistory.video_id == video_id).first()
    if not entry:
        raise HTTPException(status_code=404, detail="History entry not found")
    db.delete(entry)
    db.commit()
    return {"status": "deleted"}


@router.delete("/history")
def clear_history(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    db.query(WatchHistory).filter(WatchHistory.user_id == user.id).delete()
    db.commit()
    return {"status": "cleared"}
