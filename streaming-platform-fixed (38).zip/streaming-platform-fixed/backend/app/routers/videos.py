from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user, require_admin
from app.models import User, Video, VideoStatus, Watchlist, WatchHistory, VideoRating, Report, Notification, Download, VideoSubtitle, VideoAudioSource
from app.schemas import (
    VideoCreateRequest,
    VideoCreateResponse,
    VideoOut,
    ProgressUpdate,
    WatchlistToggleResponse,
    CatalogPage,
    HomeRail,
    RatingRequest,
    RatingOut,
    AssetUploadRequest,
    AssetUploadResponse,
    ReportCreate,
    ReportOut,
    AudioTrackOut,
    SubtitleOut,
    SubtitleUploadRequest,
    SubtitleUploadResponse,
    SubtitleCreateRequest,
    AudioSourceOut,
    AudioSourceUploadRequest,
    AudioSourceUploadResponse,
    AudioSourceCreateRequest,
)
from app.s3 import raw_key_for, hls_prefix_for, presign_put, asset_key_for, public_asset_url, subtitle_key_for, audio_source_key_for
from app.cdn import signed_playback_url
from app.redis_client import cache_get, cache_set, cache_invalidate
from app.worker.tasks import transcode_video
from app.recommendations import recommend_videos, similar_mood_videos, recent_mood_recommendations, because_you_watched_videos

import json
import re

router = APIRouter(prefix="/videos", tags=["videos"])

_GENRE_SPLIT_RE = re.compile(r"[,/&]")


def _split_genres(raw: str | None) -> list[str]:
    """A title's genre field can hold a mixed value like "Action, Thriller"
    — split it into individual genre tags on commas, slashes, and ampersands.
    Deliberately does NOT split on hyphens: a hyphen can either separate two
    genres ("Action-Thriller") or be part of a single genre's name
    ("Sci-Fi"), and there's no reliable way to tell those apart from the
    string alone — so hyphenated genres are kept whole here, and matched via
    substring search instead (see `catalog`)."""
    if not raw:
        return []
    parts = _GENRE_SPLIT_RE.split(raw)
    return [p.strip() for p in parts if p.strip()]


def _video_genres(video: Video) -> list[str]:
    """All genre tags on a title — its main genre AND its sub-genre —
    combined into one list. Anywhere a title needs to be matched against a
    genre (search, browse filtering, home-page genre rails), it should
    match on this, not on `video.genre` alone: a title with "Action" as
    its main genre and "Crime" as its sub-genre is a crime movie too, and
    searching/filtering for "Crime" should find it."""
    return _split_genres(video.genre) + _split_genres(video.sub_genre)


def _reject_mixed_genre(field_name: str, value: str | None) -> None:
    """Main genre and sub-genre are each meant to hold exactly ONE tag —
    that's what keeps a title landing in exactly one home-page rail per
    tag rather than fragmenting (e.g. someone typing "Action, Thriller"
    into a single field would otherwise silently split into two tags at
    read time). The frontend now only offers a single-select dropdown for
    both fields, but this rejects a multi-genre value at the API layer too
    in case something else calls this endpoint directly."""
    if value and len(_split_genres(value)) > 1:
        raise HTTPException(
            status_code=400,
            detail=f"{field_name} must be a single genre, not a combined value like \"{value}\" — "
                    f"use the sub-genre field for a second tag.",
        )


@router.post("/assets/presign", response_model=AssetUploadResponse)
def presign_artwork_upload(
    payload: AssetUploadRequest,
    user: User = Depends(require_admin),
):
    """Issue a direct S3 upload URL for a poster or backdrop image."""
    key = asset_key_for(payload.purpose, payload.filename)
    return AssetUploadResponse(
        upload_url=presign_put(key, payload.content_type),
        asset_url=public_asset_url(key),
        key=key,
    )


@router.post("", response_model=VideoCreateResponse)
def create_video(
    payload: VideoCreateRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    _reject_mixed_genre("Main genre", payload.genre)
    _reject_mixed_genre("Sub-genre", payload.sub_genre)
    video = Video(
        owner_id=user.id,
        title=payload.title,
        description=payload.description,
        category=payload.category or "Movie",
        genre=payload.genre or "Action",
        sub_genre=payload.sub_genre,
        rating=payload.rating or "U/A 16+",
        imdb_score=payload.imdb_score or "8.5",
        release_year=payload.release_year or 2024,
        cast_members=payload.cast_members,
        director=payload.director,
        poster_url=payload.poster_url,
        backdrop_url=payload.backdrop_url,
        original_language=(payload.original_language or "").strip().lower() or None,
        moods=(payload.moods or "").strip() or None,
        raw_s3_key="",
        status=VideoStatus.pending_upload,
    )
    db.add(video)
    db.flush()

    raw_key = raw_key_for(video.id, payload.filename)
    video.raw_s3_key = raw_key
    video.hls_prefix = hls_prefix_for(video.id)
    db.commit()
    db.refresh(video)

    upload_url = presign_put(raw_key, payload.content_type)

    return VideoCreateResponse(
        video_id=str(video.id),
        upload_url=upload_url,
        raw_s3_key=raw_key,
    )


@router.post("/{video_id}/complete-upload", response_model=VideoOut)
def complete_upload(
    video_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    video.status = VideoStatus.processing
    db.commit()

    transcode_video.delay(video.id)
    cache_invalidate(f"video:{video_id}")

    return _to_video_out(video, user.id, db)


@router.post("/{video_id}/reprocess", response_model=VideoOut)
def reprocess_video(
    video_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    """Re-runs the transcode pipeline for a title that's already `ready` or
    `failed`. The raw upload is kept in S3 indefinitely (see raw_s3_key —
    it's never deleted after the initial transcode), so this just re-queues
    the same job complete-upload runs, against today's pipeline. Exists for
    titles that were processed by an older version of the worker (e.g.
    before multi-bitrate renditions or multi-audio muxing existed) — the
    code itself can't retroactively touch files that are already sitting in
    S3, only re-running the job overwrites them."""
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    if video.status == VideoStatus.pending_upload:
        raise HTTPException(status_code=409, detail="This title hasn't finished its initial upload yet.")
    if not video.raw_s3_key:
        raise HTTPException(status_code=409, detail="No raw source file on record for this title — it can't be reprocessed.")

    video.status = VideoStatus.processing
    db.commit()

    transcode_video.delay(video.id)
    cache_invalidate(f"video:{video_id}")

    return _to_video_out(video, user.id, db)


@router.get("", response_model=list[VideoOut])
def list_videos(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    videos = db.query(Video).order_by(Video.created_at.desc()).all()
    return [_to_video_out(v, user.id, db) for v in videos]


@router.get("/catalog", response_model=CatalogPage)
def catalog(
    q: str | None = Query(default=None, max_length=120),
    category: str | None = None,
    genre: str | None = None,
    year: int | None = Query(default=None, ge=1888, le=2100),
    new_release_days: int | None = Query(default=None, ge=1, le=365, description="Only titles uploaded within this many days (for the New Releases page)."),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=24, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    query = db.query(Video)
    if q:
        term = f"%{q.strip()}%"
        query = query.filter(or_(Video.title.ilike(term), Video.description.ilike(term), Video.cast_members.ilike(term), Video.director.ilike(term), Video.genre.ilike(term), Video.sub_genre.ilike(term)))
    if new_release_days:
        query = query.filter(Video.created_at >= datetime.now(timezone.utc) - timedelta(days=new_release_days), Video.status == VideoStatus.ready)
    if category:
        query = query.filter(func.lower(Video.category) == category.lower())
    if genre:
        # Match against BOTH the main genre and the sub-genre — a title
        # tagged Action (main) / Crime (sub) should turn up when someone
        # filters or searches for "Crime", not just "Action".
        query = query.filter(or_(Video.genre.ilike(f"%{genre}%"), Video.sub_genre.ilike(f"%{genre}%")))
    if year:
        query = query.filter(Video.release_year == year)
    total = query.count()
    videos = query.order_by(Video.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()
    return CatalogPage(items=[_to_video_out(v, user.id, db) for v in videos], total=total, page=page, page_size=page_size)


@router.get("/home", response_model=list[HomeRail])
def home(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Ready-to-render catalog rails for a streaming home screen."""
    # "New releases" — genuinely recent uploads only, not just "whatever's
    # newest in the catalog" (which, on a catalog with only a handful of
    # titles, would show everything and make the rail meaningless). A title
    # only counts as a new release if it was uploaded within the last 30
    # days and has finished processing (a still-processing title isn't
    # playable yet, so it shouldn't headline the rail).
    new_release_cutoff = datetime.now(timezone.utc) - timedelta(days=30)
    newest = (
        db.query(Video)
        .filter(Video.created_at >= new_release_cutoff, Video.status == VideoStatus.ready)
        .order_by(Video.created_at.desc())
        .limit(20)
        .all()
    )
    rails = [HomeRail(title="New releases", key="new-releases", items=[_to_video_out(v, user.id, db) for v in newest])] if newest else []
    history = (
        db.query(WatchHistory).filter(WatchHistory.user_id == user.id, WatchHistory.progress_seconds > 5)
        .order_by(WatchHistory.updated_at.desc()).limit(20).all()
    )
    if history:
        watched = db.query(Video).filter(Video.id.in_([item.video_id for item in history])).all()
        rails.insert(0, HomeRail(title="Continue watching", key="continue-watching", items=[_to_video_out(v, user.id, db) for v in watched]))
    # "Recommended for you" — genre affinity learned from this user's star
    # ratings blended with sentiment analysis of their review text (see
    # app/recommendations.py), plus watchlist/watch-history as weaker
    # signals. Sits right after Continue watching since, like that rail,
    # it's personalized rather than catalog-wide.
    recommended, top_genres = recommend_videos(db, str(user.id), limit=20)
    if recommended:
        subtitle = f"Because you liked {', '.join(top_genres[:2])}" if top_genres else None
        rails.insert(
            1 if history else 0,
            HomeRail(title="Recommended for you", key="recommended", subtitle=subtitle, items=[_to_video_out(v, user.id, db) for v in recommended]),
        )
    # Mood rail — distinct from "Recommended for you" above: that one
    # weighs a user's *entire* rating/watchlist/watch-history signal
    # evenly, this one leans specifically on what they've watched most
    # recently (see recent_mood_recommendations), so a comfort-watch kick
    # this week shows up quickly instead of being diluted by months of
    # unrelated history. Sits right after "Recommended for you" for the
    # same reason that one sits after "Continue watching" — most
    # personalized signal first.
    mood_recs, top_moods = recent_mood_recommendations(db, str(user.id), limit=20)
    if mood_recs:
        mood_subtitle = f"Because you've been in the mood for {', '.join(top_moods[:2])}" if top_moods else None
        insert_at = (1 if history else 0) + (1 if recommended else 0)
        rails.insert(
            insert_at,
            HomeRail(title="More like your recent watches", key="mood-recent", subtitle=mood_subtitle, items=[_to_video_out(v, user.id, db) for v in mood_recs]),
        )
    genre_bearing = (
        db.query(Video)
        .filter(Video.category.in_(["Movie", "TV Show"]))
        .filter(or_(Video.genre.isnot(None), Video.sub_genre.isnot(None)))
        .all()
    )
    # Count every tag a title carries — main genre AND sub-genre — so a
    # title tagged Action (main) / Crime (sub) contributes to both the
    # "Action" and "Crime" rail counts, not just its main genre's.
    genre_counts: dict[str, int] = {}
    for video in genre_bearing:
        for tag in set(_video_genres(video)):
            genre_counts[tag] = genre_counts.get(tag, 0) + 1
    # Most-populated genres first — a more useful ordering for a home screen
    # than plain alphabetical once there are more than a handful of genres.
    # Only the top, most-populated genres get their own home-page rail (a
    # genre only carried by one or two titles as a minor sub-genre tag
    # isn't "important" enough to earn a whole row) — it's still fully
    # browsable/searchable via genre + sub-genre everywhere else (catalog
    # filter, /genres list, recommendations), just not on the home page.
    ranked_genres = sorted(genre_counts, key=lambda g: (-genre_counts[g], g.lower()))
    # A title can carry two genre tags (main + sub) that both make this
    # top-8 cut — track which titles have already been placed in a rail so
    # each title only ever shows up in ONE genre rail on the home page
    # (whichever of its genres is more prominent/processed first), instead
    # of appearing twice just because it has two matching tags.
    placed_ids: set = set()
    for genre in ranked_genres[:8]:
        candidates = (
            db.query(Video)
            .filter(
                or_(Video.genre.ilike(f"%{genre}%"), Video.sub_genre.ilike(f"%{genre}%")),
                Video.category.in_(["Movie", "TV Show"]),
            )
            .order_by(Video.created_at.desc())
            .limit(60)
            .all()
        )
        # The ilike above is a loose superset match — narrow to titles that
        # genuinely carry this exact tag as either their main genre or
        # their sub-genre, and that haven't already been placed in an
        # earlier (more prominent) genre rail.
        items = [v for v in candidates if genre in _video_genres(v) and v.id not in placed_ids][:20]
        if not items:
            continue
        placed_ids.update(v.id for v in items)
        label = f"{genre} Movies" if genre.lower() not in ("documentary", "documentaries") else genre
        rails.append(HomeRail(title=label, key=f"genre-{genre.lower().replace(' ', '-')}", items=[_to_video_out(v, user.id, db) for v in items]))
    return rails


@router.get("/recommendations", response_model=list[VideoOut])
def recommendations(limit: int = Query(default=20, ge=1, le=50), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Standalone version of the "Recommended for you" rail — same engine
    as /home, for anywhere else in the app that wants it on its own (e.g. a
    dedicated recommendations page/section) without paying for the rest of
    the home rails."""
    videos, _top_genres = recommend_videos(db, str(user.id), limit=limit)
    return [_to_video_out(v, user.id, db) for v in videos]


@router.get("/genres", response_model=list[str])
def genres(db: Session = Depends(get_db)):
    # Pull from both columns so a genre that only ever appears as someone's
    # sub-genre (never anyone's main genre) still shows up as something you
    # can search/filter by.
    main = [row[0] for row in db.query(Video.genre).filter(Video.genre.isnot(None)).all()]
    sub = [row[0] for row in db.query(Video.sub_genre).filter(Video.sub_genre.isnot(None)).all()]
    unique_genres = sorted({g for raw in main + sub for g in _split_genres(raw)}, key=str.lower)
    return unique_genres


@router.get("/watchlist", response_model=list[VideoOut])
def list_watchlist(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    items = (
        db.query(Watchlist)
        .filter(Watchlist.user_id == user.id)
        .order_by(Watchlist.created_at.desc())
        .all()
    )
    video_ids = [item.video_id for item in items]
    videos = db.query(Video).filter(Video.id.in_(video_ids)).all() if video_ids else []
    return [_to_video_out(v, user.id, db) for v in videos]


@router.get("/continue-watching", response_model=list[VideoOut])
def continue_watching(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    history = (
        db.query(WatchHistory)
        .filter(WatchHistory.user_id == user.id, WatchHistory.progress_seconds > 5)
        .order_by(WatchHistory.updated_at.desc())
        .limit(10)
        .all()
    )
    result = []
    for h in history:
        v = db.query(Video).filter(Video.id == h.video_id).first()
        if v:
            out = _to_video_out(v, user.id, db)
            out.progress_seconds = h.progress_seconds
            result.append(out)
    return result


@router.post("/{video_id}/watchlist", response_model=WatchlistToggleResponse)
def toggle_watchlist(
    video_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not db.query(Video.id).filter(Video.id == video_id).first():
        raise HTTPException(status_code=404, detail="Video not found")
    existing = (
        db.query(Watchlist)
        .filter(Watchlist.user_id == user.id, Watchlist.video_id == video_id)
        .first()
    )
    if existing:
        db.delete(existing)
        db.commit()
        return WatchlistToggleResponse(
            video_id=video_id, is_in_watchlist=False, message="Removed from watchlist"
        )
    else:
        new_item = Watchlist(user_id=user.id, video_id=video_id)
        db.add(new_item)
        db.commit()
        return WatchlistToggleResponse(
            video_id=video_id, is_in_watchlist=True, message="Added to watchlist"
        )


@router.post("/{video_id}/progress")
@router.put("/{video_id}/progress")
def update_progress(
    video_id: str,
    payload: ProgressUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if payload.progress_seconds < 0:
        raise HTTPException(status_code=422, detail="Progress cannot be negative")
    if not db.query(Video.id).filter(Video.id == video_id).first():
        raise HTTPException(status_code=404, detail="Video not found")
    entry = (
        db.query(WatchHistory)
        .filter(WatchHistory.user_id == user.id, WatchHistory.video_id == video_id)
        .first()
    )
    if entry:
        entry.progress_seconds = payload.progress_seconds
        if payload.duration_seconds:
            entry.duration_seconds = payload.duration_seconds
    else:
        entry = WatchHistory(
            user_id=user.id,
            video_id=video_id,
            progress_seconds=payload.progress_seconds,
            duration_seconds=payload.duration_seconds or 0.0,
        )
        db.add(entry)
    db.commit()
    return {"status": "ok", "progress_seconds": payload.progress_seconds}


@router.put("/{video_id}/rating", response_model=RatingOut)
def rate_video(video_id: str, payload: RatingRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if not db.query(Video.id).filter(Video.id == video_id).first():
        raise HTTPException(status_code=404, detail="Video not found")
    rating = db.query(VideoRating).filter(VideoRating.user_id == user.id, VideoRating.video_id == video_id).first()
    if rating:
        rating.value, rating.review = payload.value, payload.review
    else:
        rating = VideoRating(user_id=user.id, video_id=video_id, value=payload.value, review=payload.review)
        db.add(rating)
    db.commit()
    average, count = db.query(func.avg(VideoRating.value), func.count(VideoRating.id)).filter(VideoRating.video_id == video_id).one()
    return RatingOut(video_id=video_id, value=payload.value, average_rating=round(float(average), 2), rating_count=count)


@router.patch("/{video_id}", response_model=VideoOut)
def update_video(
    video_id: str,
    payload: dict,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    if "genre" in payload:
        _reject_mixed_genre("Main genre", payload["genre"])
    if "sub_genre" in payload:
        _reject_mixed_genre("Sub-genre", payload["sub_genre"])

    allowed = ["title", "description", "category", "genre", "sub_genre", "rating", "imdb_score",
               "release_year", "cast_members", "director", "poster_url", "backdrop_url",
               "original_language", "moods"]
    for field in allowed:
        if field in payload:
            value = payload[field]
            if field == "original_language" and value:
                value = value.strip().lower() or None
            setattr(video, field, value)

    db.commit()
    db.refresh(video)
    cache_invalidate(f"video:{video_id}")
    return _to_video_out(video, user.id, db)


@router.delete("/{video_id}")
def delete_video(
    video_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    # VideoRating, Report, Notification, and Download all have a foreign key
    # to videos.id but aren't declared as SQLAlchemy relationships on Video,
    # so the ORM won't cascade-delete them. Left in place, any of these would
    # trip the DB's foreign-key constraint and make the delete fail outright.
    db.query(VideoRating).filter(VideoRating.video_id == video.id).delete(synchronize_session=False)
    db.query(Report).filter(Report.video_id == video.id).delete(synchronize_session=False)
    db.query(Notification).filter(Notification.video_id == video.id).delete(synchronize_session=False)
    db.query(Download).filter(Download.video_id == video.id).delete(synchronize_session=False)

    db.delete(video)
    db.commit()
    cache_invalidate(f"video:{video_id}")
    return {"status": "deleted", "video_id": video_id}


def _subtitle_content_type_for(filename: str) -> str:
    """Decide the S3 Content-Type for a subtitle file from its extension.

    Deliberately ignores whatever MIME type the browser reports for the
    File object: `.vtt`/`.srt` aren't universally registered on every
    OS/browser, so `File.type` frequently comes back empty or as
    `application/octet-stream`. If that value gets signed into the S3 PUT,
    the object is stored with a Content-Type that browsers will download
    fine (200 OK) but silently refuse to parse as a <track> — the request
    succeeds, TextTrack.mode is "showing", but cues.length stays 0. Always
    deriving the type server-side from the extension avoids that entirely.
    """
    lowered = filename.lower()
    if lowered.endswith(".srt"):
        return "application/x-subrip"
    return "text/vtt"


@router.post("/{video_id}/subtitles/presign", response_model=SubtitleUploadResponse)
def presign_subtitle_upload(
    video_id: str,
    payload: SubtitleUploadRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    """Issue a direct S3 upload URL for a WebVTT/SRT subtitle file."""
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    key = subtitle_key_for(video_id, payload.filename)
    content_type = _subtitle_content_type_for(payload.filename)
    return SubtitleUploadResponse(
        upload_url=presign_put(key, content_type),
        subtitle_url=public_asset_url(key),
        key=key,
        content_type=content_type,
    )


@router.post("/{video_id}/subtitles", response_model=SubtitleOut, status_code=201)
def add_subtitle(
    video_id: str,
    payload: SubtitleCreateRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    if payload.is_default:
        # Only one default track per title — the player auto-selects it.
        db.query(VideoSubtitle).filter(VideoSubtitle.video_id == video_id).update({"is_default": False})

    subtitle = VideoSubtitle(
        video_id=video_id,
        language=payload.language.strip().lower(),
        label=payload.label.strip(),
        url=payload.url,
        is_default=payload.is_default,
    )
    db.add(subtitle)
    db.commit()
    db.refresh(subtitle)
    cache_invalidate(f"video:{video_id}")
    return SubtitleOut(id=str(subtitle.id), language=subtitle.language, label=subtitle.label, url=subtitle.url, is_default=subtitle.is_default)


@router.delete("/{video_id}/subtitles/{subtitle_id}", status_code=204)
def delete_subtitle(
    video_id: str,
    subtitle_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    subtitle = db.query(VideoSubtitle).filter(VideoSubtitle.id == subtitle_id, VideoSubtitle.video_id == video_id).first()
    if not subtitle:
        raise HTTPException(status_code=404, detail="Subtitle not found")
    db.delete(subtitle)
    db.commit()
    cache_invalidate(f"video:{video_id}")
    return None


@router.post("/{video_id}/audio-tracks/presign", response_model=AudioSourceUploadResponse)
def presign_audio_source_upload(
    video_id: str,
    payload: AudioSourceUploadRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    """Issue a direct S3 upload URL for a raw dub/audio-track file (e.g. a
    separate Hindi audio track for an English video). Works both before a
    title's first upload finishes (the file gets picked up by
    complete-upload's queued job) and afterward, once it's `ready` or
    `failed` (see add_audio_source below, which queues a reprocess so it
    actually gets muxed in) — just not while a transcode is already
    running, since that job already downloaded whatever sources existed
    when it started."""
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    if video.status == VideoStatus.processing:
        raise HTTPException(status_code=409, detail="This title is already processing — wait for it to finish before adding another audio track.")
    key = audio_source_key_for(video_id, payload.filename)
    return AudioSourceUploadResponse(
        upload_url=presign_put(key, payload.content_type),
        key=key,
    )


def _requeue_transcode(db: Session, video: Video) -> None:
    """Shared by add/delete audio-track and reprocess: re-runs the
    transcode pipeline against the original upload so a change made after
    the title already finished processing (or failed) actually lands in
    the streaming files, rather than just sitting in the DB unused until
    someone happens to hit "Reprocess" by hand."""
    video.status = VideoStatus.processing
    db.commit()
    transcode_video.delay(video.id)
    cache_invalidate(f"video:{video.id}")


@router.post("/{video_id}/audio-tracks", response_model=AudioSourceOut, status_code=201)
def add_audio_source(
    video_id: str,
    payload: AudioSourceCreateRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    """Attach a dub/audio-track file to a title. If the title is still
    mid-upload (`pending_upload`), the track is simply picked up when
    complete-upload queues the first transcode. If the title is already
    `ready` or `failed`, this also re-queues the transcode pipeline right
    away so the new track is actually muxed into the streaming files
    instead of sitting unused."""
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    if video.status == VideoStatus.processing:
        raise HTTPException(status_code=409, detail="This title is already processing — wait for it to finish before adding another audio track.")

    if payload.is_default:
        db.query(VideoAudioSource).filter(VideoAudioSource.video_id == video_id).update({"is_default": False})

    source = VideoAudioSource(
        video_id=video_id,
        language=payload.language.strip().lower(),
        label=payload.label.strip(),
        raw_s3_key=payload.raw_s3_key,
        is_default=payload.is_default,
    )
    db.add(source)
    db.commit()
    db.refresh(source)

    if video.status in (VideoStatus.ready, VideoStatus.failed):
        _requeue_transcode(db, video)

    return AudioSourceOut(id=str(source.id), language=source.language, label=source.label, is_default=source.is_default)


@router.delete("/{video_id}/audio-tracks/{audio_source_id}", status_code=204)
def delete_audio_source(
    video_id: str,
    audio_source_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    if video.status == VideoStatus.processing:
        raise HTTPException(status_code=409, detail="This title is already processing — wait for it to finish before removing an audio track.")
    source = db.query(VideoAudioSource).filter(VideoAudioSource.id == audio_source_id, VideoAudioSource.video_id == video_id).first()
    if not source:
        raise HTTPException(status_code=404, detail="Audio track not found")
    db.delete(source)
    db.commit()

    # Removing a track from a title that's already streaming only takes
    # effect once the files are rebuilt without it.
    if video.status in (VideoStatus.ready, VideoStatus.failed):
        _requeue_transcode(db, video)

    return None


@router.post("/{video_id}/report", response_model=ReportOut, status_code=201)
def report_video(
    video_id: str,
    payload: ReportCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    report = Report(reporter_id=user.id, video_id=video_id, subject=payload.subject, message=payload.message)
    db.add(report)
    db.commit()
    db.refresh(report)
    return ReportOut(
        id=str(report.id),
        subject=report.subject,
        message=report.message,
        status=report.status,
        created_at=report.created_at,
        resolved_at=report.resolved_at,
        video_id=str(report.video_id),
        video_title=video.title,
        reporter_email=user.email,
    )


@router.get("/{video_id}", response_model=VideoOut)
def get_video(video_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    return _to_video_out(video, user.id, db)


@router.get("/{video_id}/similar-mood", response_model=list[VideoOut])
def get_similar_mood(video_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """"More like this mood" rail for the player page — other titles that
    feel similar to the one currently playing, based on shared mood tags
    AND genre (see Video.moods / Video.genre /
    app/recommendations.py:similar_mood_videos). Returns an empty list
    rather than 404/error when the title has no mood tags or genre set,
    since that's a normal, expected state for older titles uploaded
    before moods existed — the frontend just shows nothing rather than
    an error."""
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    similar = similar_mood_videos(db, video, limit=12)
    return [_to_video_out(v, user.id, db) for v in similar]


@router.get("/{video_id}/because-you-watched", response_model=list[VideoOut])
def get_because_you_watched(video_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """"Because you watched X" rail for the player page — other titles
    led by the same director or sharing a cast member with the one
    currently playing (see
    app/recommendations.py:because_you_watched_videos), falling back to
    genre overlap only when there's no cast/director match to work with.
    Distinct from "More like this mood" above: that rail is about
    tone/feel, this one is about "same hero" / "same director" picks."""
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    similar = because_you_watched_videos(db, video, limit=12)
    return [_to_video_out(v, user.id, db) for v in similar]


def _to_video_out(video: Video, user_id: str | None = None, db: Session | None = None) -> VideoOut:
    playback_url = None
    if video.status == VideoStatus.ready and video.hls_prefix:
        # Cache-bust with updated_at so a reprocess (which rewrites the same
        # S3 keys in place) actually reaches viewers instead of getting
        # served a stale cached copy of the old manifest — see cdn.py.
        cache_bust = str(int(video.updated_at.timestamp())) if video.updated_at else None
        playback_url = signed_playback_url(video.hls_prefix, cache_bust)

    is_in_wl = False
    progress_sec = 0.0
    duration_sec = None
    user_rating_value = None
    user_review_value = None

    if user_id and db:
        wl = (
            db.query(Watchlist)
            .filter(Watchlist.user_id == user_id, Watchlist.video_id == video.id)
            .first()
        )
        is_in_wl = bool(wl)

        hist = (
            db.query(WatchHistory)
            .filter(WatchHistory.user_id == user_id, WatchHistory.video_id == video.id)
            .first()
        )
        if hist:
            progress_sec = hist.progress_seconds
            if hist.duration_seconds:
                duration_sec = hist.duration_seconds

        own_rating = (
            db.query(VideoRating)
            .filter(VideoRating.user_id == user_id, VideoRating.video_id == video.id)
            .first()
        )
        if own_rating:
            user_rating_value = own_rating.value
            user_review_value = own_rating.review

    if duration_sec is None and video.duration_seconds:
        try:
            duration_sec = float(video.duration_seconds)
        except (TypeError, ValueError):
            duration_sec = None

    average_rating = None
    rating_count = 0
    if db:
        avg, count = (
            db.query(func.avg(VideoRating.value), func.count(VideoRating.id))
            .filter(VideoRating.video_id == video.id)
            .one()
        )
        rating_count = count or 0
        if avg is not None:
            average_rating = round(float(avg), 2)

    audio_tracks: list[AudioTrackOut] = []
    if video.audio_tracks_json:
        try:
            audio_tracks = [AudioTrackOut(**track) for track in json.loads(video.audio_tracks_json)]
        except (TypeError, ValueError):
            audio_tracks = []

    subtitles = [
        SubtitleOut(id=str(sub.id), language=sub.language, label=sub.label, url=sub.url, is_default=sub.is_default)
        for sub in (video.subtitles or [])
    ]

    pending_audio_sources = [
        AudioSourceOut(id=str(src.id), language=src.language, label=src.label, is_default=src.is_default)
        for src in (video.audio_sources or [])
    ]

    return VideoOut(
        id=str(video.id),
        title=video.title,
        description=video.description,
        category=video.category or "Movie",
        genre=video.genre or "Action",
        sub_genre=video.sub_genre,
        rating=video.rating or "U/A 16+",
        imdb_score=video.imdb_score or "8.5",
        release_year=video.release_year or 2024,
        cast_members=video.cast_members,
        director=video.director,
        poster_url=video.poster_url,
        backdrop_url=video.backdrop_url,
        original_language=video.original_language,
        moods=video.moods,
        status=video.status,
        playback_url=playback_url,
        is_in_watchlist=is_in_wl,
        progress_seconds=progress_sec,
        duration_seconds=duration_sec,
        average_rating=average_rating,
        rating_count=rating_count,
        user_rating=user_rating_value,
        user_review=user_review_value,
        audio_tracks=audio_tracks,
        subtitles=subtitles,
        pending_audio_sources=pending_audio_sources,
    )
