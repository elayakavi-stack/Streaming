from typing import Optional
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User
from app.security import decode_access_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login", auto_error=False)


def get_current_user(
    token: Optional[str] = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    """Returns the authenticated user for a valid bearer token, or raises 401.

    Every /videos and /profiles route depends on this, and the frontend's
    RequireSignIn gate + per-request Authorization header assume real
    enforcement here — so an invalid/missing token must not silently
    resolve to some default account.
    """
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
        headers={"WWW-Authenticate": "Bearer"},
    )
    if not token:
        raise credentials_error

    email = decode_access_token(token)
    if not email:
        raise credentials_error

    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise credentials_error
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="This account has been disabled")

    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if not user.is_admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Administrator access required")
    return user


def require_streamer(user: User = Depends(get_current_user)) -> User:
    """Gate for going live: admins can always broadcast; everyone else needs
    an admin to have flipped `can_stream` on for their account first."""
    if not (user.is_admin or user.can_stream):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Live streaming requires admin approval. Request access from your account menu.",
        )
    return user
