from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine, SessionLocal
from app.routers import auth, videos, profiles, account, admin, live
from app.seed import seed_database_if_empty
from app.migrate import run_lightweight_migrations

Base.metadata.create_all(bind=engine)
run_lightweight_migrations(engine)

# Auto seed database on boot
with SessionLocal() as db:
    seed_database_if_empty(db)

app = FastAPI(
    title="StreamVerse Streaming API",
    description="Next-Gen cloud video transcoding and HLS adaptive streaming platform API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(videos.router)
app.include_router(profiles.router)
app.include_router(account.router)
app.include_router(admin.router)
app.include_router(live.router)




@app.get("/")
def root():
    return {
        "status": "online",
        "service": "StreamVerse Streaming API",
        "documentation": "/docs",
        "frontend_url": "http://localhost:5173",
        "endpoints": {
            "videos": "/videos",
            "watchlist": "/videos/watchlist",
            "continue_watching": "/videos/continue-watching",
            "health": "/health",
            "profiles": "/profiles",
            "catalog": "/videos/catalog and /videos/home",
            "account": "/account/preferences, /account/subscription, /account/notifications, /account/downloads, /account/history",
            "admin": "/admin/users, /admin/categories, /admin/reports",
            "live": "/live (live now), /live/{id}, POST /live to go live (admin)",
        },
    }


@app.get("/health")
def health():
    return {"status": "ok"}
