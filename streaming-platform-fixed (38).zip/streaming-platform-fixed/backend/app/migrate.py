"""Tiny best-effort migration helper.

This project boots with `Base.metadata.create_all`, which creates missing
*tables* but never adds new *columns* to a table that already exists (e.g. an
existing `streamverse.db` from before the account/admin features were added).
Rather than pull in Alembic for a handful of additive, nullable columns, this
adds them directly with plain SQL and ignores "already exists" errors so it's
safe to run on every boot, on a fresh database, and on both SQLite and
Postgres.
"""
from sqlalchemy import inspect, text
from sqlalchemy.engine import Engine


def _add_column_if_missing(engine: Engine, table: str, column: str, ddl_type: str, default_sql: str) -> None:
    inspector = inspect(engine)
    if table not in inspector.get_table_names():
        return
    existing = {col["name"] for col in inspector.get_columns(table)}
    if column in existing:
        return
    with engine.begin() as conn:
        conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {column} {ddl_type} DEFAULT {default_sql}"))


def _relax_unknown_not_null_columns(engine: Engine, table: str, known_columns: set[str]) -> None:
    """Drop NOT NULL from any column the current model doesn't know about.

    Tables that have been through a few schema generations (e.g. live_streams,
    which used to back a Cloudflare Stream integration before this MediaMTX
    version existed) can carry old NOT NULL columns like cf_input_uid that
    the ORM never sets on insert, since it doesn't know they exist. Postgres
    only here — SQLite can't ALTER COLUMN DROP NOT NULL without a full table
    rebuild, and a fresh SQLite db won't have this problem since it's created
    straight from the current model.
    """
    if engine.dialect.name != "postgresql":
        return
    inspector = inspect(engine)
    if table not in inspector.get_table_names():
        return
    for col in inspector.get_columns(table):
        if col["name"] not in known_columns and not col["nullable"]:
            with engine.begin() as conn:
                conn.execute(text(f'ALTER TABLE {table} ALTER COLUMN "{col["name"]}" DROP NOT NULL'))


def run_lightweight_migrations(engine: Engine) -> None:
    is_postgres = engine.dialect.name == "postgresql"

    bool_default = "TRUE" if is_postgres else "1"
    datetime_type = "TIMESTAMP" if is_postgres else "DATETIME"

    try:
        _add_column_if_missing(engine, "users", "plan", "VARCHAR(20)", "'essential'")
        _add_column_if_missing(engine, "users", "is_active", "BOOLEAN", bool_default)
        _add_column_if_missing(engine, "users", "last_active_at", datetime_type, "CURRENT_TIMESTAMP")
        bool_false = "FALSE" if is_postgres else "0"
        _add_column_if_missing(engine, "users", "can_stream", "BOOLEAN", bool_false)
        _add_column_if_missing(engine, "users", "stream_requested_at", datetime_type, "NULL")

        # live_streams predates the self-hosted RTMP/MediaMTX integration
        # (it used to back a Cloudflare Stream integration) — an existing
        # table won't have these columns yet. stream_key/hls_url are
        # nullable=False on the model, but ADD COLUMN can't retroactively
        # satisfy that for existing rows, so they're backfilled with a
        # placeholder here; any pre-existing rows are leftovers from the old
        # integration anyway and aren't publishable via MediaMTX regardless.
        _add_column_if_missing(engine, "live_streams", "stream_key", "VARCHAR(64)", "''")
        _add_column_if_missing(engine, "live_streams", "hls_url", "VARCHAR", "''")
        _add_column_if_missing(engine, "live_streams", "dash_url", "VARCHAR", "NULL")
        _add_column_if_missing(engine, "live_streams", "poster_url", "VARCHAR", "NULL")
        # See app/models.py:LiveStream.poster_is_manual — existing rows
        # default to FALSE (auto-capture may manage their thumbnail) since a
        # pre-existing poster_url on an old row was just as likely set by
        # the old Cloudflare integration as by a broadcaster.
        _add_column_if_missing(engine, "live_streams", "poster_is_manual", "BOOLEAN", bool_false)
        _add_column_if_missing(engine, "live_streams", "started_at", datetime_type, "NULL")
        _add_column_if_missing(engine, "live_streams", "ended_at", datetime_type, "NULL")

        # Columns like cf_input_uid from the old Cloudflare-backed version of
        # this table are still NOT NULL but unknown to the current model, so
        # every insert through the ORM violates that constraint. Relax them.
        live_stream_columns = {
            "id", "owner_id", "title", "description", "poster_url", "poster_is_manual", "status",
            "stream_key", "hls_url", "dash_url", "created_at", "started_at",
            "ended_at",
        }
        _relax_unknown_not_null_columns(engine, "live_streams", live_stream_columns)

        # audio_tracks_json backs the player's audio-language switcher — see
        # app/worker/transcode.py. An existing videos table won't have it yet.
        _add_column_if_missing(engine, "videos", "audio_tracks_json", "TEXT", "NULL")

        # sub_genre backs the upload/edit form's "Sub-genre" field and is
        # kept separate from the main `genre` column — see app/models.py.
        _add_column_if_missing(engine, "videos", "sub_genre", "TEXT", "NULL")

        # original_language backs the upload/edit form's "Original audio
        # language" field, used to label the video's own embedded audio
        # track when the source file has no language tag ffprobe can read
        # (the common case, and why tracks used to show up as "Unknown" in
        # the player's audio menu) — see app/worker/transcode.py.
        _add_column_if_missing(engine, "videos", "original_language", "VARCHAR(16)", "NULL")

        # moods backs the upload/edit form's mood checkboxes (e.g.
        # "Feel-good,Tense/Thrilling") and drives mood-based recommendations
        # — see app/recommendations.py.
        _add_column_if_missing(engine, "videos", "moods", "TEXT", "NULL")
    except Exception as exc:
        # Best-effort: don't crash boot over a migration hiccup, but at
        # least surface it instead of swallowing it silently — a silent
        # failure here just resurfaces later as a confusing UndefinedColumn
        # error somewhere downstream (e.g. during seeding).
        print(f"[migrate] lightweight migration step failed: {exc}")
