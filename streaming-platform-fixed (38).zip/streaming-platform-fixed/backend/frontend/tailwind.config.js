export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        canvas: '#07080f',
        surface: '#11131f',
        'surface-raised': '#191c2c',
        'surface-hover': '#22263a',
        brand: '#4ca5ff',
        violet: '#9b7bff',
        ink: '#f4f7ff',
        muted: '#9ba4bd',
        success: '#5cdd9d',
        danger: '#ff6b83',
      },
      fontFamily: {
        display: ['"Plus Jakarta Sans"', 'Inter', 'sans-serif'],
        body: ['Manrope', 'Inter', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
        hero: ['"Bebas Neue"', '"Archivo Black"', 'Impact', 'sans-serif'],
      },
      boxShadow: { glow: '0 0 42px rgba(76,165,255,.22)', panel: '0 24px 70px rgba(0,0,0,.32)' },
      borderRadius: { '4xl': '2rem' },
    },
  },
  plugins: [],
}
