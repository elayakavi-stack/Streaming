import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getPreferences, setPreference } from '../lib/preferences'
import Navbar from '../components/Navbar'

export default function Settings() {
  const navigate = useNavigate()
  const [prefs, setPrefs] = useState(getPreferences())
  const [saved, setSaved] = useState(false)

  function toggle(key) {
    const next = { ...prefs, [key]: !prefs[key] }
    setPreference(key, next[key])
    setPrefs(next)
    setSaved(true)
  }

  function save() {
    Object.entries(prefs).forEach(([key, value]) => {
      setPreference(key, value)
    })
    setSaved(true)
  }

  return (
    <div className="min-h-screen bg-void">
      <Navbar onAddTitle={() => navigate('/')} />

      <main className="mx-auto max-w-2xl px-6 py-12">
        <h1 className="marquee-heading text-2xl text-ivory">Settings</h1>
        <p className="mt-2 text-sm text-ash">Preferences are saved on this device.</p>

        <div className="sprocket-divider my-8" />

        <h2 className="marquee-heading text-lg text-ivory">Playback</h2>
        <div className="mt-4 flex flex-col divide-y divide-panel-raised rounded-lg border border-panel-raised bg-panel">
          <SettingRow label="Autoplay" description="Start playing as soon as a title opens" checked={prefs.autoplay} onChange={() => toggle('autoplay')} />
          <SettingRow label="Continue Watching" description="Remember where you left off and resume automatically" checked={prefs.trackProgress} onChange={() => toggle('trackProgress')} />
        </div>

        <div className="mt-6 flex items-center justify-between gap-4 rounded-lg border border-white/10 bg-panel p-4">
          <div>
            <p className="text-sm text-ash">Your playback choices will apply on this device.</p>
            {saved && <p className="mt-1 text-xs uppercase tracking-[0.18em] text-marquee">Saved</p>}
          </div>
          <button onClick={save} className="rounded-md bg-marquee px-4 py-2 text-sm font-semibold text-void transition hover:bg-marquee-dim">Save options</button>
        </div>
      </main>
    </div>
  )
}

function SettingRow({ label, description, checked, onChange }) {
  return (
    <div className="flex items-center justify-between gap-6 px-5 py-4">
      <div>
        <p className="text-sm font-medium text-ivory">{label}</p>
        <p className="mt-0.5 text-sm text-ash">{description}</p>
      </div>
      <button role="switch" aria-checked={checked} aria-label={label} onClick={onChange} className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${checked ? 'bg-marquee' : 'bg-panel-raised'}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-ivory transition-transform ${checked ? 'translate-x-5' : 'translate-x-0.5'}`} />
      </button>
    </div>
  )
}
