import { FiAlertTriangle, FiCheckCircle, FiClock, FiFilm, FiGrid, FiUploadCloud, FiUsers } from 'react-icons/fi'
import { Link } from 'react-router-dom'
import { useContentCatalog } from '@/features/discovery/queries'
import { Skeleton } from '@/components/ui/Skeleton'

export function AdminDashboardPage() {
  const { data, isPending } = useContentCatalog()
  const items = data?.data ?? []
  const total = data?.total ?? 0
  const ready = items.filter((item) => item.status === 'ready').length
  const processing = items.filter((item) => item.status === 'processing' || item.status === 'pending_upload').length
  const failed = items.filter((item) => item.status === 'failed').length

  const metrics = [
    { label: 'Catalog titles', value: total, icon: FiFilm },
    { label: 'Ready to stream', value: ready, icon: FiCheckCircle },
    { label: 'Processing', value: processing, icon: FiClock },
    { label: 'Failed', value: failed, icon: FiAlertTriangle },
  ]

  return <div className="mx-auto max-w-[1680px] px-4 py-8 sm:px-6 lg:px-10">
    <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-brand">Admin control room</p><h1 className="mt-2 font-display text-4xl font-black tracking-[-.05em]">Your content studio.</h1><p className="mt-2 text-sm text-muted">Upload titles and track their processing status.</p></div><div className="flex gap-2"><Link to="/admin/content" className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-surface px-4 py-3 text-sm font-black text-ink hover:border-brand/50"><FiGrid/> Manage content</Link><Link to="/admin/users" className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-surface px-4 py-3 text-sm font-black text-ink hover:border-brand/50"><FiUsers/> Manage users</Link><Link to="/admin/upload" className="inline-flex items-center justify-center gap-2 rounded-xl bg-brand px-4 py-3 text-sm font-black text-canvas"><FiUploadCloud/> Upload title</Link></div></div>
    <section className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {isPending
        ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32" />)
        : metrics.map(({ label, value, icon: Icon }) => <article key={label} className="rounded-2xl border border-white/10 bg-surface p-5 shadow-panel"><span className="grid h-10 w-10 place-items-center rounded-xl bg-brand/10 text-brand"><Icon/></span><p className="mt-5 font-display text-3xl font-black">{value}</p><p className="mt-1 text-sm text-muted">{label}</p></article>)}
    </section>
    {!isPending && total === 0 && <section className="mt-6 rounded-3xl border border-dashed border-white/15 bg-surface p-10 text-center"><FiUploadCloud className="mx-auto text-4xl text-brand"/><h2 className="mt-4 font-display text-2xl font-black">Your catalog is empty.</h2><p className="mx-auto mt-2 max-w-lg text-sm leading-6 text-muted">Create your first title with a video, poster thumbnail, backdrop, description, cast, and director.</p><Link to="/admin/upload" className="mt-6 inline-flex rounded-xl bg-brand px-4 py-3 text-sm font-black text-canvas">Open upload form</Link></section>}
    {!isPending && total > 0 && <section className="mt-6 rounded-3xl border border-white/10 bg-surface p-6"><div className="flex items-center justify-between"><h2 className="font-display text-xl font-bold">Recent uploads</h2><Link to="/admin/content" className="text-sm font-bold text-brand">View all content</Link></div><div className="mt-4 divide-y divide-white/10">{items.slice(0, 8).map((item) => <div key={item.id} className="flex items-center justify-between gap-4 py-3"><div><p className="text-sm font-bold">{item.title}</p><p className="text-xs text-muted">{item.releaseYear} · {item.genres.join(', ') || 'No genre'}</p></div><span className={`rounded-full px-2.5 py-1 text-xs font-bold ${item.status === 'ready' ? 'bg-success/15 text-success' : item.status === 'failed' ? 'bg-danger/15 text-danger' : 'bg-brand/15 text-brand'}`}>{item.status}</span></div>)}</div></section>}
  </div>
}
