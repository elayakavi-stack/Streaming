import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Film, Clock, CheckCircle2, LogOut, Bookmark } from 'lucide-react'
import { getMe, listVideos, getWatchlist, logout } from '../api/client'
import Navbar from '../components/Navbar'

export default function Profile() {
  const navigate = useNavigate()
  const [user, setUser] = useState(null)
  const [videos, setVideos] = useState([])
  const [watchlist, setWatchlist] = useState([])

  useEffect(() => {
    getMe().then(setUser).catch(() => {})
    listVideos().then(setVideos).catch(() => {})
    getWatchlist().then(setWatchlist).catch(() => {})
  }, [])

  const ready = videos.filter((v) => v.status === 'ready').length
  const processing = videos.filter((v) => v.status === 'processing' || v.status === 'pending_upload').length

  function handleLogout() {
    logout()
    navigate('/login')
  }

  const memberSince = user?.created_at
    ? new Date(user.created_at).toLocaleDateString(undefined, { year: 'numeric', month: 'long' })
    : null

  return (
    <div className="min-h-screen bg-void">
      <Navbar onAddTitle={() => navigate('/')} />

      <main className="mx-auto max-w-4xl px-6 py-12">
        <div className="rounded-[24px] border border-white/10 bg-gradient-to-r from-[#13212b] to-[#0f171e] p-6">
          <div className="flex items-center gap-5">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-panel-raised font-display text-3xl text-marquee">
              {user?.email ? user.email[0].toUpperCase() : '…'}
            </div>
            <div>
              <h1 className="marquee-heading text-2xl text-ivory">{user?.email || 'Loading…'}</h1>
              {memberSince && <p className="mt-1 text-sm text-ash">Member since {memberSince}</p>}
            </div>
          </div>

          <div className="sprocket-divider my-8" />

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
            <StatCard icon={Film} label="Total titles" value={videos.length} accent="text-marquee" />
            <StatCard icon={CheckCircle2} label="Ready to watch" value={ready} accent="text-moss" />
            <StatCard icon={Clock} label="Processing" value={processing} accent="text-plum" />
            <StatCard icon={Bookmark} label="Saved" value={watchlist.length} accent="text-ivory" />
          </div>
        </div>

        <div className="sprocket-divider my-8" />

        <button
          onClick={handleLogout}
          className="flex items-center gap-2 rounded-md border border-panel-raised px-4 py-2.5 text-sm text-ash transition-colors hover:border-reel hover:text-reel"
        >
          <LogOut size={16} />
          Sign out
        </button>
      </main>
    </div>
  )
}

function StatCard({ icon: Icon, label, value, accent }) {
  return (
    <div className="rounded-lg border border-panel-raised bg-panel p-5">
      <Icon size={20} className={accent} />
      <p className="marquee-heading mt-3 text-3xl text-ivory">{value}</p>
      <p className="mt-1 font-mono text-xs uppercase tracking-wide text-ash">{label}</p>
    </div>
  )
}
