import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { getHome, getContinueWatching, getWatchlist } from '../api/client'
import Navbar from '../components/Navbar'
import HeroBanner from '../components/HeroBanner'
import VideoRow from '../components/VideoRow'
import UploadModal from '../components/UploadModal'

export default function Home() {
  const location = useLocation()
  const navigate = useNavigate()
  const [rails, setRails] = useState([])
  const [continueWatching, setContinueWatching] = useState([])
  const [watchlist, setWatchlist] = useState([])
  const [loading, setLoading] = useState(true)
  const [showUpload, setShowUpload] = useState(false)

  async function refresh() {
    try {
      const [homeRails, continueData, watchlistData] = await Promise.all([
        getHome(),
        getContinueWatching(),
        getWatchlist(),
      ])
      setRails(homeRails)
      setContinueWatching(continueData)
      setWatchlist(watchlistData)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
    const interval = setInterval(refresh, 10000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (!location.state?.openUpload) return
    setShowUpload(true)
    navigate(location.pathname, { replace: true, state: null })
  }, [location.pathname, location.state, navigate])

  const featured = rails.flatMap((rail) => rail.items).find((item) => item.status === 'ready') || null

  return (
    <div className="min-h-screen bg-void">
      <Navbar onAddTitle={() => setShowUpload(true)} />
      <HeroBanner video={featured} videos={rails.flatMap((rail) => rail.items).filter((item) => item.status === 'ready')} />

      <main id="library" className="mx-auto max-w-[1440px] py-8">
        {loading ? (
          <p className="px-6 text-ash">Loading your stream deck…</p>
        ) : rails.length === 0 ? (
          <div className="mx-4 rounded-xl border border-white/10 bg-panel/50 px-6 py-16 text-center md:mx-6">
            <p className="marquee-heading text-2xl text-ivory">Your watchlist starts here</p>
            <p className="mt-2 text-ash">Add your first title to begin streaming.</p>
          </div>
        ) : (
          <>
            {continueWatching.length > 0 && (
              <div id="continue-watching">
                <VideoRow title="Continue watching" videos={continueWatching} accent="text-ivory" onDeleted={refresh} />
              </div>
            )}

            {watchlist.length > 0 && (
              <VideoRow title="My watchlist" videos={watchlist} accent="text-ivory" onDeleted={refresh} />
            )}

            {rails.map((rail) => (
              <VideoRow key={rail.key} title={rail.title} videos={rail.items} accent="text-ivory" onDeleted={refresh} />
            ))}
          </>
        )}
      </main>

      {showUpload && <UploadModal onClose={() => setShowUpload(false)} onUploaded={refresh} />}
    </div>
  )
}
