import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { FiImage, FiMusic, FiMessageSquare, FiPlus, FiTrash2, FiUploadCloud, FiVideo } from 'react-icons/fi'
import { Button } from '@/components/ui/Button'
import { contentApi } from '@/services/content-api'
import { COMMON_GENRES, COMMON_MOODS } from '@/constants/genres'

type PendingAudioTrack = { key: string; file: File | null; language: string; label: string; isDefault: boolean }
type PendingSubtitle = { key: string; file: File | null; language: string; label: string; isDefault: boolean }

let rowKeySeq = 0
const nextRowKey = () => `row-${(rowKeySeq += 1)}`

export function UploadTitlePage() {
  const navigate = useNavigate()
  const [status, setStatus] = useState('')
  const [error, setError] = useState('')
  const [video, setVideo] = useState<File | null>(null)
  const [poster, setPoster] = useState<File | null>(null)
  const [backdrop, setBackdrop] = useState<File | null>(null)
  const [form, setForm] = useState({
    title: '', description: '', category: 'Movie', genre: 'Drama', subGenre: '',
    rating: 'U/A 13+', releaseYear: new Date().getFullYear(), castMembers: '', director: '',
    originalLanguage: '',
  })
  const set = (key: keyof typeof form, value: string | number) => setForm({ ...form, [key]: value })
  const [moods, setMoods] = useState<string[]>([])
  const toggleMood = (mood: string) => setMoods((current) => (current.includes(mood) ? current.filter((m) => m !== mood) : [...current, mood]))

  // Extra dub/audio-track files (e.g. a standalone Hindi audio track for an
  // English video) and subtitle files, staged here and uploaded once the
  // video record exists — the transcode job only gets queued after all of
  // these have made it to the video, so every language is picked up in the
  // same processing pass. See app/worker/transcode.py:transcode_to_hls.
  const [audioTracks, setAudioTracks] = useState<PendingAudioTrack[]>([])
  const [subtitleTracks, setSubtitleTracks] = useState<PendingSubtitle[]>([])

  const addAudioRow = () => setAudioTracks((rows) => [...rows, { key: nextRowKey(), file: null, language: '', label: '', isDefault: rows.length === 0 }])
  const updateAudioRow = (key: string, patch: Partial<PendingAudioTrack>) => setAudioTracks((rows) => rows.map((row) => (row.key === key ? { ...row, ...patch } : row)))
  const removeAudioRow = (key: string) => setAudioTracks((rows) => rows.filter((row) => row.key !== key))

  const addSubtitleRow = () => setSubtitleTracks((rows) => [...rows, { key: nextRowKey(), file: null, language: '', label: '', isDefault: rows.length === 0 }])
  const updateSubtitleRow = (key: string, patch: Partial<PendingSubtitle>) => setSubtitleTracks((rows) => rows.map((row) => (row.key === key ? { ...row, ...patch } : row)))
  const removeSubtitleRow = (key: string) => setSubtitleTracks((rows) => rows.filter((row) => row.key !== key))

  async function submit(event: React.FormEvent) {
    event.preventDefault()
    if (!video) { setError('Choose a video file first.'); return }
    const incompleteAudio = audioTracks.find((row) => !row.file || !row.language.trim() || !row.label.trim())
    if (incompleteAudio) { setError('Every audio track row needs a file, language code, and label — or remove the row.'); return }
    const incompleteSubtitle = subtitleTracks.find((row) => !row.file || !row.language.trim() || !row.label.trim())
    if (incompleteSubtitle) { setError('Every subtitle row needs a file, language code, and label — or remove the row.'); return }

    setStatus('Uploading artwork…')
    setError('')
    try {
      const posterUrl = poster ? await contentApi.uploadArtwork(poster, 'poster') : undefined
      const backdropUrl = backdrop ? await contentApi.uploadArtwork(backdrop, 'backdrop') : undefined

      setStatus('Creating title…')
      const { videoId, uploadUrl } = await contentApi.createVideoRecord({
        ...form, moods, posterUrl, backdropUrl, filename: video.name, contentType: video.type || 'video/mp4',
      })

      setStatus('Uploading video to S3…')
      await contentApi.uploadRawFile(uploadUrl, video)

      for (let i = 0; i < audioTracks.length; i += 1) {
        const row = audioTracks[i]
        setStatus(`Uploading audio track ${i + 1}/${audioTracks.length} (${row.label})…`)
        await contentApi.addAudioTrack(videoId, { language: row.language.trim(), label: row.label.trim(), isDefault: row.isDefault, file: row.file as File })
      }

      for (let i = 0; i < subtitleTracks.length; i += 1) {
        const row = subtitleTracks[i]
        setStatus(`Uploading subtitle ${i + 1}/${subtitleTracks.length} (${row.label})…`)
        await contentApi.addSubtitle(videoId, { language: row.language.trim(), label: row.label.trim(), isDefault: row.isDefault, file: row.file as File })
      }

      setStatus('Queueing HLS processing…')
      await contentApi.completeUpload(videoId)
      setStatus('Queued for HLS processing.')
      navigate(`/title/${videoId}`)
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Upload failed')
      setStatus('')
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
      <p className="text-xs font-bold uppercase tracking-[.2em] text-brand">Content management</p>
      <h1 className="mt-2 font-display text-4xl font-black tracking-[-.05em]">Upload a title</h1>
      <p className="mt-3 text-muted">Add your video and artwork, then fill in the details below — processing starts automatically after upload.</p>
      <form onSubmit={submit} className="mt-8 grid gap-5 rounded-3xl border border-white/10 bg-surface p-5 sm:grid-cols-2 sm:p-7">
        <Field label="Title"><input required value={form.title} onChange={(e) => set('title', e.target.value)} className="input" /></Field>
        <Field label="Release year"><input required type="number" value={form.releaseYear} onChange={(e) => set('releaseYear', Number(e.target.value))} className="input" /></Field>
        <Field label="Category">
          <select value={form.category} onChange={(e) => set('category', e.target.value)} className="input">
            <option>Movie</option><option>TV Show</option><option>Sports</option><option>Original</option>
          </select>
        </Field>
        <Field label="Maturity rating"><input required value={form.rating} onChange={(e) => set('rating', e.target.value)} className="input" /></Field>
        <Field label="Main genre">
          <select required value={form.genre} onChange={(e) => set('genre', e.target.value)} className="input">
            <option value="" disabled>Choose one genre…</option>
            {COMMON_GENRES.map((g) => <option key={g} value={g}>{g}</option>)}
          </select>
          <span className="mt-1 block text-xs font-normal text-muted">Decides which genre row the title shows up in on the home page (e.g. "Action Movies"). One genre only — pick the closer secondary genre below rather than combining two here (e.g. "Action, Thriller"), which would fragment the title across mismatched rails instead of landing cleanly in one.</span>
        </Field>
        <Field label="Sub-genre">
          <select value={form.subGenre} onChange={(e) => set('subGenre', e.target.value)} className="input">
            <option value="">None</option>
            {COMMON_GENRES.filter((g) => g !== form.genre).map((g) => <option key={g} value={g}>{g}</option>)}
          </select>
          <span className="mt-1 block text-xs font-normal text-muted">Optional. A secondary tag also used for search, filtering, and recommendations.</span>
        </Field>
        <Field label="Director"><input value={form.director} onChange={(e) => set('director', e.target.value)} className="input" /></Field>
        <Field label="Cast"><input value={form.castMembers} onChange={(e) => set('castMembers', e.target.value)} className="input" placeholder="Name One, Name Two" /></Field>
        <Field label="Video file">
          <Upload icon={<FiVideo />} accept="video/*" file={video} setFile={setVideo} />
          <span className="mt-1 block text-xs font-normal text-muted">Automatically transcoded into 360p, 720p, and 1080p HLS renditions — viewers get a quality picker either way.</span>
        </Field>
        <Field label="Original audio language">
          <input value={form.originalLanguage} onChange={(e) => set('originalLanguage', e.target.value)} className="input" placeholder="Language code (e.g. en, te)" />
          <span className="mt-1 block text-xs font-normal text-muted">Most video files don't tag the language of their own audio, so without this it shows up as "Unknown" in the audio menu instead of the real language.</span>
        </Field>
        <Field label="Moods">
          <div className="flex flex-wrap gap-2">
            {COMMON_MOODS.map((mood) => (
              <button
                key={mood}
                type="button"
                onClick={() => toggleMood(mood)}
                className={`rounded-full border px-3 py-1.5 text-xs font-bold transition ${moods.includes(mood) ? 'border-brand bg-brand/15 text-brand' : 'border-white/10 text-muted hover:text-ink'}`}
              >
                {mood}
              </button>
            ))}
          </div>
          <span className="mt-1 block text-xs font-normal text-muted">Powers "More like this mood" recommendations while watching, and a mood-based home rail — separate from genre, which is about subject matter rather than how a title feels.</span>
        </Field>
        <div className="sm:col-span-2"><Field label="Description"><textarea required value={form.description} onChange={(e) => set('description', e.target.value)} className="input min-h-28" /></Field></div>
        <Field label="Poster thumbnail"><Upload icon={<FiImage />} accept="image/jpeg,image/png,image/webp" file={poster} setFile={setPoster} /></Field>
        <Field label="Backdrop image"><Upload icon={<FiImage />} accept="image/jpeg,image/png,image/webp" file={backdrop} setFile={setBackdrop} /></Field>

        <div className="sm:col-span-2">
          <TrackSection
            icon={<FiMusic />}
            title="Additional audio tracks"
            hint="Optional. Add a separate audio file per dub — e.g. a standalone Hindi track for an English video. If the video file itself already has more than one audio stream, that's picked up automatically too."
            rows={audioTracks}
            fileAccept="audio/*"
            filePlaceholder="Choose audio file"
            languagePlaceholder="Language code (e.g. hi)"
            labelPlaceholder="Label (e.g. Hindi)"
            onAdd={addAudioRow}
            onUpdate={updateAudioRow}
            onRemove={removeAudioRow}
            addLabel="Add audio track"
          />
        </div>

        <div className="sm:col-span-2">
          <TrackSection
            icon={<FiMessageSquare />}
            title="Subtitles"
            hint="Optional. Add a WebVTT (.vtt) file per language."
            rows={subtitleTracks}
            fileAccept=".vtt,text/vtt"
            filePlaceholder="Choose .vtt file"
            languagePlaceholder="Language code (e.g. en)"
            labelPlaceholder="Label (e.g. English)"
            onAdd={addSubtitleRow}
            onUpdate={updateSubtitleRow}
            onRemove={removeSubtitleRow}
            addLabel="Add subtitle"
          />
        </div>

        {error && <p className="sm:col-span-2 text-sm font-bold text-danger">{error}</p>}
        {status && <p className="sm:col-span-2 text-sm font-bold text-brand">{status}</p>}
        <div className="sm:col-span-2"><Button type="submit" disabled={Boolean(status)}><FiUploadCloud /> {status || 'Upload title'}</Button></div>
      </form>
    </div>
  )
}
function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="block text-sm font-bold">{label}<span className="mt-2 block">{children}</span></label> }
function Upload({ icon, accept, file, setFile }: { icon: React.ReactNode; accept: string; file: File | null; setFile: (file: File | null) => void }) { return <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-white/20 bg-canvas px-3 py-3 text-muted hover:border-brand"><span className="text-brand">{icon}</span><span className="truncate text-sm">{file?.name || 'Choose file'}</span><input className="hidden" type="file" accept={accept} onChange={(e) => setFile(e.target.files?.[0] ?? null)} /></label> }

type PendingTrackRow = { key: string; file: File | null; language: string; label: string; isDefault: boolean }

function TrackSection({
  icon, title, hint, rows, fileAccept, filePlaceholder, languagePlaceholder, labelPlaceholder, addLabel, onAdd, onUpdate, onRemove,
}: {
  icon: React.ReactNode
  title: string
  hint: string
  rows: PendingTrackRow[]
  fileAccept: string
  filePlaceholder: string
  languagePlaceholder: string
  labelPlaceholder: string
  addLabel: string
  onAdd: () => void
  onUpdate: (key: string, patch: Partial<PendingTrackRow>) => void
  onRemove: (key: string) => void
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-canvas p-4">
      <h3 className="flex items-center gap-2 text-sm font-bold text-ink"><span className="text-brand">{icon}</span>{title}</h3>
      <p className="mt-1 text-xs text-muted">{hint}</p>
      {rows.length > 0 && (
        <div className="mt-3 space-y-3">
          {rows.map((row) => (
            <div key={row.key} className="rounded-xl border border-white/10 bg-surface p-3">
              <div className="flex items-center gap-3">
                <label className="flex flex-1 cursor-pointer items-center gap-2 truncate rounded-lg border border-dashed border-white/20 px-3 py-2 text-xs text-muted hover:border-brand">
                  <span className="truncate">{row.file?.name || filePlaceholder}</span>
                  <input className="hidden" type="file" accept={fileAccept} onChange={(e) => onUpdate(row.key, { file: e.target.files?.[0] ?? null })} />
                </label>
                <button type="button" onClick={() => onRemove(row.key)} aria-label="Remove" className="shrink-0 rounded-lg p-2 text-muted hover:bg-white/10 hover:text-danger"><FiTrash2 size={15} /></button>
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <input value={row.label} onChange={(e) => onUpdate(row.key, { label: e.target.value })} placeholder={labelPlaceholder} className="input" />
                <input value={row.language} onChange={(e) => onUpdate(row.key, { language: e.target.value })} placeholder={languagePlaceholder} className="input" />
              </div>
              <label className="mt-2 flex w-fit items-center gap-1.5 text-xs font-bold text-muted">
                <input type="checkbox" checked={row.isDefault} onChange={(e) => onUpdate(row.key, { isDefault: e.target.checked })} /> Default
              </label>
            </div>
          ))}
        </div>
      )}
      <button type="button" onClick={onAdd} className="mt-3 flex items-center gap-1.5 rounded-xl border border-white/10 px-3 py-2 text-xs font-bold text-muted hover:border-brand hover:text-ink">
        <FiPlus size={14} /> {addLabel}
      </button>
    </div>
  )
}
