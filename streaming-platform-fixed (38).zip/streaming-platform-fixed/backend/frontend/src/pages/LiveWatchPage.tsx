import { useNavigate, useParams } from 'react-router-dom'
import { FiArrowLeft, FiRadio } from 'react-icons/fi'
import { OttPlayer } from '@/components/player/OttPlayer'
import { Skeleton } from '@/components/ui/Skeleton'
import { useLiveStream } from '@/features/live/queries'

export function LiveWatchPage() {
  const { id = '' } = useParams()
  const navigate = useNavigate()
  // Poll while watching so the page reacts on its own once the broadcaster ends the stream.
  const { data: stream, isPending, isError } = useLiveStream(id, { poll: true })

  if (isPending) {
    return (
      <div className="mx-auto max-w-[1680px] px-4 py-6 sm:px-6 lg:px-10">
        <Skeleton className="aspect-video w-full" />
      </div>
    )
  }

  if (isError || !stream) {
    return (
      <div className="grid min-h-[70vh] place-items-center px-6 text-center">
        <div>
          <h1 className="font-display text-3xl font-black">This broadcast isn't available.</h1>
          <button onClick={() => navigate('/')} className="mt-5 rounded-xl bg-brand px-4 py-2 font-bold text-canvas">Back to home</button>
        </div>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-[1680px] px-4 py-6 sm:px-6 lg:px-10">
      <button onClick={() => navigate('/')} className="mb-4 inline-flex items-center gap-2 text-sm font-bold text-muted hover:text-ink">
        <FiArrowLeft /> Back to home
      </button>

      {stream.status === 'live' ? (
        <OttPlayer src={stream.hlsUrl} poster={stream.posterUrl} isLive autoPlay />
      ) : (
        <div className="grid aspect-video place-items-center rounded-2xl border border-white/10 bg-surface text-center">
          <div>
            <h2 className="font-display text-2xl font-black">
              {stream.status === 'ended' ? 'This broadcast has ended.' : "This broadcast hasn't started yet."}
            </h2>
            <p className="mt-2 text-muted">
              {stream.status === 'ended' ? 'Check back for the next live stream.' : 'Hang tight — it will start playing automatically.'}
            </p>
          </div>
        </div>
      )}

      <div className="mt-6">
        <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[.2em] text-brand">
          {stream.status === 'live' ? <><FiRadio /> Live now</> : 'Live broadcast'}
        </p>
        <h1 className="mt-2 font-display text-3xl font-black tracking-[-.04em] sm:text-4xl">{stream.title}</h1>
        {stream.ownerEmail && <p className="mt-2 text-sm text-muted">Hosted by {stream.ownerEmail}</p>}
        <p className="mt-3 max-w-3xl leading-7 text-muted">{stream.description || 'No description provided.'}</p>
      </div>
    </div>
  )
}
