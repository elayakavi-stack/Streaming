import { useEffect, useRef, useState } from 'react'
import { FiRadio, FiSquare, FiClock, FiLock, FiCopy, FiCheck, FiVideo, FiExternalLink, FiImage, FiUploadCloud } from 'react-icons/fi'
import { Button } from '@/components/ui/Button'
import {
  useCreateLiveStream,
  useEndLiveStream,
  useStartLiveStream,
  useStreamAccess,
  useRequestStreamAccess,
  useLiveIngest,
  useLiveStream,
  useSetLiveThumbnail,
} from '@/features/live/queries'
import { liveApi } from '@/services/live-api'
import { useBroadcastStore } from '@/features/live/broadcastStore'

/** Gate: only admin-approved broadcasters (or admins) see the studio —
 * everyone else gets a request-access screen. */
export function GoLivePage() {
  const { data: access, isPending } = useStreamAccess()

  if (isPending) return null
  if (!access?.canStream) return <StreamAccessGate requestedAt={access?.streamRequestedAt} />

  return <BroadcastStudio />
}

function StreamAccessGate({ requestedAt }: { requestedAt?: string }) {
  const requestAccess = useRequestStreamAccess()
  const pending = Boolean(requestedAt) || requestAccess.isSuccess

  return (
    <div className="mx-auto max-w-lg px-4 py-16 text-center sm:px-6">
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-surface text-brand">
        <FiLock size={22} />
      </div>
      <h1 className="mt-5 font-display text-3xl font-black tracking-[-.05em]">Go live</h1>
      {pending ? (
        <p className="mt-3 text-muted">
          <FiClock className="mb-0.5 inline" /> Your request to broadcast is waiting on an admin to approve
          it. You'll be able to go live as soon as it's approved.
        </p>
      ) : (
        <>
          <p className="mt-3 text-muted">
            Live streaming is available to admin-approved broadcasters. Request access and an admin will
            review it shortly.
          </p>
          <Button onClick={() => requestAccess.mutate()} disabled={requestAccess.isPending} className="mt-6">
            <FiRadio /> {requestAccess.isPending ? 'Requesting…' : 'Request streaming access'}
          </Button>
          {requestAccess.isError && (
            <p className="mt-3 text-sm font-bold text-danger">
              {requestAccess.error instanceof Error ? requestAccess.error.message : 'Could not send your request.'}
            </p>
          )}
        </>
      )}
    </div>
  )
}

function CopyField({ label, value }: { label: string; value: string }) {
  const [copied, setCopied] = useState(false)

  async function copy() {
    try {
      await navigator.clipboard.writeText(value)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      // Clipboard access can fail (permissions, insecure context); the value is still visible to copy by hand.
    }
  }

  return (
    <label className="block text-sm font-bold">
      {label}
      <div className="mt-2 flex items-center gap-2">
        <input readOnly value={value} className="input flex-1 font-mono text-sm" onFocus={(e) => e.target.select()} />
        <button
          type="button"
          onClick={copy}
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-white/10 text-muted hover:border-brand/40 hover:text-ink"
          aria-label={`Copy ${label}`}
        >
          {copied ? <FiCheck className="text-brand" /> : <FiCopy />}
        </button>
      </div>
    </label>
  )
}

function CameraPreview({ stream }: { stream: MediaStream | null }) {
  const videoRef = useRef<HTMLVideoElement | null>(null)

  useEffect(() => {
    if (videoRef.current) videoRef.current.srcObject = stream
  }, [stream])

  if (!stream) return null
  return <video ref={videoRef} autoPlay muted playsInline className="h-full w-full object-cover" />
}

/** Thumbnail control used both during setup (before a broadcast exists —
 * uploads straight to S3 and hands back a URL) and once it exists (uploads
 * + immediately saves via PATCH .../thumbnail). Either way it's a manual
 * override: once set, the auto-capture job (grabbing a frame from the live
 * feed itself) leaves this broadcast's thumbnail alone. */
function ThumbnailPicker({
  posterUrl,
  onUploaded,
  isSaving,
  autoCaptured,
}: {
  posterUrl: string
  onUploaded: (file: File) => void
  isSaving?: boolean
  autoCaptured?: boolean
}) {
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [error, setError] = useState('')

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (!file.type.startsWith('image/')) {
      setError('Please choose an image file.')
      return
    }
    setError('')
    onUploaded(file)
  }

  return (
    <div>
      <div className="flex items-center gap-3">
        <div className="grid h-14 w-24 shrink-0 place-items-center overflow-hidden rounded-lg border border-white/10 bg-canvas text-muted">
          {posterUrl ? (
            <img src={posterUrl} alt="" className="h-full w-full object-cover" onError={(e) => (e.currentTarget.style.display = 'none')} />
          ) : (
            <FiImage size={18} />
          )}
        </div>
        <div className="flex-1">
          <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={isSaving}
            className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-canvas px-3 py-2 text-xs font-bold text-ink hover:border-brand/40 disabled:opacity-60"
          >
            <FiUploadCloud /> {isSaving ? 'Uploading…' : posterUrl ? 'Change thumbnail' : 'Upload thumbnail'}
          </button>
          <span className="mt-1 block text-xs text-muted">
            {autoCaptured
              ? "Auto-picked from your stream — upload your own to override it."
              : 'Shown as your broadcast\'s cover image in the "Live now" rail.'}
          </span>
        </div>
      </div>
      {error && <p className="mt-2 text-xs font-bold text-danger">{error}</p>}
    </div>
  )
}

// Refreshing this page shouldn't lose track of an in-progress broadcast —
// for the 'external' (OBS/ffmpeg) mode the server-side stream keeps running
// regardless (the encoder doesn't know or care that this tab reloaded), so
// without this the page would show the "create a new broadcast" form again
// while the old stream is still live, orphaning it (and its stream key)
// with no way back to it from this UI. For 'camera' mode the broadcast
// itself *does* live in this tab (getUserMedia + the WebRTC/WHIP
// connection can't survive a reload), so we additionally remember that we
// were broadcasting from the camera and auto-reconnect below instead of
// making the person click "Start broadcasting" all over again.
const STREAM_ID_STORAGE_KEY = 'goLiveStreamId'
const MODE_STORAGE_KEY = 'goLiveMode'
const WAS_BROADCASTING_KEY = 'goLiveWasBroadcasting'

function BroadcastStudio() {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  // Shown as the card thumbnail in the "Live now" rail (home page + sports
  // page) and as the <video> poster while the stream is loading/paused.
  // Without one, viewers just see a generic radio-wave icon in the rail.
  const [posterUrl, setPosterUrl] = useState('')
  const [uploadingSetupThumbnail, setUploadingSetupThumbnail] = useState(false)
  const [streamId, setStreamId] = useState<string | null>(() => localStorage.getItem(STREAM_ID_STORAGE_KEY))
  const [error, setError] = useState('')
  // 'camera' broadcasts straight from this device over WebRTC/WHIP — no
  // external software needed. 'external' shows the RTMP server + stream key
  // for OBS/ffmpeg/etc, for anyone who'd rather use dedicated software.
  const [mode, setMode] = useState<'camera' | 'external'>(
    () => (localStorage.getItem(MODE_STORAGE_KEY) as 'camera' | 'external' | null) ?? 'camera',
  )
  // Whether this tab was actively broadcasting from the camera before a
  // *full page reload* — used once, right after mount, to auto-resume.
  // (Simply navigating to another page in the app, as opposed to reloading
  // the browser tab, never needs this: the camera connection itself lives
  // in features/live/broadcastStore.ts, outside this page's component
  // tree, so it's untouched by this page unmounting.)
  const resumeCameraOnLoad = useRef(mode === 'camera' && localStorage.getItem(WAS_BROADCASTING_KEY) === '1')

  const createStream = useCreateLiveStream()
  const endStream = useEndLiveStream()
  const startStream = useStartLiveStream()
  const setThumbnail = useSetLiveThumbnail()
  const ingest = useLiveIngest(streamId)
  // Selected individually (rather than as one object) so this component
  // only re-renders for the fields it actually reads, same as any other
  // Zustand usage — the plain `camera` object below is just a local,
  // per-render convenience wrapper around them.
  const cameraState = useBroadcastStore((s) => s.cameraState)
  const cameraError = useBroadcastStore((s) => s.cameraError)
  const previewStream = useBroadcastStore((s) => s.previewStream)
  const startCamera = useBroadcastStore((s) => s.startCamera)
  const stopCamera = useBroadcastStore((s) => s.stopCamera)
  const camera = { state: cameraState, error: cameraError, previewStream, start: startCamera, stop: stopCamera }
  // Poll once the stream exists: flips to 'live' on its own as soon as a
  // publisher (this device's camera, or OBS/ffmpeg) starts sending media
  // and the RTMP server's webhook confirms it.
  const { data: stream, isError: streamLoadError } = useLiveStream(streamId ?? '', { poll: Boolean(streamId) })

  const phase = !streamId ? 'setup' : stream?.status === 'live' ? 'live' : stream?.status === 'ended' ? 'ended' : 'waiting'

  // The backend normally only flips a stream to 'live' once MediaMTX's
  // runOnReady webhook confirms media is flowing — but that webhook
  // depends on MediaMTX being configured correctly outside this app (right
  // hook names for the installed MediaMTX version, matching secret, and so
  // on), so a misconfiguration there would otherwise leave the camera
  // connected and streaming while this page sits on "Connecting to the
  // streaming server…" forever. For the in-browser camera path we already
  // know, from this tab's own WebRTC connection, the instant the broadcast
  // actually reaches the streaming server — so confirm "live" with the
  // backend directly instead of waiting on the webhook.
  const confirmedLiveFor = useRef<string | null>(null)
  useEffect(() => {
    if (mode !== 'camera' || camera.state !== 'live' || !streamId) return
    if (stream?.status === 'live' || stream?.status === 'ended') return
    if (confirmedLiveFor.current === streamId) return
    confirmedLiveFor.current = streamId
    startStream.mutate(streamId)
  }, [mode, camera.state, streamId, stream?.status])

  function setStream(id: string | null) {
    setStreamId(id)
    if (id) localStorage.setItem(STREAM_ID_STORAGE_KEY, id)
    else localStorage.removeItem(STREAM_ID_STORAGE_KEY)
  }

  function setPersistedMode(next: 'camera' | 'external') {
    setMode(next)
    localStorage.setItem(MODE_STORAGE_KEY, next)
  }

  // Automatically pick the broadcast back up after a reload instead of
  // asking the person to start a brand-new stream — as long as the server
  // still considers this stream live (i.e. it wasn't ended in the
  // meantime), reacquire the camera and reconnect over WHIP using the same
  // stream key the moment the ingest details are back.
  useEffect(() => {
    if (!resumeCameraOnLoad.current) return
    if (!ingest.data || camera.state !== 'idle') return
    if (phase === 'ended') {
      resumeCameraOnLoad.current = false
      return
    }
    if (phase === 'live' || phase === 'waiting') {
      resumeCameraOnLoad.current = false
      camera.start(ingest.data.whipUrl)
    }
  }, [ingest.data, camera.state, phase])

  // Remember (only) while actually broadcasting from the camera, so a
  // reload knows whether to auto-resume.
  useEffect(() => {
    if (mode === 'camera' && camera.state === 'live') {
      localStorage.setItem(WAS_BROADCASTING_KEY, '1')
    } else if (camera.state === 'idle') {
      localStorage.removeItem(WAS_BROADCASTING_KEY)
    }
  }, [mode, camera.state])

  // Note: the "warn before an accidental refresh/close" listener lives in
  // broadcastStore.ts itself (registered when the camera goes live, removed
  // when it stops) rather than here, since the camera connection — and the
  // need to guard it — outlives this particular page being mounted.

  function startNewBroadcast() {
    resumeCameraOnLoad.current = false
    localStorage.removeItem(WAS_BROADCASTING_KEY)
    setTitle('')
    setDescription('')
    setPosterUrl('')
    setStream(null)
  }

  async function createBroadcast() {
    if (!title.trim()) {
      setError('Give your stream a title.')
      return
    }
    setError('')
    try {
      const created = await createStream.mutateAsync({
        title: title.trim(),
        description: description.trim() || undefined,
        posterUrl: posterUrl.trim() || undefined,
      })
      setStream(created.id)
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Could not create the broadcast. Please try again.')
    }
  }

  // Before the broadcast exists there's no stream id to PATCH yet, so this
  // just uploads the image and stashes the resulting URL in local state —
  // createBroadcast() above sends it along when the stream is created.
  async function uploadSetupThumbnail(file: File) {
    setUploadingSetupThumbnail(true)
    setError('')
    try {
      const assetUrl = await liveApi.uploadThumbnail(file)
      setPosterUrl(assetUrl)
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Could not upload that image. Please try again.')
    } finally {
      setUploadingSetupThumbnail(false)
    }
  }

  async function stopStream() {
    resumeCameraOnLoad.current = false
    localStorage.removeItem(WAS_BROADCASTING_KEY)
    if (camera.state !== 'idle') await camera.stop()
    if (streamId) await endStream.mutateAsync(streamId).catch(() => undefined)
    setStream(null)
  }

  useEffect(() => {
    if (streamLoadError) setStream(null)
  }, [streamLoadError])

  // If the broadcast ends (or is kicked) from elsewhere — the dashboard,
  // an admin, MediaMTX itself — stop holding the camera open in this tab.
  useEffect(() => {
    if (stream?.status === 'ended' && camera.state !== 'idle') camera.stop()
  }, [stream?.status])

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
      <p className="text-xs font-bold uppercase tracking-[.2em] text-brand">Broadcast</p>
      <h1 className="mt-2 font-display text-4xl font-black tracking-[-.05em]">Go live</h1>
      <p className="mt-3 text-muted">
        Broadcast straight from your camera — no extra software needed — or use OBS Studio (or any other
        RTMP-capable software) if you'd rather. Once you go live, viewers can find your broadcast on the home
        page under "Live now".
      </p>

      <div className="mt-8 grid gap-6 sm:grid-cols-[1.4fr_1fr]">
        <div>
          <div className="relative flex aspect-video flex-col items-center justify-center gap-3 overflow-hidden rounded-2xl bg-black text-center shadow-panel">
            {phase === 'live' && (
              <span className="absolute left-3 top-3 z-10 flex items-center gap-1.5 rounded-full bg-danger px-2.5 py-1 text-xs font-black text-white">
                <FiRadio /> LIVE
              </span>
            )}
            {mode === 'camera' && camera.previewStream && <CameraPreview stream={camera.previewStream} />}
            {phase === 'setup' && (
              <p className="max-w-xs px-4 text-sm text-muted">
                Give your broadcast a title, then we'll get everything ready for you to go live.
              </p>
            )}
            {phase !== 'setup' && mode === 'camera' && !camera.previewStream && (
              <>
                <FiVideo className="text-2xl text-brand" />
                <p className="max-w-xs px-4 text-sm font-bold text-ink">
                  {camera.state === 'starting' ? 'Starting your camera…' : 'Ready to broadcast from this device.'}
                </p>
                <p className="max-w-xs px-4 text-sm text-muted">Click "Start broadcasting" to go live from your camera.</p>
              </>
            )}
            {phase === 'waiting' && mode === 'camera' && camera.previewStream && (
              <p className="absolute bottom-3 left-3 right-3 text-xs font-bold text-white/80">Connecting to the streaming server…</p>
            )}
            {phase === 'waiting' && mode === 'external' && (
              <>
                <FiRadio className="animate-pulse text-2xl text-brand" />
                <p className="max-w-xs px-4 text-sm font-bold text-ink">Waiting for your stream to connect…</p>
                <p className="max-w-xs px-4 text-sm text-muted">
                  Paste the server address and stream key into OBS, then click "Start Streaming" there. This
                  page updates automatically once we detect your feed.
                </p>
              </>
            )}
            {phase === 'ended' && (
              <div>
                <p className="font-display text-xl font-black text-ink">Stream ended</p>
                <p className="mt-1 text-sm text-muted">Ready when you are — no need to reload the page.</p>
                <Button onClick={startNewBroadcast} className="mt-4">
                  <FiRadio /> Start a new broadcast
                </Button>
              </div>
            )}
          </div>
          {mode === 'camera' && camera.state === 'live' && (
            <p className="mt-2 text-xs text-muted">You can browse the rest of the app while live — just don't close or refresh this tab, that will end your broadcast.</p>
          )}
        </div>

        <div className="rounded-2xl border border-white/10 bg-surface p-5">
          {phase === 'setup' && (
            <div className="mb-5 flex gap-2 rounded-xl bg-canvas p-1">
              <button
                type="button"
                onClick={() => setPersistedMode('camera')}
                className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-bold ${mode === 'camera' ? 'bg-surface text-ink shadow' : 'text-muted'}`}
              >
                <FiVideo /> This device
              </button>
              <button
                type="button"
                onClick={() => setPersistedMode('external')}
                className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-bold ${mode === 'external' ? 'bg-surface text-ink shadow' : 'text-muted'}`}
              >
                <FiExternalLink /> OBS / other software
              </button>
            </div>
          )}

          {phase === 'setup' ? (
            <>
              <label className="block text-sm font-bold">
                Title
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="input mt-2"
                  placeholder="Friday night watch party"
                />
              </label>
              <label className="mt-4 block text-sm font-bold">
                Description
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="input mt-2 min-h-24"
                  placeholder="What are you streaming today?"
                />
              </label>
              <div className="mt-4">
                <p className="text-sm font-bold">
                  Thumbnail <span className="font-normal text-muted">(optional — auto-picked from your stream if you skip this)</span>
                </p>
                <div className="mt-2">
                  <ThumbnailPicker posterUrl={posterUrl} onUploaded={uploadSetupThumbnail} isSaving={uploadingSetupThumbnail} />
                </div>
              </div>

              {error && <p className="mt-4 text-sm font-bold text-danger">{error}</p>}

              <div className="mt-5">
                <Button onClick={createBroadcast} disabled={createStream.isPending} className="w-full justify-center">
                  <FiRadio /> {createStream.isPending ? 'Setting up…' : 'Get streaming details'}
                </Button>
              </div>
            </>
          ) : mode === 'camera' ? (
            <>
              <p className="text-sm font-bold text-ink">{title || 'Your broadcast'}</p>
              <p className="mt-1 text-xs text-muted">Broadcasting from this device's camera and microphone.</p>

              {(error || camera.error) && <p className="mt-4 text-sm font-bold text-danger">{camera.error || error}</p>}

              {phase !== 'ended' && stream && (
                <div className="mt-4 border-t border-white/10 pt-4">
                  <ThumbnailPicker
                    posterUrl={stream.posterUrl ?? ''}
                    autoCaptured={!stream.posterIsManual}
                    isSaving={setThumbnail.isPending}
                    onUploaded={(file) => setThumbnail.mutate({ id: stream.id, file })}
                  />
                </div>
              )}

              {phase !== 'ended' && (
                <div className="mt-5 space-y-3">
                  {camera.state === 'idle' && (
                    <Button
                      onClick={() => ingest.data && camera.start(ingest.data.whipUrl)}
                      disabled={!ingest.data}
                      className="w-full justify-center"
                    >
                      <FiVideo /> {ingest.data ? 'Start broadcasting' : 'Loading…'}
                    </Button>
                  )}
                  <Button
                    onClick={stopStream}
                    variant="secondary"
                    className="w-full justify-center border-danger/40 text-danger hover:bg-danger/10"
                  >
                    <FiSquare /> End stream
                  </Button>
                </div>
              )}
            </>
          ) : (
            <>
              <p className="text-sm font-bold text-ink">{title || 'Your broadcast'}</p>
              {ingest.data ? (
                <div className="mt-4 space-y-4">
                  <CopyField label="Server" value={ingest.data.rtmpUrl} />
                  <CopyField label="Stream key" value={ingest.data.streamKey} />
                </div>
              ) : ingest.isError ? (
                <p className="mt-4 text-sm font-bold text-danger">Could not load your streaming details.</p>
              ) : (
                <p className="mt-4 text-sm text-muted">Loading streaming details…</p>
              )}

              {error && <p className="mt-4 text-sm font-bold text-danger">{error}</p>}

              {phase !== 'ended' && stream && (
                <div className="mt-4 border-t border-white/10 pt-4">
                  <ThumbnailPicker
                    posterUrl={stream.posterUrl ?? ''}
                    autoCaptured={!stream.posterIsManual}
                    isSaving={setThumbnail.isPending}
                    onUploaded={(file) => setThumbnail.mutate({ id: stream.id, file })}
                  />
                </div>
              )}

              {phase !== 'ended' && (
                <div className="mt-5">
                  <Button
                    onClick={stopStream}
                    variant="secondary"
                    className="w-full justify-center border-danger/40 text-danger hover:bg-danger/10"
                  >
                    <FiSquare /> End stream
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
