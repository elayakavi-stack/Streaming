import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/Button'
export function NotFoundPage() { return <div className="grid min-h-[70vh] place-items-center px-6 text-center"><div><p className="font-display text-8xl font-black text-brand/30">404</p><h1 className="font-display text-3xl font-black">This scene is missing.</h1><p className="mt-3 text-muted">The page may have moved, or the link has reached its final credits.</p><Link to="/" className="mt-6 inline-block"><Button>Return home</Button></Link></div></div> }
