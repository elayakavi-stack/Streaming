import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useForm, type UseFormRegisterReturn } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { FiCheck, FiLogOut, FiMonitor, FiShield, FiVolume2 } from 'react-icons/fi'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { usePreferences, useUpdatePreferences } from '@/features/account/queries'
import { authApi } from '@/services/auth-api'

const schema = z.object({ autoplay: z.boolean(), autoplayPreviews: z.boolean(), dataSaver: z.boolean(), emailNotifications: z.boolean() })
type Preferences = z.infer<typeof schema>

export function SettingsPage() {
  const navigate = useNavigate()
  const { data: preferences, isPending, isError } = usePreferences()
  const updatePreferences = useUpdatePreferences()
  const { register, handleSubmit, reset, formState: { isSubmitSuccessful, isDirty } } = useForm<Preferences>({
    resolver: zodResolver(schema),
    defaultValues: { autoplay: true, autoplayPreviews: true, dataSaver: false, emailNotifications: true },
  })

  useEffect(() => {
    if (preferences) reset(preferences)
  }, [preferences, reset])

  const onSubmit = handleSubmit((values) => {
    updatePreferences.mutate(values)
  })

  return <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
    <p className="text-xs font-bold uppercase tracking-[.2em] text-brand">Settings</p>
    <h1 className="mt-2 font-display text-4xl font-black tracking-[-.05em]">Make NovaPlay yours.</h1>

    {isPending && <div className="mt-8 space-y-5"><Skeleton className="h-40" /><Skeleton className="h-24" /></div>}
    {isError && <p className="mt-6 text-sm font-bold text-danger">Couldn't load your preferences. Check the API connection.</p>}

    {!isPending && !isError && <form onSubmit={onSubmit} className="mt-8 space-y-5">
      <SettingGroup icon={<FiMonitor/>} title="Playback">
        <Toggle label="Autoplay next episode" description="Start the next episode when this one ends." input={register('autoplay')}/>
        <Toggle label="Autoplay previews" description="Play silent previews while you browse." input={register('autoplayPreviews')}/>
        <Toggle label="Data saver" description="Prefer lower quality on mobile connections." input={register('dataSaver')}/>
      </SettingGroup>
      <SettingGroup icon={<FiVolume2/>} title="Notifications">
        <Toggle label="Email updates" description="New releases and personalised picks." input={register('emailNotifications')}/>
      </SettingGroup>
      <SettingGroup icon={<FiShield/>} title="Privacy">
        <p className="text-sm leading-6 text-muted">Account privacy and viewing-data controls will connect to <code>/v1/account/privacy</code>.</p>
      </SettingGroup>
      <div className="flex items-center gap-4">
        <Button type="submit" disabled={updatePreferences.isPending || !isDirty}>{updatePreferences.isPending ? 'Saving…' : 'Save preferences'}</Button>
        {isSubmitSuccessful && updatePreferences.isSuccess && !isDirty && <span className="flex items-center gap-1 text-sm font-semibold text-success"><FiCheck/> Saved</span>}
        {updatePreferences.isError && <span className="text-sm font-bold text-danger">{updatePreferences.error instanceof Error ? updatePreferences.error.message : 'Could not save preferences.'}</span>}
      </div>
    </form>}

    <section className="mt-5 rounded-3xl border border-white/10 bg-surface p-5 sm:p-6">
      <h2 className="flex items-center gap-2 font-display text-xl font-bold"><span className="text-brand"><FiLogOut/></span>Account</h2>
      <div className="mt-3 flex items-center justify-between gap-5 py-2">
        <span><span className="block text-sm font-bold">Sign out</span><span className="mt-1 block text-sm text-muted">End your session on this device.</span></span>
        <Button variant="secondary" onClick={() => { authApi.logout(); navigate('/login') }}>Sign out</Button>
      </div>
    </section>
  </div>
}

function SettingGroup({icon,title,children}:{icon:React.ReactNode;title:string;children:React.ReactNode}) { return <section className="rounded-3xl border border-white/10 bg-surface p-5 sm:p-6"><h2 className="flex items-center gap-2 font-display text-xl font-bold"><span className="text-brand">{icon}</span>{title}</h2><div className="mt-3 divide-y divide-white/10">{children}</div></section> }
function Toggle({label,description,input}:{label:string;description:string;input:UseFormRegisterReturn}) { return <label className="flex cursor-pointer items-center justify-between gap-5 py-4"><span><span className="block text-sm font-bold">{label}</span><span className="mt-1 block text-sm text-muted">{description}</span></span><input type="checkbox" className="h-5 w-5 accent-brand" {...input}/></label> }
