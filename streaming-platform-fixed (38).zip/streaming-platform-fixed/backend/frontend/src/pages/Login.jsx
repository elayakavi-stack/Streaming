import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { login, register } from '../api/client'

export default function Login() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [mode, setMode] = useState('signin')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      if (mode === 'register') {
        await register(email, password)
        await login(email, password)
      } else {
        await login(email, password)
      }
      navigate('/')
    } catch {
      setError(mode === 'register' ? 'Registration failed. Try another email or password.' : 'Incorrect email or password.')
    } finally {
      setBusy(false)
    }
  }

  async function useDemoAccount() {
    setEmail('guest@streamverse.com')
    setPassword('guest123')
    setMode('signin')
    setError('')
    try {
      setBusy(true)
      await login('guest@streamverse.com', 'guest123')
      navigate('/')
    } catch {
      setError('Demo sign-in failed. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-void px-4">
      <div className="pointer-events-none absolute inset-0" style={{ background: 'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(232,163,61,0.08) 0%, transparent 60%)' }} />

      <div className="relative w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="marquee-heading text-4xl text-marquee">StreamVerse</h1>
          <p className="mt-2 text-sm text-ash">Premium streaming. Faster sign-in. Better viewing.</p>
        </div>

        <div className="mb-4 flex rounded-lg border border-panel-raised bg-panel p-1">
          <button onClick={() => setMode('signin')} className={`flex-1 rounded-md px-3 py-2 text-sm font-semibold transition ${mode === 'signin' ? 'bg-marquee text-void' : 'text-ash'}`}>Sign In</button>
          <button onClick={() => setMode('register')} className={`flex-1 rounded-md px-3 py-2 text-sm font-semibold transition ${mode === 'register' ? 'bg-marquee text-void' : 'text-ash'}`}>Create Account</button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4 rounded-lg border border-panel-raised bg-panel p-8 shadow-2xl">
          <h2 className="marquee-heading text-xl text-ivory">{mode === 'signin' ? 'Welcome back' : 'Start your watchlist'}</h2>

          <label className="flex flex-col gap-1.5 text-sm text-ash">
            Email
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="rounded-md border border-panel-raised bg-void px-3 py-2 text-ivory outline-none focus:border-marquee" placeholder="you@example.com" />
          </label>

          <label className="flex flex-col gap-1.5 text-sm text-ash">
            Password
            <input type="password" required minLength={4} value={password} onChange={(e) => setPassword(e.target.value)} className="rounded-md border border-panel-raised bg-void px-3 py-2 text-ivory outline-none focus:border-marquee" placeholder="••••••••" />
          </label>

          {error && <p className="text-sm text-reel">{error}</p>}

          <button type="submit" disabled={busy} className="mt-2 rounded-md bg-marquee px-4 py-2.5 font-semibold text-void transition-colors hover:bg-marquee-dim disabled:opacity-50">
            {busy ? (mode === 'signin' ? 'Signing in…' : 'Creating account…') : mode === 'signin' ? 'Sign in' : 'Create account'}
          </button>

          <button type="button" onClick={useDemoAccount} className="rounded-md border border-white/10 px-4 py-2.5 text-sm font-semibold text-ivory transition-colors hover:border-marquee hover:text-marquee">
            Use demo account
          </button>
        </form>
      </div>
    </div>
  )
}
