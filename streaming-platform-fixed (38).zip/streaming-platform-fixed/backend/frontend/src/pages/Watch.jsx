import { useEffect, useRef, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { ArrowLeft, Trash2, Loader2, BookmarkPlus, BookmarkCheck, Star } from 'lucide-react'
import { getVideo, saveProgress, deleteVideo, toggleWatchlist, rateVideo } from '../api/client'
import { getPreferences } from '../lib/preferences'
import VideoPlayer from '../components/VideoPlayer'

export default function Watch() {
  const { videoId } = useParams()
  const navigate = useNavigate()
  const [video, setVideo] = useState(null)
  const [confirming, setConfirming] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [watchlisted, setWatchlisted] = useState(false)
  const [rating, setRating] = useState(0)
  const lastSaved = useRef(0)
  const prefs = getPreferences()

  useEffect(() => {
    let interval
    async function poll() {
      const v = await getVideo(videoId)
      setVideo(v)
      setWatchlisted(Boolean(v?.is_in_watchlist))
      if (v.status === 'ready' || v.status === 'failed') clearInterval(interval)
    }
    poll()
    interval = setInterval(poll, 4000)
    return () => clearInterval(interval)
  }, [videoId])

  function handleProgress(position, duration) {
    if (!prefs.trackProgress) return
    if (Math.abs(position - lastSaved.current) < 1) return
    lastSaved.current = position
    saveProgress(videoId, position, duration)
  }

  async function handleWatchlist() {
    try {
      const result = await toggleWatchlist(videoId)
      setWatchlisted(result.is_in_watchlist)
    } catch (err) {
      console.error(err)
    }
  }

  async function handleRate(value) {
    try {
      const result = await rateVideo(videoId, value)
      setRating(result.average_rating)
    } catch (err) {
      console.error(err)
    }
  }

  async function handleDelete() {
    if (!confirming) {
      setConfirming(true)
      return
    }
    setDeleting(true)
    try {
      await deleteVideo(videoId)
      navigate('/')
    } catch (err) {
      console.error(err)
      setDeleting(false)
      setConfirming(false)
    }
  }

  return (
    <div className="min-h-screen bg-void">
      <div className="mx-auto flex max-w-4xl items-center justify-between px-6 py-6">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-ash transition-colors hover:text-ivory">
          <ArrowLeft size={16} />
          Back to home
        </Link>

        {video && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleWatchlist}
              className="flex items-center gap-2 rounded-md border border-white/10 px-3 py-1.5 text-sm text-ash transition-colors hover:border-marquee hover:text-ivory"
            >
              {watchlisted ? <BookmarkCheck size={15} className="text-marquee" /> : <BookmarkPlus size={15} />}
              {watchlisted ? 'Saved' : 'Save'}
            </button>
            <button
              onClick={handleDelete}
              onBlur={() => setConfirming(false)}
              disabled={deleting}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm transition-colors ${
                confirming ? 'bg-reel text-ivory' : 'text-ash hover:text-reel'
              }`}
            >
              {deleting ? <Loader2 size={15} className="animate-spin" /> : <Trash2 size={15} />}
              {confirming ? 'Click again to delete' : 'Delete'}
            </button>
          </div>
        )}
      </div>

      {!video ? (
        <p className="px-6 text-ash">Loading…</p>
      ) : (
        <div className="mx-auto max-w-4xl px-6 pb-16">
          <VideoPlayer
            src={video.playback_url}
            initialPosition={prefs.trackProgress ? video.progress_seconds : null}
            onProgress={handleProgress}
            autoPlay={prefs.autoplay}
          />

          <div className="mt-6 rounded-2xl border border-white/10 bg-panel p-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h1 className="marquee-heading text-3xl text-ivory">{video.title}</h1>
                <div className="mt-3 flex flex-wrap gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-ash">
                  <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1">{video.genre}</span>
                  <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1">{video.category}</span>
                  <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1">{video.rating}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-sm">
                <span className="text-ash">Rating</span>
                <span className="font-bold text-ivory">{rating || video.imdb_score || '8.5'}</span>
              </div>
            </div>

            {video.status === 'failed' && (
              <p className="mt-3 font-mono text-xs uppercase tracking-wide text-reel">
                This title couldn't be processed.
              </p>
            )}
            {video.description && <p className="mt-4 text-ash">{video.description}</p>}

            <div className="mt-5 flex flex-wrap items-center gap-2">
              {[1, 2, 3, 4, 5].map((value) => (
                <button key={value} onClick={() => handleRate(value)} className="rounded-full p-2 text-ash transition hover:bg-white/10 hover:text-ivory">
                  <Star size={18} className={value <= Math.round(rating || Number(video.imdb_score || 8.5)) ? 'fill-current text-marquee' : ''} />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
