import { ContentRail } from '@/components/content/ContentRail'
import { CinematicHero } from '@/components/content/CinematicHero'
import { LiveNowRail } from '@/components/content/LiveNowRail'
import { Skeleton } from '@/components/ui/Skeleton'
import { useHomeDiscovery } from '@/features/discovery/queries'
import { useLiveNow } from '@/features/live/queries'

export function HomePage() {
  const { data, isPending, isError, refetch } = useHomeDiscovery()
  const { data: liveStreams } = useLiveNow()
  if (isPending) return <div className="space-y-10"><Skeleton className="h-[580px] rounded-none"/><div className="space-y-8 px-4 sm:px-6 lg:px-10"><Skeleton className="h-8 w-56"/><Skeleton className="h-60"/></div></div>
  if (isError || !data) return <div className="grid min-h-[70vh] place-items-center px-6 text-center"><div><h1 className="font-display text-3xl font-black">We couldn’t load your library.</h1><p className="mt-3 text-muted">Check that the API is running and VITE_API_BASE points to it.</p><button onClick={() => refetch()} className="mt-5 rounded-xl bg-brand px-4 py-2 font-bold text-canvas">Try again</button></div></div>
  if (!data.hero) return <div className="grid min-h-[70vh] place-items-center px-6 text-center"><div><h1 className="font-display text-3xl font-black">Your library is ready for its first title.</h1><p className="mt-3 text-muted">Upload a video, thumbnail, and metadata from the admin upload workflow.</p></div></div>
  return <><CinematicHero item={data.hero} items={data.heroItems}/><div className="mx-auto max-w-[1680px] px-4 pb-16 pt-4 sm:px-6 lg:px-10">{liveStreams && liveStreams.length > 0 && <LiveNowRail streams={liveStreams}/>}{data.rails.map((rail) => <ContentRail key={rail.id} rail={rail}/>)}</div></>
}
