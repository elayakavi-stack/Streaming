import { useMemo, useState } from 'react'
import { FiCheck, FiChevronDown, FiMic, FiSearch, FiSliders, FiX } from 'react-icons/fi'
import { PosterCard } from '@/components/content/PosterCard'
import { Skeleton } from '@/components/ui/Skeleton'
import { useContentSearch, useGenres } from '@/features/discovery/queries'

const trending = ['Science fiction', 'Crime drama', 'Sports documentaries', 'Feel-good films']

type TypeFilter = 'all' | 'movie' | 'series'
type SortBy = 'relevance' | 'newest' | 'rating' | 'az'

const TYPE_OPTIONS: { value: TypeFilter; label: string }[] = [
  { value: 'all', label: 'All types' },
  { value: 'movie', label: 'Movies' },
  { value: 'series', label: 'Series' },
]

const SORT_OPTIONS: { value: SortBy; label: string }[] = [
  { value: 'relevance', label: 'Relevance' },
  { value: 'newest', label: 'Newest first' },
  { value: 'rating', label: 'Highest rated' },
  { value: 'az', label: 'Title A–Z' },
]

export function BrowsePage() {
  const [query, setQuery] = useState('')
  const [genre, setGenre] = useState('All genres')
  const [type, setType] = useState<TypeFilter>('all')
  const [sortBy, setSortBy] = useState<SortBy>('relevance')
  const [filtersOpen, setFiltersOpen] = useState(false)
  const { data, isPending } = useContentSearch(query)
  const { data: genres = [] } = useGenres()

  const activeFilterCount = (genre !== 'All genres' ? 1 : 0) + (type !== 'all' ? 1 : 0) + (sortBy !== 'relevance' ? 1 : 0)

  const results = useMemo(() => {
    let items = data?.data ?? []
    if (genre !== 'All genres') items = items.filter((item) => item.genres.some((g) => g.toLowerCase().includes(genre.toLowerCase())))
    if (type !== 'all') items = items.filter((item) => item.kind === type)
    items = [...items]
    if (sortBy === 'newest') items.sort((a, b) => b.releaseYear - a.releaseYear)
    if (sortBy === 'rating') items.sort((a, b) => (b.averageRating ?? b.score ?? 0) - (a.averageRating ?? a.score ?? 0))
    if (sortBy === 'az') items.sort((a, b) => a.title.localeCompare(b.title))
    return items
  }, [data, genre, type, sortBy])

  const resetFilters = () => { setGenre('All genres'); setType('all'); setSortBy('relevance') }

  return <div className="mx-auto max-w-[1680px] px-4 py-8 sm:px-6 lg:px-10">
    <div className="mx-auto max-w-4xl">
      <p className="text-xs font-bold uppercase tracking-[.2em] text-brand">Search</p>
      <h1 className="mt-2 font-display text-4xl font-black tracking-[-.05em] sm:text-5xl">Find your next obsession.</h1>
      <div className="mt-7 flex items-center rounded-2xl border border-white/15 bg-surface px-4 shadow-panel transition focus-within:border-brand/50 focus-within:ring-2 focus-within:ring-brand/30">
        <FiSearch className="text-brand"/>
        <input value={query} onChange={(event) => setQuery(event.target.value)} autoFocus placeholder="Titles, genres, people, collections…" className="h-14 min-w-0 flex-1 border-none bg-transparent px-3 text-base text-ink outline-none ring-0 focus-visible:outline-none placeholder:text-muted" style={{ boxShadow: 'none' }} aria-label="Search titles"/>
        {query && <button onClick={() => setQuery('')} className="p-2 text-muted hover:text-ink" aria-label="Clear search"><FiX/></button>}
        <button className="p-2 text-muted hover:text-brand" aria-label="Voice search placeholder"><FiMic/></button>
      </div>

      <div className="relative mt-4 flex flex-wrap items-center gap-2">
        <button
          type="button"
          aria-expanded={filtersOpen}
          onClick={() => setFiltersOpen((open) => !open)}
          className={`inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-sm font-semibold transition ${filtersOpen || activeFilterCount ? 'border-brand/60 bg-brand/10 text-ink' : 'border-white/10 bg-white/[.05] text-muted hover:text-ink'}`}
        >
          <FiSliders/> Filters
          {activeFilterCount > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-brand px-1 text-[11px] font-black text-canvas">{activeFilterCount}</span>}
          <FiChevronDown className={`transition-transform ${filtersOpen ? 'rotate-180' : ''}`}/>
        </button>
        <select value={genre} onChange={(event) => setGenre(event.target.value)} className="rounded-lg border border-white/10 bg-white/[.05] px-3 py-2 text-sm font-semibold text-muted outline-none">
          <option>All genres</option>
          {genres.map((g) => <option key={g}>{g}</option>)}
        </select>
        {activeFilterCount > 0 && <button onClick={resetFilters} className="text-sm font-bold text-brand hover:underline">Clear all</button>}

        {filtersOpen && <div className="absolute left-0 top-full z-20 mt-2 w-full max-w-sm rounded-2xl border border-white/10 bg-surface p-4 shadow-panel sm:w-80">
          <p className="text-xs font-bold uppercase tracking-[.15em] text-muted">Type</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {TYPE_OPTIONS.map((option) => <button key={option.value} onClick={() => setType(option.value)} className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-semibold transition ${type === option.value ? 'bg-ink text-canvas' : 'border border-white/10 bg-white/[.05] text-muted hover:text-ink'}`}>
              {type === option.value && <FiCheck size={14}/>} {option.label}
            </button>)}
          </div>
          <p className="mt-4 text-xs font-bold uppercase tracking-[.15em] text-muted">Sort by</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {SORT_OPTIONS.map((option) => <button key={option.value} onClick={() => setSortBy(option.value)} className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-semibold transition ${sortBy === option.value ? 'bg-ink text-canvas' : 'border border-white/10 bg-white/[.05] text-muted hover:text-ink'}`}>
              {sortBy === option.value && <FiCheck size={14}/>} {option.label}
            </button>)}
          </div>
          <div className="mt-4 flex justify-end gap-3 border-t border-white/10 pt-3">
            <button onClick={resetFilters} className="text-sm font-bold text-muted hover:text-ink">Reset</button>
            <button onClick={() => setFiltersOpen(false)} className="rounded-lg bg-brand px-3 py-1.5 text-sm font-bold text-canvas">Done</button>
          </div>
        </div>}
      </div>
    </div>

    {!query && <section className="mt-10"><h2 className="font-display text-xl font-bold">Trending searches</h2><div className="mt-4 flex flex-wrap gap-2">{trending.map((item) => <button key={item} onClick={() => setQuery(item)} className="rounded-full border border-white/10 bg-white/[.05] px-4 py-2 text-sm text-muted transition hover:border-brand/50 hover:text-ink">{item}</button>)}</div></section>}

    <section className="mt-10">
      <div className="flex items-baseline justify-between"><h2 className="font-display text-2xl font-bold">{query ? `Results for “${query}”` : 'Browse everything'}</h2><span className="text-sm text-muted">{results.length} titles</span></div>
      {isPending ? <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-6">{Array.from({length: 6}).map((_, index) => <Skeleton key={index} className="aspect-[2/3]"/>)}</div>
      : results.length ? <div className="mt-5 grid grid-cols-2 gap-x-3 gap-y-7 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-7">{results.map((item) => <PosterCard key={item.id} item={item}/>)}</div>
      : <div className="mt-5 rounded-3xl border border-dashed border-white/15 bg-surface/60 p-12 text-center"><h3 className="font-display text-xl font-bold">No titles found</h3><p className="mt-2 text-sm text-muted">Try a broader title, genre, or person.</p></div>}
    </section>
  </div>
}
