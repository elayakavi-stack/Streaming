import { useCallback, useEffect, useRef, useState } from 'react'
import { FiArrowLeft, FiCheck, FiDownload, FiFlag, FiPlay, FiPlus, FiStar } from 'react-icons/fi'
import { useParams, useSearchParams } from 'react-router-dom'
import { OttPlayer } from '@/components/player/OttPlayer'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { ContentRail } from '@/components/content/ContentRail'
import { humanizeMoods } from '@/lib/moods'
import { useBecauseYouWatched, useContentDetails, useRateVideo, useSimilarMood, useToggleWatchlist } from '@/features/discovery/queries'
import { useAddDownload, useDownloads, useRemoveDownload } from '@/features/account/queries'
import { contentApi } from '@/services/content-api'

/** The title page — one page, the OTT way (Hotstar/Netflix/Prime): browsing
 * info and watching live on the same URL (`/title/:id`). Hitting "Play"
 * doesn't navigate to a separate player route; it swaps the hero art for the
 * video player in place via a `?play=1` query flag on this same page, so
 * nothing unmounts, scroll position is preserved, and the "More like this" /
 * "Because you watched" rails stay right below it. The back button (or
 * "Back to details") just drops the flag instead of leaving the page.
 * Old `/watch/:id` links redirect here with `?play=1` already set (see
 * App.tsx's WatchRedirect), so they land already playing. */
export function TitleDetailsPage() {
  const { id = '' } = useParams()
  const [searchParams, setSearchParams] = useSearchParams()

  const { data: item, isPending, isError } = useContentDetails(id)
  const toggleWatchlist = useToggleWatchlist()
  const rateVideo = useRateVideo()
  const { data: downloads = [] } = useDownloads()
  const addDownload = useAddDownload()
  const removeDownload = useRemoveDownload()
  const [hoverRating, setHoverRating] = useState(0)
  const [reporting, setReporting] = useState(false)
  const [reviewDraft, setReviewDraft] = useState('')
  const [editingReview, setEditingReview] = useState(false)

  // A `?play=1` link (from a poster/hero "Play" button, or a shared URL)
  // should drop the viewer straight into playback.
  const [isPlaying, setIsPlaying] = useState(() => searchParams.get('play') === '1')
  useEffect(() => {
    if (searchParams.get('play') === '1') setIsPlaying(true)
  }, [searchParams])

  const { data: moodItems = [] } = useSimilarMood(id)
  // "Because you watched X" — same director / same cast picks only, never
  // generic catalog-wide recommendations unrelated to this title.
  const { data: relatedItems = [] } = useBecauseYouWatched(id)

  const lastReported = useRef(0)
  const handleProgress = useCallback(
    (currentTime: number, duration: number) => {
      if (Math.abs(currentTime - lastReported.current) < 4) return
      lastReported.current = currentTime
      contentApi.saveProgress(id, currentTime, duration || undefined)
    },
    [id],
  )

  const startPlaying = () => {
    setIsPlaying(true)
    setSearchParams({ play: '1' }, { replace: true })
  }
  const stopPlaying = () => {
    setIsPlaying(false)
    setSearchParams({}, { replace: true })
  }

  if (isPending) {
    return (
      <div>
        <Skeleton className="h-[560px] rounded-none" />
        <div className="mx-auto mt-8 max-w-[1680px] px-4"><Skeleton className="h-10 w-2/3" /><Skeleton className="mt-4 h-24 max-w-2xl" /></div>
      </div>
    )
  }
  if (isError || !item) return <div className="grid min-h-[70vh] place-items-center text-muted">This title is no longer available.</div>

  const isProcessing = Boolean(item.status && item.status !== 'ready')
  const activeRating = hoverRating || item.userRating || 0
  const isDownloaded = downloads.some((d) => d.video.id === item.id)
  const canPlay = isPlaying && !isProcessing && Boolean(item.playbackUrl)

  const submitReport = () => {
    const subject = window.prompt('What issue are you reporting?')
    if (!subject) return
    setReporting(true)
    contentApi
      .reportVideo(item.id, subject)
      .then(() => window.alert('Thanks — our team will take a look.'))
      .catch((error) => window.alert(error instanceof Error ? error.message : 'Could not submit the report.'))
      .finally(() => setReporting(false))
  }

  return (
    <>
      {canPlay ? (
        <div className="mx-auto max-w-[1680px] px-4 pt-6 sm:px-6 lg:px-10">
          <button onClick={stopPlaying} className="mb-4 inline-flex items-center gap-2 text-sm font-bold text-muted hover:text-ink">
            <FiArrowLeft /> Back to details
          </button>
          <OttPlayer
            src={item.playbackUrl!}
            poster={item.backdropUrl || item.posterUrl}
            initialPosition={item.progressSeconds ?? 0}
            subtitles={item.subtitles}
            onProgress={handleProgress}
          />
        </div>
      ) : (
        <section className="relative isolate min-h-[620px] overflow-hidden">
          <img src={item.backdropUrl || item.posterUrl} alt="" className="absolute inset-0 -z-20 h-full w-full object-cover opacity-90" />
          <div className="absolute inset-0 -z-10 bg-[linear-gradient(90deg,rgba(7,8,15,.85)_0%,rgba(7,8,15,.58)_34%,rgba(7,8,15,.16)_68%,rgba(7,8,15,.04)_100%),linear-gradient(0deg,rgba(7,8,15,.78)_0%,transparent_58%)]" />
          <div className="mx-auto flex min-h-[620px] max-w-[1680px] items-end px-4 pb-14 sm:px-6 lg:px-10">
            <div className="max-w-2xl">
              <p className="text-xs font-black uppercase tracking-[.2em] text-brand">{item.kind}</p>
              <h1 className="mt-3 font-display text-5xl font-black tracking-[-.06em] sm:text-7xl">{item.title}</h1>
              <div className="mt-4 flex flex-wrap gap-3 text-sm font-semibold text-[#d4dcf0]">
                <span>{item.releaseYear}</span>
                <span>{item.maturityRating}</span>
                {item.durationLabel && <span>{item.durationLabel}</span>}
                {item.averageRating !== undefined && <span className="flex items-center gap-1"><FiStar className="text-brand" /> {item.averageRating} ({item.ratingCount})</span>}
              </div>
              <p className="mt-5 max-w-xl text-base leading-7 text-[#c3cbdd]">{item.synopsis || 'No description has been added yet.'}</p>
              {isProcessing && <p className="mt-3 text-sm font-semibold text-brand">{item.status === 'processing' ? 'Still processing into streaming quality — check back shortly.' : 'Not ready to play yet.'}</p>}
              {!isProcessing && !item.playbackUrl && <p className="mt-3 text-sm font-semibold text-muted">No playback source is available for this title yet.</p>}
              <div className="mt-7 flex flex-wrap gap-3">
                <Button onClick={startPlaying} disabled={isProcessing || !item.playbackUrl}>
                  <FiPlay /> {isProcessing ? 'Processing…' : 'Play'}
                </Button>
                <Button variant="secondary" disabled={toggleWatchlist.isPending} onClick={() => toggleWatchlist.mutate(item.id)}>
                  {item.isInWatchlist ? <FiCheck /> : <FiPlus />} {item.isInWatchlist ? 'In watchlist' : 'Watch later'}
                </Button>
                <Button
                  variant="secondary"
                  disabled={addDownload.isPending || removeDownload.isPending}
                  onClick={() => (isDownloaded ? removeDownload.mutate(item.id) : addDownload.mutate(item.id))}
                >
                  <FiDownload /> {isDownloaded ? 'Remove download' : 'Download'}
                </Button>
                <Button variant="ghost" disabled={reporting} onClick={submitReport}>
                  <FiFlag /> Report an issue
                </Button>
              </div>
            </div>
          </div>
        </section>
      )}

      <main className="mx-auto max-w-[1680px] px-4 pb-16 pt-8 sm:px-6 lg:px-10">
        {canPlay && (
          <div className="mb-8">
            <p className="text-xs font-black uppercase tracking-[.2em] text-brand">{item.kind === 'series' ? 'Series' : 'Movie'} · {item.releaseYear}</p>
            <h1 className="mt-2 font-display text-3xl font-black tracking-[-.04em] sm:text-4xl">{item.title}</h1>
            <div className="mt-3 flex flex-wrap items-center gap-3 text-sm font-semibold text-muted">
              <span>{item.maturityRating}</span>
              {item.durationLabel && <span>{item.durationLabel}</span>}
              {item.averageRating !== undefined && <span className="flex items-center gap-1"><FiStar className="text-brand" /> {item.averageRating} ({item.ratingCount})</span>}
            </div>
            <p className="mt-3 max-w-3xl leading-7 text-muted">{item.synopsis || 'No description has been added yet.'}</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button variant="secondary" disabled={toggleWatchlist.isPending} onClick={() => toggleWatchlist.mutate(item.id)}>
                {item.isInWatchlist ? <FiCheck /> : <FiPlus />} {item.isInWatchlist ? 'In watchlist' : 'Watch later'}
              </Button>
              <Button
                variant="secondary"
                disabled={addDownload.isPending || removeDownload.isPending}
                onClick={() => (isDownloaded ? removeDownload.mutate(item.id) : addDownload.mutate(item.id))}
              >
                <FiDownload /> {isDownloaded ? 'Remove download' : 'Download'}
              </Button>
              <Button variant="ghost" disabled={reporting} onClick={submitReport}>
                <FiFlag /> Report an issue
              </Button>
            </div>
          </div>
        )}

        <section className="grid gap-6 border-b border-white/10 pb-10 sm:grid-cols-2 lg:grid-cols-4">
          <Info label="Genres" value={[...item.genres, item.subGenre].filter(Boolean).join(', ') || 'Not set'} />
          <Info label="Director" value={item.director || 'Not set'} />
          <Info label="Cast" value={item.castMembers || 'Not set'} />
          <Info label="Rating" value={item.averageRating !== undefined ? `${item.averageRating} / 5 (${item.ratingCount} ratings)` : 'No ratings yet'} />
        </section>

        <section className="border-b border-white/10 py-10">
          <div className="flex items-center gap-1" role="radiogroup" aria-label="Rate this title">
            {[1, 2, 3, 4, 5].map((value) => (
              <button
                key={value}
                role="radio"
                aria-checked={activeRating >= value}
                onMouseEnter={() => setHoverRating(value)}
                onMouseLeave={() => setHoverRating(0)}
                onClick={() => rateVideo.mutate({ id: item.id, value })}
                className="p-1 text-xl transition"
              >
                <FiStar className={activeRating >= value ? 'text-brand' : 'text-white/25'} />
              </button>
            ))}
            {item.userRating && <span className="ml-2 text-sm font-semibold text-muted">Your rating: {item.userRating}/5</span>}
          </div>

          <div className="mt-4 max-w-xl">
            {item.userReview && !editingReview ? (
              <div className="rounded-2xl border border-white/10 bg-white/[.04] p-4">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-bold uppercase tracking-[.14em] text-muted">Your review</p>
                  <button
                    onClick={() => {
                      setReviewDraft(item.userReview ?? '')
                      setEditingReview(true)
                    }}
                    className="text-xs font-bold text-brand"
                  >
                    Edit
                  </button>
                </div>
                <p className="mt-2 text-sm leading-6 text-[#c3cbdd]">{item.userReview}</p>
              </div>
            ) : (
              <>
                <label className="block text-xs font-bold uppercase tracking-[.14em] text-muted">
                  Write a review <span className="font-normal normal-case">(optional — helps us recommend titles you'll actually like)</span>
                </label>
                <textarea
                  value={reviewDraft}
                  onChange={(event) => setReviewDraft(event.target.value)}
                  placeholder="What did you think?"
                  className="input mt-2 min-h-20 w-full"
                />
                <div className="mt-2 flex items-center gap-3">
                  <Button
                    variant="secondary"
                    disabled={!reviewDraft.trim() || rateVideo.isPending}
                    onClick={() => {
                      rateVideo.mutate(
                        { id: item.id, value: activeRating || item.userRating || 5, review: reviewDraft.trim() },
                        { onSuccess: () => setEditingReview(false) },
                      )
                    }}
                  >
                    {rateVideo.isPending ? 'Saving…' : 'Save review'}
                  </Button>
                  {editingReview && (
                    <button onClick={() => setEditingReview(false)} className="text-xs font-bold text-muted hover:text-ink">Cancel</button>
                  )}
                  {!activeRating && !item.userRating && reviewDraft.trim() && (
                    <span className="text-xs text-muted">Rate with stars above too, or this saves as a 5-star review.</span>
                  )}
                </div>
              </>
            )}
          </div>
        </section>

        {/* Recommendations — always live on this same page, right below the
            details/player, the way an OTT app never bounces you to a
            separate "recommendations" screen. */}
        {moodItems.length > 0 && (
          <ContentRail
            rail={{
              id: 'similar-mood',
              title: 'More like this mood',
              // Only call out moods that are actually shared with at least
              // one of the recommended titles below — item.moods on its
              // own is everything THIS title is tagged with, which isn't
              // necessarily what any given recommendation matched on (the
              // backend can also let a title in on genre alone, or on a
              // different mood tag than the ones we'd show first). Claiming
              // "dark and intense" over a rail that includes something
              // that's neither is worse than saying less.
              subtitle: (() => {
                const shared = (item.moods ?? []).filter((mood) =>
                  moodItems.some((mi) => mi.moods?.includes(mood)),
                )
                return shared.length ? `Because it's ${humanizeMoods(shared, shared.length)}` : undefined
              })(),
              items: moodItems,
            }}
            titleClassName="font-body text-base font-bold tracking-tight text-ink sm:text-lg"
          />
        )}
        {relatedItems.length > 0 && (
          <ContentRail
            rail={{
              id: 'related',
              title: 'More Like This',
              subtitle: `Because you watched ${item.title}`,
              items: relatedItems,
            }}
            titleClassName="font-body text-base font-bold tracking-tight text-ink sm:text-lg"
          />
        )}
      </main>
    </>
  )
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs font-bold uppercase tracking-[.16em] text-muted">{label}</p>
      <p className="mt-2 text-sm font-semibold text-ink">{value}</p>
    </div>
  )
}
