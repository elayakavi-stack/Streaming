import { useEffect, useMemo, useState } from 'react'
import { FiCheck, FiChevronRight, FiFilter, FiGlobe, FiGrid, FiList, FiPlay, FiPlus, FiStar } from 'react-icons/fi'
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom'
import { PosterCard } from '@/components/content/PosterCard'
import { LiveNowRail } from '@/components/content/LiveNowRail'
import { Skeleton } from '@/components/ui/Skeleton'
import { useContentCatalog, useGenres, useToggleWatchlist, useWatchlist } from '@/features/discovery/queries'
import { useLiveNow } from '@/features/live/queries'
import type { ContentCard } from '@/types/content'

const configuration: Record<string, { eyebrow: string; title: string; copy: string; filters: string[]; category?: string; newReleaseDays?: Record<string, number> }> = {
  movies: { eyebrow: 'Cinema', title: 'Movies that stay with you.', copy: 'A considered edit of new releases, audience favourites, and award-worthy stories.', filters: ['All movies', 'Action', 'Drama', 'Sci-Fi', 'Comedy'], category: 'Movie' },
  series: { eyebrow: 'Series', title: 'One more episode.', copy: 'Binge-worthy originals and seasons built for the long weekend.', filters: ['All series', 'Crime', 'Thriller', 'Drama', 'International'], category: 'TV Show' },
  // Sports content lives under its own category (set on upload/edit) so this
  // page only ever shows live broadcasts + titles actually tagged Sports —
  // never the general movie/series catalog.
  sports: { eyebrow: 'Live & sport', title: 'Every moment, live.', copy: 'Match days, sports documentaries, and stories behind the score.', filters: ['All sports', 'Football', 'Motorsport', 'Cricket', 'Documentary'], category: 'Sports' },
  kids: { eyebrow: 'Kids', title: 'Big imagination, safe space.', copy: 'Joyful stories selected for younger viewers.', filters: ['All ages', 'Animation', 'Adventure', 'Learning'] },
  trending: { eyebrow: 'Popular right now', title: 'Everyone is watching.', copy: 'The conversation starters climbing across NovaPlay today.', filters: ['Today', 'This week', 'In your region'] },
  // Genuinely recent uploads only (see new_release_days on GET
  // /videos/catalog) — not the whole catalog re-sorted by date, which used
  // to make every title show up here on a small library.
  'new-releases': { eyebrow: 'Fresh arrivals', title: 'New, and worth pressing play for.', copy: 'Titles uploaded to NovaPlay recently.', filters: ['This month', 'This week'], newReleaseDays: { 'This month': 30, 'This week': 7 } },
  'top-rated': { eyebrow: 'Highest rated', title: 'The best of NovaPlay.', copy: 'Critically loved stories and audience favourites.', filters: ['All time', 'Films', 'Series', 'Documentaries'] },
  genres: { eyebrow: 'Explore by mood', title: 'A story for every mood.', copy: 'Choose a genre and follow your curiosity.', filters: ['All genres'] },
  languages: { eyebrow: 'Languages', title: 'Stories without borders.', copy: 'Original voices from around the world, with subtitles and dubbing.', filters: ['English', 'Hindi', 'Tamil', 'Spanish', 'Korean', 'Japanese'] },
  watchlist: { eyebrow: 'Your watchlist', title: 'Saved for the right moment.', copy: 'Every title you add is ready whenever you are.', filters: ['All saved', 'Movies', 'Series'] },
}

const SORT_OPTIONS = [
  ['newest', 'Newest'],
  ['rating', 'Top rated'],
  ['az', 'A–Z'],
] as const
type SortValue = (typeof SORT_OPTIONS)[number][0]

function useCatalogResults({ config, activeFilter }: { config: (typeof configuration)[string]; activeFilter: string }) {
  const isDefaultFilter = activeFilter === config.filters[0]
  const newReleaseDays = config.newReleaseDays?.[activeFilter]
  const genre = !isDefaultFilter && !newReleaseDays ? activeFilter : undefined
  const { data, isPending } = useContentCatalog({ category: config.category, genre, newReleaseDays })
  const results = useMemo(() => {
    const items = data?.data ?? []
    // Once a category is set (Movies/Series/Sports) or a real server-side
    // filter (genre, new-release window) is already applied, the API has
    // done the filtering — nothing further to do client-side, and
    // critically, nothing here ever falls back to the *unfiltered* catalog
    // the way it used to.
    if (config.category || isDefaultFilter || newReleaseDays) return items
    // Client-side match for dimensions the API doesn't filter on yet (mood, language, trending window).
    // A title's genre can be a mixed value like "Action-Thriller" — match if the
    // active filter appears anywhere in any of the title's genre tags, not just an exact tag match.
    return items.filter((item) => item.genres.some((g) => g.toLowerCase().includes(activeFilter.toLowerCase())))
  }, [data, config.category, isDefaultFilter, activeFilter, newReleaseDays])
  return { results, isPending, total: data?.total } as const
}

function useWatchlistResults({ activeFilter, defaultFilter }: { activeFilter: string; defaultFilter: string }) {
  const { data, isPending } = useWatchlist()
  const results = useMemo(() => {
    const items = data ?? []
    if (activeFilter === defaultFilter) return items
    return items.filter((item) => (activeFilter === 'Movies' ? item.kind === 'movie' : item.kind === 'series'))
  }, [data, activeFilter, defaultFilter])
  return { results, isPending, total: data?.length } as const
}

function ListRow({ item }: { item: ContentCard }) {
  const navigate = useNavigate()
  const toggleWatchlist = useToggleWatchlist()
  const saved = item.isInWatchlist ?? false
  return (
    <div
      onClick={() => navigate(`/title/${item.id}`)}
      onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') navigate(`/title/${item.id}`) }}
      role="link"
      tabIndex={0}
      aria-label={`Open ${item.title}`}
      className="group flex cursor-pointer items-center gap-4 rounded-2xl border border-white/10 bg-surface p-3 transition hover:border-brand/50"
    >
      <div className="h-20 w-14 shrink-0 overflow-hidden rounded-lg bg-surface-raised">
        {item.posterUrl ? <img src={item.posterUrl} alt="" className="h-full w-full object-cover" loading="lazy" /> : <div className="grid h-full w-full place-items-center text-[10px] font-bold text-muted">{item.title.slice(0, 2)}</div>}
      </div>
      <div className="min-w-0 flex-1">
        <h3 className="truncate text-sm font-bold text-ink">{item.title}</h3>
        <p className="mt-0.5 flex flex-wrap items-center gap-1 text-xs text-muted">
          <span>{item.releaseYear}</span>
          {item.durationLabel && <><span>•</span><span>{item.durationLabel}</span></>}
          {item.genres.length > 0 && <><span>•</span><span className="truncate">{item.genres.join(', ')}</span></>}
          {item.score && <><span>•</span><FiStar className="text-brand" /><span>{item.score}</span></>}
        </p>
      </div>
      <div className="flex shrink-0 gap-2">
        <button onClick={(event) => { event.stopPropagation(); navigate(`/title/${item.id}?play=1`) }} className="grid h-9 w-9 place-items-center rounded-full bg-ink text-canvas" aria-label={`Play ${item.title}`}><FiPlay className="ml-0.5" /></button>
        <button disabled={toggleWatchlist.isPending} onClick={(event) => { event.stopPropagation(); toggleWatchlist.mutate(item.id) }} className="grid h-9 w-9 place-items-center rounded-full bg-white/10 text-ink hover:bg-white/20 disabled:opacity-60" aria-label={`${saved ? 'Remove' : 'Add'} ${item.title} ${saved ? 'from' : 'to'} watchlist`}>{saved ? <FiCheck /> : <FiPlus />}</button>
      </div>
    </div>
  )
}

export function CollectionPage() {
  const slug = useLocation().pathname.split('/')[1] || 'movies'
  const isLivePage = slug === 'sports'
  const { data: liveStreams } = useLiveNow({ enabled: isLivePage })
  const { data: liveGenres = [] } = useGenres()
  const [searchParams] = useSearchParams()
  const config = useMemo(() => {
    const base = configuration[slug] ?? configuration.movies
    if (slug === 'genres' && liveGenres.length) return { ...base, filters: ['All genres', ...liveGenres] }
    return base
  }, [slug, liveGenres])
  // A home-page genre rail's "See all" link arrives as /genres?genre=Crime —
  // land straight on that genre's results instead of the "All genres" tab.
  const requestedGenre = searchParams.get('genre')
  const [activeFilter, setActiveFilter] = useState(
    () => (slug === 'genres' && requestedGenre && config.filters.includes(requestedGenre) ? requestedGenre : config.filters[0]),
  )
  // liveGenres (and therefore config.filters) loads asynchronously, so a
  // requested genre that isn't available yet on first render needs to be
  // applied once the real genre list comes in.
  useEffect(() => {
    if (slug === 'genres' && requestedGenre && config.filters.includes(requestedGenre)) setActiveFilter(requestedGenre)
  }, [slug, requestedGenre, config.filters])
  const isWatchlist = slug === 'watchlist'
  // Hooks must run unconditionally; only one branch's data is used per render.
  const catalog = useCatalogResults({ config, activeFilter })
  const watchlist = useWatchlistResults({ activeFilter, defaultFilter: config.filters[0] })
  const { results, isPending } = isWatchlist ? watchlist : catalog

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [filterOpen, setFilterOpen] = useState(false)
  const [sortBy, setSortBy] = useState<SortValue>('newest')

  const sortedResults = useMemo(() => {
    if (sortBy === 'newest') return results
    const list = [...results]
    if (sortBy === 'rating') list.sort((a, b) => (b.averageRating ?? b.score ?? 0) - (a.averageRating ?? a.score ?? 0))
    else if (sortBy === 'az') list.sort((a, b) => a.title.localeCompare(b.title))
    return list
  }, [results, sortBy])

  return <div className="mx-auto max-w-[1680px] px-4 py-8 sm:px-6 lg:px-10">
    <section className="relative overflow-hidden rounded-4xl border border-white/10 bg-[radial-gradient(circle_at_80%_0%,rgba(155,123,255,.23),transparent_30%),linear-gradient(120deg,#161a2a,#0c0e17)] p-7 sm:p-10">
      <p className="text-xs font-bold uppercase tracking-[.2em] text-brand">{config.eyebrow}</p>
      <h1 className="mt-3 max-w-2xl font-display text-4xl font-black tracking-[-.055em] sm:text-6xl">{config.title}</h1>
      <p className="mt-4 max-w-xl text-base leading-7 text-muted">{config.copy}</p>
      <div className="mt-7 flex flex-wrap gap-2">{config.filters.map((filter) => <button onClick={() => setActiveFilter(filter)} key={filter} aria-pressed={activeFilter === filter} className={`rounded-full px-4 py-2 text-sm font-bold transition ${activeFilter === filter ? 'bg-ink text-canvas' : 'border border-white/10 bg-white/[.05] text-muted hover:border-brand/50 hover:text-ink'}`}>{filter}</button>)}</div>
    </section>
    {isLivePage && liveStreams && liveStreams.length > 0 && <LiveNowRail streams={liveStreams} />}
    <div className="mt-9 flex flex-wrap items-center justify-between gap-4">
      <div className="flex items-center gap-2 text-sm">
        <button
          onClick={() => setViewMode('grid')}
          aria-pressed={viewMode === 'grid'}
          className={`inline-flex items-center gap-2 rounded-lg px-3 py-2 font-bold transition ${viewMode === 'grid' ? 'bg-white/10 text-ink' : 'text-muted hover:bg-white/5 hover:text-ink'}`}
        >
          <FiGrid /> Grid
        </button>
        <button
          onClick={() => setViewMode('list')}
          aria-pressed={viewMode === 'list'}
          className={`inline-flex items-center gap-2 rounded-lg px-3 py-2 font-bold transition ${viewMode === 'list' ? 'bg-white/10 text-ink' : 'text-muted hover:bg-white/5 hover:text-ink'}`}
        >
          <FiList /> List
        </button>
        <div className="relative">
          <button
            onClick={() => setFilterOpen((open) => !open)}
            aria-expanded={filterOpen}
            className={`inline-flex items-center gap-2 rounded-lg px-3 py-2 font-bold transition ${filterOpen ? 'bg-white/10 text-ink' : 'text-muted hover:bg-white/10 hover:text-ink'}`}
          >
            <FiFilter /> Filter
          </button>
          {filterOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setFilterOpen(false)} />
              <div className="absolute left-0 z-20 mt-2 w-48 overflow-hidden rounded-xl border border-white/10 bg-surface p-1.5 shadow-panel">
                <p className="px-2.5 pb-1 pt-1.5 text-[11px] font-bold uppercase tracking-[.14em] text-muted">Sort by</p>
                {SORT_OPTIONS.map(([value, label]) => (
                  <button
                    key={value}
                    onClick={() => { setSortBy(value); setFilterOpen(false) }}
                    className="flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-left text-sm text-muted hover:bg-white/10 hover:text-ink"
                  >
                    {label}{sortBy === value && <FiCheck className="text-brand" />}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
      <p className="text-sm text-muted">{sortedResults.length} titles · {activeFilter}</p>
    </div>
    {isPending ? (
      <div className="mt-6 grid grid-cols-2 gap-x-3 gap-y-7 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-7">{Array.from({ length: 14 }).map((_, i) => <Skeleton key={i} className="aspect-[2/3]" />)}</div>
    ) : sortedResults.length ? (
      viewMode === 'grid' ? (
        <div className="mt-6 grid grid-cols-2 gap-x-3 gap-y-7 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-7">{sortedResults.map((item) => <PosterCard key={item.id} item={item} />)}</div>
      ) : (
        <div className="mt-6 space-y-2">{sortedResults.map((item) => <ListRow key={item.id} item={item} />)}</div>
      )
    ) : (
      <div className="mt-6 rounded-3xl border border-dashed border-white/15 bg-surface p-12 text-center"><h2 className="font-display text-xl font-bold">Nothing here yet</h2><p className="mt-2 text-sm text-muted">{isWatchlist ? 'Add titles to your watchlist to see them here.' : 'No titles match this filter yet.'}</p><button onClick={() => setActiveFilter(config.filters[0])} className="mt-5 text-sm font-bold text-brand">Clear filter</button></div>
    )}
    <section className="mt-12 rounded-3xl border border-white/10 bg-surface p-6"><p className="flex items-center gap-2 text-xs font-bold uppercase tracking-[.18em] text-brand"><FiGlobe /> Global discovery</p><div className="mt-4 flex flex-wrap items-center justify-between gap-4"><p className="max-w-2xl text-sm leading-6 text-muted">Looking for something specific? Search the full catalogue by title, genre, or category.</p><Link to="/browse" className="inline-flex items-center gap-2 text-sm font-bold text-brand">Search the catalogue <FiChevronRight /></Link></div></section>
  </div>
}
