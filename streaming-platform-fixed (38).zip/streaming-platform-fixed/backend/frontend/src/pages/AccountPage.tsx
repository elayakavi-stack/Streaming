import { useEffect, useState } from 'react'
import { FiCheck, FiClock, FiDownload, FiLock, FiPlus, FiTrash2, FiUsers } from 'react-icons/fi'
import { Link } from 'react-router-dom'
import { useAccountStore } from '@/store/account-store'
import { useCreateProfile, useDeleteProfile, useProfiles } from '@/features/profiles/queries'
import { useCurrentUser } from '@/features/account/queries'
import { Button } from '@/components/ui/Button'

const colors = ['from-brand to-violet', 'from-violet to-[#f06cc1]', 'from-[#4ca5ff] to-[#5cdd9d]', 'from-[#f7b955] to-brand', 'from-[#f06cc1] to-[#4ca5ff]', 'from-[#5cdd9d] to-violet']

export function AccountPage() {
  const { data: user } = useCurrentUser()
  const { data: profiles = [], isPending, isError } = useProfiles()
  const { activeProfileId, setActiveProfile } = useAccountStore()
  const createProfile = useCreateProfile()
  const deleteProfile = useDeleteProfile()
  const [adding, setAdding] = useState(false)
  const [name, setName] = useState('')

  useEffect(() => {
    if (!activeProfileId && profiles.length) setActiveProfile(profiles[0].id)
  }, [activeProfileId, profiles, setActiveProfile])

  const submitProfile = (event: React.FormEvent) => {
    event.preventDefault()
    if (!name.trim()) return
    createProfile.mutate(
      { name: name.trim() },
      { onSuccess: () => { setName(''); setAdding(false) } },
    )
  }

  return <div className="mx-auto max-w-[1180px] px-4 py-10 sm:px-6 lg:px-10">
    <p className="text-xs font-bold uppercase tracking-[.2em] text-brand">My space</p>
    <h1 className="mt-2 font-display text-4xl font-black tracking-[-.05em]">Your viewing world.</h1>
    {user && <p className="mt-2 text-sm text-muted">Signed in as {user.email}</p>}
    <section className="mt-9 rounded-3xl border border-white/10 bg-surface p-5 sm:p-7">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h2 className="flex items-center gap-2 font-display text-xl font-bold"><FiUsers className="text-brand"/> Profiles</h2>
          <p className="mt-1 text-sm text-muted">Keep recommendations and history personal.</p>
        </div>
        <Button variant="secondary" onClick={() => setAdding(!adding)} disabled={profiles.length >= 6}><FiPlus/> Add profile</Button>
      </div>
      {isPending && <p className="mt-6 text-sm text-muted">Loading profiles…</p>}
      {isError && <p className="mt-6 text-sm text-danger">Couldn't load profiles. Check the API connection.</p>}
      {!isPending && !isError && profiles.length === 0 && <p className="mt-6 text-sm text-muted">No profiles yet — add your first one.</p>}
      <div className="mt-6 flex flex-wrap gap-4">
        {profiles.map((profile, index) => (
          <div key={profile.id} className={`relative rounded-2xl border p-3 text-left transition ${profile.id === activeProfileId ? 'border-brand bg-brand/10' : 'border-white/10 hover:border-white/30'}`}>
            <button onClick={() => setActiveProfile(profile.id)} className="block text-left">
              <span className={`grid h-16 w-16 place-items-center rounded-xl bg-gradient-to-br ${colors[index % colors.length]} text-2xl font-black text-canvas`}>{profile.name[0]}</span>
              <span className="mt-2 flex items-center gap-1 text-sm font-bold">{profile.name}{profile.id === activeProfileId && <FiCheck className="text-brand"/>}</span>
              <span className="text-xs text-muted">{profile.isKids ? 'Kids profile' : 'Standard'}</span>
            </button>
            <button onClick={() => deleteProfile.mutate(profile.id)} disabled={deleteProfile.isPending} aria-label={`Delete ${profile.name}`} className="absolute right-2 top-2 rounded-lg p-1 text-muted hover:bg-white/10 hover:text-danger"><FiTrash2 size={14}/></button>
          </div>
        ))}
      </div>
      {adding && <form onSubmit={submitProfile} className="mt-5 flex max-w-md gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Profile name" className="min-w-0 flex-1 rounded-xl border border-white/10 bg-canvas px-3 text-sm outline-none focus:border-brand"/>
        <Button type="submit" disabled={createProfile.isPending}>Create</Button>
      </form>}
      {createProfile.isError && <p className="mt-3 text-sm font-bold text-danger">{createProfile.error instanceof Error ? createProfile.error.message : 'Could not create profile.'}</p>}
    </section>
    <section className="mt-8 grid gap-4 md:grid-cols-3">
      <Panel icon={<FiClock/>} title="Watch history" body="Continue your stories across every device." action="View history" to="/history"/>
      <Panel icon={<FiDownload/>} title="Downloads" body="Manage titles saved for offline viewing." action="Manage downloads" to="/downloads"/>
      <Panel icon={<FiLock/>} title="Privacy" body="Control playback, data, and account privacy." action="Privacy settings" to="/settings"/>
    </section>
  </div>
}
function Panel({icon,title,body,action,to}:{icon:React.ReactNode;title:string;body:string;action:string;to:string}) { return <section className="rounded-2xl border border-white/10 bg-surface p-5"><span className="text-xl text-brand">{icon}</span><h2 className="mt-4 font-display text-lg font-bold">{title}</h2><p className="mt-2 text-sm leading-6 text-muted">{body}</p><Link to={to} className="mt-4 inline-block text-sm font-bold text-brand hover:text-ink">{action} →</Link></section> }
