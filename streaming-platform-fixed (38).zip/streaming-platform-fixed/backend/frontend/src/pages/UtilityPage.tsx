import { useState } from 'react'
import { FiBell, FiCheck, FiDownload, FiHelpCircle, FiMessageCircle, FiPlayCircle, FiTrash2, FiX } from 'react-icons/fi'
import { useLocation } from 'react-router-dom'
import { Skeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'
import {
  useDownloads,
  useRemoveDownload,
  useWatchHistory,
  useRemoveHistoryEntry,
  useClearHistory,
  useNotifications,
  useMarkNotificationRead,
  useMarkAllNotificationsRead,
  useDeleteNotification,
  useSubscription,
  useSetSubscription,
} from '@/features/account/queries'
import type { Plan } from '@/services/account-api'

const config = {
  downloads: { icon: FiDownload, eyebrow: 'Offline library', title: 'Downloads', copy: 'Keep your favourites ready for every journey.' },
  history: { icon: FiPlayCircle, eyebrow: 'Your activity', title: 'Watch history', copy: 'Pick up a story or remove it from your viewing history.' },
  notifications: { icon: FiBell, eyebrow: 'Inbox', title: 'Notifications', copy: 'New releases, saved-title updates, and account alerts.' },
  help: { icon: FiHelpCircle, eyebrow: 'Support', title: 'How can we help?', copy: 'Find answers or start a support request.' },
  subscription: { icon: FiCheck, eyebrow: 'Membership', title: 'Choose your plan', copy: 'One plan, every story. Upgrade or change anytime.' },
} as const

type Slug = keyof typeof config

function EmptyState({ label }: { label: string }) {
  return <div className="grid min-h-52 place-items-center text-center"><div><FiCheck className="mx-auto text-3xl text-success"/><h2 className="mt-3 font-display text-xl font-bold">{label}</h2></div></div>
}

function DownloadsPanel() {
  const { data: downloads = [], isPending, isError } = useDownloads()
  const removeDownload = useRemoveDownload()
  if (isPending) return <div className="space-y-3"><Skeleton className="h-16"/><Skeleton className="h-16"/></div>
  if (isError) return <p className="text-sm font-bold text-danger">Couldn't load your downloads.</p>
  if (downloads.length === 0) return <EmptyState label="No downloads yet." />
  return <div className="divide-y divide-white/10">
    {downloads.map((item) => <div key={item.id} className="flex items-center gap-4 py-4">
      <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/[.06] text-brand"><FiDownload/></span>
      <span className="flex-1"><span className="block text-sm font-bold">{item.video.title}</span><span className="mt-1 block text-xs text-muted">Saved {new Date(item.createdAt).toLocaleDateString()}</span></span>
      <button onClick={() => removeDownload.mutate(item.video.id)} disabled={removeDownload.isPending} aria-label="Remove download" className="rounded-lg p-2 text-muted hover:bg-white/10 hover:text-danger"><FiTrash2 size={14}/></button>
    </div>)}
  </div>
}

function HistoryPanel() {
  const { data: history = [], isPending, isError } = useWatchHistory()
  const removeEntry = useRemoveHistoryEntry()
  const clearHistory = useClearHistory()
  if (isPending) return <div className="space-y-3"><Skeleton className="h-16"/><Skeleton className="h-16"/></div>
  if (isError) return <p className="text-sm font-bold text-danger">Couldn't load your watch history.</p>
  if (history.length === 0) return <EmptyState label="No watch history yet." />
  return <>
    <div className="flex items-center justify-between"><h2 className="font-display text-xl font-bold">Recent items</h2><button onClick={() => clearHistory.mutate()} disabled={clearHistory.isPending} className="text-sm font-bold text-brand">Clear all</button></div>
    <div className="mt-5 divide-y divide-white/10">
      {history.map((entry) => <div key={entry.video.id} className="flex items-center gap-4 py-4">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/[.06] text-brand"><FiPlayCircle/></span>
        <span className="flex-1"><span className="block text-sm font-bold">{entry.video.title}</span><span className="mt-1 block text-xs text-muted">{entry.durationSeconds ? `${Math.round((entry.progressSeconds / entry.durationSeconds) * 100)}% watched` : `${Math.round(entry.progressSeconds / 60)} min in`} · Updated {new Date(entry.updatedAt).toLocaleDateString()}</span></span>
        <button onClick={() => removeEntry.mutate(entry.video.id)} disabled={removeEntry.isPending} aria-label="Remove from history" className="rounded-lg p-2 text-muted hover:bg-white/10 hover:text-danger"><FiTrash2 size={14}/></button>
      </div>)}
    </div>
  </>
}

function NotificationsPanel() {
  const { data: notifications = [], isPending, isError } = useNotifications()
  const markRead = useMarkNotificationRead()
  const markAllRead = useMarkAllNotificationsRead()
  const deleteNotification = useDeleteNotification()
  if (isPending) return <div className="space-y-3"><Skeleton className="h-16"/><Skeleton className="h-16"/></div>
  if (isError) return <p className="text-sm font-bold text-danger">Couldn't load notifications.</p>
  if (notifications.length === 0) return <EmptyState label="You're all caught up." />
  return <>
    <div className="flex items-center justify-between"><h2 className="font-display text-xl font-bold">Recent items</h2><button onClick={() => markAllRead.mutate()} disabled={markAllRead.isPending} className="text-sm font-bold text-brand">Mark all read</button></div>
    <div className="mt-5 divide-y divide-white/10">
      {notifications.map((item) => <div key={item.id} className={`flex items-center gap-4 py-4 ${item.isRead ? 'opacity-60' : ''}`}>
        <button onClick={() => !item.isRead && markRead.mutate(item.id)} className="flex flex-1 items-center gap-4 text-left">
          <span className={`grid h-10 w-10 place-items-center rounded-xl text-brand ${item.kind === 'error' ? 'bg-danger/15 text-danger' : item.kind === 'success' ? 'bg-success/15 text-success' : 'bg-white/[.06]'}`}><FiBell/></span>
          <span><span className="block text-sm font-bold">{item.title}</span>{item.message && <span className="mt-1 block text-xs text-muted">{item.message}</span>}<span className="mt-1 block text-xs text-muted">{new Date(item.createdAt).toLocaleString()}</span></span>
        </button>
        <button onClick={() => deleteNotification.mutate(item.id)} aria-label="Dismiss" className="rounded-lg p-2 text-muted hover:bg-white/10 hover:text-danger"><FiX size={14}/></button>
      </div>)}
    </div>
  </>
}

const plans: { id: Plan; label: string; price: number; blurb: string }[] = [
  { id: 'essential', label: 'Essential', price: 149, blurb: 'HD · 1 screen' },
  { id: 'premium', label: 'Premium', price: 299, blurb: 'Full HD · 2 screens' },
  { id: 'ultimate', label: 'Ultimate', price: 499, blurb: '4K UHD · 4 screens' },
]

function SubscriptionPanel() {
  const { data: subscription, isPending, isError } = useSubscription()
  const setSubscription = useSetSubscription()
  if (isPending) return <div className="mt-8 grid gap-4 md:grid-cols-3"><Skeleton className="h-48"/><Skeleton className="h-48"/><Skeleton className="h-48"/></div>
  if (isError) return <p className="mt-8 text-sm font-bold text-danger">Couldn't load your subscription.</p>
  return <div className="mt-8 grid gap-4 md:grid-cols-3">
    {plans.map((plan) => {
      const active = subscription?.plan === plan.id
      return <article key={plan.id} className={`rounded-3xl border p-6 ${active ? 'border-brand bg-brand/10' : 'border-white/10 bg-surface'}`}>
        <h2 className="font-display text-xl font-bold">{plan.label}</h2>
        <p className="mt-3 text-3xl font-black">₹{plan.price}<span className="text-sm font-medium text-muted">/month</span></p>
        <p className="mt-3 text-sm text-muted">{plan.blurb}</p>
        <Button variant={active ? 'secondary' : 'primary'} className="mt-6 w-full" disabled={active || setSubscription.isPending} onClick={() => setSubscription.mutate(plan.id)}>
          {active ? 'Current plan' : setSubscription.isPending && setSubscription.variables === plan.id ? 'Switching…' : 'Select plan'}
        </Button>
      </article>
    })}
  </div>
}

function HelpPanel() {
  return <section className="mt-8 rounded-3xl border border-white/10 bg-surface p-5 sm:p-7">
    <div className="flex items-center justify-between"><h2 className="font-display text-xl font-bold">Popular help topics</h2><button className="text-sm font-bold text-brand">Start a request</button></div>
    <div className="mt-5 divide-y divide-white/10">
      {['Managing your subscription', 'Fixing playback issues', 'Downloading titles for offline viewing'].map((item) => <button key={item} className="flex w-full items-center gap-4 py-4 text-left hover:bg-white/[.03]">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/[.06] text-brand"><FiMessageCircle/></span>
        <span className="block text-sm font-bold">{item}</span>
      </button>)}
    </div>
  </section>
}

export function UtilityPage() {
  const slug = useLocation().pathname.split('/')[1] as Slug
  const detail = config[slug] ?? config.help
  const Icon = detail.icon

  return <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
    <p className="text-xs font-bold uppercase tracking-[.2em] text-brand">{detail.eyebrow}</p>
    <h1 className="mt-2 flex items-center gap-3 font-display text-4xl font-black tracking-[-.05em]"><Icon className="text-brand"/>{detail.title}</h1>
    <p className="mt-3 max-w-xl text-muted">{detail.copy}</p>

    {slug === 'subscription' && <SubscriptionPanel/>}
    {slug === 'help' && <HelpPanel/>}
    {(slug === 'downloads' || slug === 'history' || slug === 'notifications') && <section className="mt-8 rounded-3xl border border-white/10 bg-surface p-5 sm:p-7">
      {slug === 'downloads' && <DownloadsPanel/>}
      {slug === 'history' && <HistoryPanel/>}
      {slug === 'notifications' && <NotificationsPanel/>}
    </section>}
  </div>
}
