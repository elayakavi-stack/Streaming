import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Search, SlidersHorizontal } from 'lucide-react'
import Navbar from '../components/Navbar'
import VideoCard from '../components/VideoCard'
import { getCatalog, getGenres } from '../api/client'

export default function Browse() {
  const [searchParams] = useSearchParams()
  const [items, setItems] = useState([])
  const [genres, setGenres] = useState([])
  const [query, setQuery] = useState(() => searchParams.get('q') || '')
  const [category, setCategory] = useState('')
  const [genre, setGenre] = useState('')
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(true)

  async function refresh(nextPage = page) {
    setLoading(true)
    try {
      const [catalog, genreList] = await Promise.all([getCatalog({ q: query, category, genre, page: nextPage, pageSize: 24 }), getGenres()])
      setItems(catalog.items)
      setGenres(genreList)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh(1)
  }, [query, category, genre])

  const allGenres = useMemo(() => genres, [genres])

  return (
    <div className="min-h-screen bg-void text-ivory">
      <Navbar />

      <main className="mx-auto max-w-[1440px] px-4 py-8 sm:px-6 lg:px-8">
        <div className="rounded-[24px] border border-white/10 bg-gradient-to-r from-[#13212b] via-[#0f171e] to-[#13212b] p-5 shadow-2xl shadow-black/30">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.28em] text-marquee">Browse all</p>
              <h1 className="mt-2 text-3xl font-black text-ivory md:text-4xl">Find your next screen pick</h1>
            </div>

            <div className="flex w-full max-w-xl items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2">
              <Search size={18} className="text-ash" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search titles, actors, directors..."
                className="w-full bg-transparent text-sm text-ivory outline-none placeholder:text-ash"
              />
            </div>
          </div>

          <div className="mt-5 grid gap-3 md:grid-cols-3">
            <label className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-3 text-sm text-ash">
              <SlidersHorizontal size={16} />
              <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full bg-transparent text-ivory outline-none">
                <option value="">All categories</option>
                <option value="Movie">Movies</option>
                <option value="TV Show">TV Shows</option>
                <option value="Original">Originals</option>
              </select>
            </label>

            <label className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-3 text-sm text-ash">
              <SlidersHorizontal size={16} />
              <select value={genre} onChange={(e) => setGenre(e.target.value)} className="w-full bg-transparent text-ivory outline-none">
                <option value="">All genres</option>
                {allGenres.map((item) => (
                  <option key={item} value={item}>{item}</option>
                ))}
              </select>
            </label>

            <button
              onClick={() => {
                setQuery('')
                setCategory('')
                setGenre('')
                setPage(1)
              }}
              className="rounded-xl bg-marquee px-4 py-3 text-sm font-bold text-void transition hover:bg-marquee-dim"
            >
              Reset filters
            </button>
          </div>
        </div>

        <section className="mt-8">
          {loading ? (
            <p className="text-ash">Loading catalog…</p>
          ) : items.length === 0 ? (
            <div className="rounded-2xl border border-white/10 bg-panel px-6 py-10 text-center text-ash">
              No titles match your filters right now.
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-6">
              {items.map((video) => (
                <VideoCard key={video.id} video={video} />
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  )
}
