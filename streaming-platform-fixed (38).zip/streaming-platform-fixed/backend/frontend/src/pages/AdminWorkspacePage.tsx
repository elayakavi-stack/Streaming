import { useState } from 'react'
import { FiAlertCircle, FiCheckCircle, FiEdit2, FiFilm, FiFolder, FiImage, FiPlus, FiRadio, FiRefreshCw, FiTrash2, FiUploadCloud, FiUser, FiX } from 'react-icons/fi'
import { Link, useLocation } from 'react-router-dom'
import { discoveryKeys, useAddSubtitle, useContentCatalog, useRemoveSubtitle, useAddAudioTrack, useRemoveAudioTrack } from '@/features/discovery/queries'
import { contentApi } from '@/services/content-api'
import type { ContentCard, SubtitleTrack, PendingAudioSource } from '@/types/content'
import { COMMON_GENRES, COMMON_MOODS } from '@/constants/genres'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Skeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'
import {
  useAdminUsers,
  useUpdateAdminUser,
  useDeleteAdminUser,
  useAdminCategories,
  useCreateCategory,
  useDeleteCategory,
  useAdminReports,
  useUpdateReportStatus,
} from '@/features/admin/queries'
import type { AdminUser } from '@/services/admin-api'

function StatusBadge({ value }: { value: string }) {
  const positive = ['active', 'public', 'resolved', 'ready'].includes(value.toLowerCase())
  const negative = ['disabled', 'failed', 'open'].includes(value.toLowerCase())
  const tone = positive ? 'bg-success/15 text-success' : negative ? 'bg-danger/15 text-danger' : 'bg-brand/15 text-brand'
  return <span className={`rounded-full px-2.5 py-1 text-xs font-bold capitalize ${tone}`}>{value.replace('_', ' ')}</span>
}

function WorkspaceShell({ icon: Icon, title, action, children, note }: { icon: typeof FiUser; title: string; action?: React.ReactNode; children: React.ReactNode; note: string }) {
  return <div className="mx-auto max-w-[1680px] px-4 py-8 sm:px-6 lg:px-10">
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div><p className="text-xs font-bold uppercase tracking-[.2em] text-brand">Admin workspace</p><h1 className="mt-2 flex items-center gap-3 font-display text-4xl font-black tracking-[-.05em]"><Icon className="text-brand" />{title}</h1></div>
      <div className="flex gap-2"><Link to="/admin" className="rounded-xl border border-white/10 px-3 py-2 text-sm font-bold text-muted hover:text-ink">Overview</Link>{action}</div>
    </div>
    {children}
    <p className="mt-5 flex items-center gap-2 text-sm text-muted"><FiCheckCircle className="text-success" /> {note}</p>
  </div>
}

function Table({ columns, children }: { columns: string[]; children: React.ReactNode }) {
  return <div className="mt-8 overflow-x-auto rounded-3xl border border-white/10 bg-surface">
    <table className="w-full min-w-[700px] text-left text-sm">
      <thead className="bg-white/[.03] text-xs uppercase tracking-[.15em] text-muted"><tr>{columns.map((c) => <th key={c} className="px-5 py-4 font-bold">{c}</th>)}<th className="px-5 py-4" /></tr></thead>
      <tbody>{children}</tbody>
    </table>
  </div>
}

function SubtitlesManager({ videoId, initialSubtitles }: { videoId: string; initialSubtitles: SubtitleTrack[] }) {
  const [subtitles, setSubtitles] = useState<SubtitleTrack[]>(initialSubtitles)
  const [language, setLanguage] = useState('')
  const [label, setLabel] = useState('')
  const [isDefault, setIsDefault] = useState(subtitles.length === 0)
  const [file, setFile] = useState<File | null>(null)
  const addSubtitle = useAddSubtitle()
  const removeSubtitle = useRemoveSubtitle()

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!file || !language.trim() || !label.trim()) return
    addSubtitle.mutate(
      { videoId, language: language.trim(), label: label.trim(), isDefault, file },
      {
        onSuccess: (created) => {
          setSubtitles((current) => [...current, created])
          setLanguage('')
          setLabel('')
          setIsDefault(false)
          setFile(null)
        },
      },
    )
  }

  const remove = (subtitleId: string) => {
    removeSubtitle.mutate(
      { videoId, subtitleId },
      { onSuccess: () => setSubtitles((current) => current.filter((s) => s.id !== subtitleId)) },
    )
  }

  return (
    <div className="mt-2 rounded-2xl border border-white/10 bg-canvas p-4">
      <h3 className="text-sm font-bold text-ink">Subtitles</h3>
      <p className="mt-1 text-xs text-muted">Upload a WebVTT (.vtt) file per language. Viewers pick a language — or "Off" — from the player's settings menu.</p>
      {subtitles.length > 0 && (
        <ul className="mt-3 space-y-2">
          {subtitles.map((s) => (
            <li key={s.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-surface px-3 py-2 text-sm">
              <span className="font-semibold text-ink">{s.label} <span className="ml-1 text-xs font-normal text-muted">({s.language}){s.isDefault ? ' · default' : ''}</span></span>
              <button type="button" onClick={() => remove(s.id)} disabled={removeSubtitle.isPending} className="text-xs font-bold text-danger">Remove</button>
            </li>
          ))}
        </ul>
      )}
      <form onSubmit={submit} className="mt-3 space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Label (e.g. English)" className="input" />
          <input value={language} onChange={(e) => setLanguage(e.target.value)} placeholder="Language code (e.g. en)" className="input" />
        </div>
        <div className="flex items-center gap-3">
          <input type="file" accept=".vtt,text/vtt" onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="flex-1 text-xs text-muted file:mr-3 file:rounded-lg file:border-0 file:bg-white/10 file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-ink" />
          <label className="flex shrink-0 items-center gap-1.5 text-xs font-bold text-muted"><input type="checkbox" checked={isDefault} onChange={(e) => setIsDefault(e.target.checked)} /> Default</label>
        </div>
        {addSubtitle.isError && <p className="text-xs font-bold text-danger">{addSubtitle.error instanceof Error ? addSubtitle.error.message : 'Could not upload subtitle.'}</p>}
        <Button type="submit" variant="secondary" disabled={!file || !language.trim() || !label.trim() || addSubtitle.isPending}>
          {addSubtitle.isPending ? 'Uploading…' : 'Add subtitle'}
        </Button>
      </form>
    </div>
  )
}

function AudioTracksManager({ videoId, initialTracks, videoStatus }: { videoId: string; initialTracks: PendingAudioSource[]; videoStatus?: ContentCard['status'] }) {
  const [tracks, setTracks] = useState<PendingAudioSource[]>(initialTracks)
  const [language, setLanguage] = useState('')
  const [label, setLabel] = useState('')
  const [isDefault, setIsDefault] = useState(tracks.length === 0)
  const [file, setFile] = useState<File | null>(null)
  const addTrack = useAddAudioTrack()
  const removeTrack = useRemoveAudioTrack()
  // The backend rejects adding/removing tracks while a transcode is
  // already mid-run — mirror that here so the button disables instead of
  // round-tripping to a 409.
  const locked = videoStatus === 'processing'

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!file || !language.trim() || !label.trim()) return
    addTrack.mutate(
      { videoId, language: language.trim(), label: label.trim(), isDefault, file },
      {
        onSuccess: (created) => {
          setTracks((current) => [...current, created])
          setLanguage('')
          setLabel('')
          setIsDefault(false)
          setFile(null)
        },
      },
    )
  }

  const remove = (audioSourceId: string) => {
    removeTrack.mutate(
      { videoId, audioSourceId },
      { onSuccess: () => setTracks((current) => current.filter((t) => t.id !== audioSourceId)) },
    )
  }

  return (
    <div className="mt-2 rounded-2xl border border-white/10 bg-canvas p-4">
      <h3 className="text-sm font-bold text-ink">Audio tracks</h3>
      <p className="mt-1 text-xs text-muted">
        Add a separate dub — e.g. a standalone Hindi track for an English title. For a title that's already live,
        adding or removing a track automatically re-processes it so the change takes effect; it'll briefly show as
        "Processing" while that runs.
      </p>
      {tracks.length > 0 && (
        <ul className="mt-3 space-y-2">
          {tracks.map((t) => (
            <li key={t.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-surface px-3 py-2 text-sm">
              <span className="font-semibold text-ink">{t.label} <span className="ml-1 text-xs font-normal text-muted">({t.language}){t.isDefault ? ' · default' : ''}</span></span>
              <button type="button" onClick={() => remove(t.id)} disabled={removeTrack.isPending || locked} className="text-xs font-bold text-danger disabled:opacity-50">Remove</button>
            </li>
          ))}
        </ul>
      )}
      <form onSubmit={submit} className="mt-3 space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Label (e.g. Hindi)" className="input" disabled={locked} />
          <input value={language} onChange={(e) => setLanguage(e.target.value)} placeholder="Language code (e.g. hi)" className="input" disabled={locked} />
        </div>
        <div className="flex items-center gap-3">
          <input type="file" accept="audio/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} disabled={locked} className="flex-1 text-xs text-muted file:mr-3 file:rounded-lg file:border-0 file:bg-white/10 file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-ink" />
          <label className="flex shrink-0 items-center gap-1.5 text-xs font-bold text-muted"><input type="checkbox" checked={isDefault} onChange={(e) => setIsDefault(e.target.checked)} disabled={locked} /> Default</label>
        </div>
        {addTrack.isError && <p className="text-xs font-bold text-danger">{addTrack.error instanceof Error ? addTrack.error.message : 'Could not upload audio track.'}</p>}
        {locked && <p className="text-xs font-bold text-brand">This title is processing — try again once it finishes.</p>}
        <Button type="submit" variant="secondary" disabled={!file || !language.trim() || !label.trim() || addTrack.isPending || locked}>
          {addTrack.isPending ? 'Uploading…' : 'Add audio track'}
        </Button>
      </form>
    </div>
  )
}

function EditTitleModal({ item, onClose }: { item: ContentCard; onClose: () => void }) {
  const queryClient = useQueryClient()
  const [form, setForm] = useState({
    title: item.title,
    description: item.synopsis ?? '',
    category: item.rawCategory ?? (item.kind === 'series' ? 'TV Show' : 'Movie'),
    genre: item.genres[0] ?? '',
    subGenre: item.subGenre ?? '',
    rating: item.maturityRating,
    imdbScore: item.score ? String(item.score) : '',
    releaseYear: item.releaseYear,
    castMembers: item.castMembers ?? '',
    director: item.director ?? '',
    originalLanguage: item.originalLanguage ?? '',
  })
  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) => setForm((f) => ({ ...f, [key]: value }))
  const [moods, setMoods] = useState<string[]>(item.moods ?? [])
  const toggleMood = (mood: string) => setMoods((current) => (current.includes(mood) ? current.filter((m) => m !== mood) : [...current, mood]))

  // Poster/backdrop stay separate from `form`: they need an S3 round-trip
  // (uploadArtwork) before the URL can be saved, unlike the rest of the
  // fields which patch straight through. `null` here means "no change" —
  // only set when the admin actually picks a replacement file.
  const [posterFile, setPosterFile] = useState<File | null>(null)
  const [backdropFile, setBackdropFile] = useState<File | null>(null)
  const [posterPreview, setPosterPreview] = useState(item.posterUrl)
  const [backdropPreview, setBackdropPreview] = useState(item.backdropUrl ?? '')

  const pickPoster = (file: File | null) => {
    setPosterFile(file)
    setPosterPreview(file ? URL.createObjectURL(file) : item.posterUrl)
  }
  const pickBackdrop = (file: File | null) => {
    setBackdropFile(file)
    setBackdropPreview(file ? URL.createObjectURL(file) : (item.backdropUrl ?? ''))
  }

  const save = useMutation({
    mutationFn: async () => {
      const posterUrl = posterFile ? await contentApi.uploadArtwork(posterFile, 'poster') : undefined
      const backdropUrl = backdropFile ? await contentApi.uploadArtwork(backdropFile, 'backdrop') : undefined
      return contentApi.updateVideo(item.id, { ...form, moods, posterUrl, backdropUrl })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['discovery'] })
      onClose()
    },
  })

  return <div className="fixed inset-0 z-[70] grid place-items-center bg-black/70 p-4" onClick={onClose}>
    <div onClick={(e) => e.stopPropagation()} className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-3xl border border-white/10 bg-surface p-6 shadow-panel">
      <div className="flex items-center justify-between"><h2 className="font-display text-xl font-bold">Edit title</h2><button onClick={onClose} aria-label="Close" className="rounded-lg p-1 text-muted hover:bg-white/10 hover:text-ink"><FiX/></button></div>
      <form onSubmit={(e) => { e.preventDefault(); save.mutate() }} className="mt-5 space-y-4">
        <label className="block text-sm font-bold">Title<input required value={form.title} onChange={(e) => set('title', e.target.value)} className="input mt-1"/></label>
        <label className="block text-sm font-bold">Description<textarea value={form.description} onChange={(e) => set('description', e.target.value)} rows={3} className="input mt-1"/></label>
        <div className="grid grid-cols-2 gap-3">
          <div className="block text-sm font-bold">Poster thumbnail
            <label className="mt-1 flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-white/20 bg-canvas px-3 py-3 text-muted hover:border-brand">
              {posterPreview ? (
                <img src={posterPreview} alt="" className="h-12 w-9 shrink-0 rounded object-cover" />
              ) : (
                <span className="text-brand"><FiImage /></span>
              )}
              <span className="truncate text-xs font-normal">{posterFile?.name || 'Replace poster image'}</span>
              <input className="hidden" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => pickPoster(e.target.files?.[0] ?? null)} />
            </label>
          </div>
          <div className="block text-sm font-bold">Backdrop image
            <label className="mt-1 flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-white/20 bg-canvas px-3 py-3 text-muted hover:border-brand">
              {backdropPreview ? (
                <img src={backdropPreview} alt="" className="h-12 w-20 shrink-0 rounded object-cover" />
              ) : (
                <span className="text-brand"><FiImage /></span>
              )}
              <span className="truncate text-xs font-normal">{backdropFile?.name || 'Replace backdrop image'}</span>
              <input className="hidden" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => pickBackdrop(e.target.files?.[0] ?? null)} />
            </label>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label className="block text-sm font-bold">Category
            <select value={form.category} onChange={(e) => set('category', e.target.value)} className="input mt-1"><option>Movie</option><option>TV Show</option><option>Sports</option><option>Original</option></select>
          </label>
          <label className="block text-sm font-bold">Release year<input type="number" value={form.releaseYear} onChange={(e) => set('releaseYear', Number(e.target.value))} className="input mt-1"/></label>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label className="block text-sm font-bold">Main genre
            <select required value={form.genre} onChange={(e) => set('genre', e.target.value)} className="input mt-1">
              <option value="" disabled>Choose one genre…</option>
              {COMMON_GENRES.map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
            <span className="mt-1 block text-xs font-normal text-muted">Decides the home page genre row. One genre only — combining two here (e.g. "Action, Thriller") fragments the title across mismatched rails instead of one clean row.</span>
          </label>
          <label className="block text-sm font-bold">Sub-genre
            <select value={form.subGenre} onChange={(e) => set('subGenre', e.target.value)} className="input mt-1">
              <option value="">None</option>
              {COMMON_GENRES.filter((g) => g !== form.genre).map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
          </label>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label className="block text-sm font-bold">Maturity rating<input value={form.rating} onChange={(e) => set('rating', e.target.value)} className="input mt-1"/></label>
          <label className="block text-sm font-bold">IMDb score<input value={form.imdbScore} onChange={(e) => set('imdbScore', e.target.value)} className="input mt-1"/></label>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label className="block text-sm font-bold">Director<input value={form.director} onChange={(e) => set('director', e.target.value)} className="input mt-1"/></label>
          <label className="block text-sm font-bold">Cast members<input value={form.castMembers} onChange={(e) => set('castMembers', e.target.value)} className="input mt-1"/></label>
        </div>
        <label className="block text-sm font-bold">Original audio language<input value={form.originalLanguage} onChange={(e) => set('originalLanguage', e.target.value)} placeholder="Language code (e.g. en, te)" className="input mt-1"/>
          <span className="mt-1 block text-xs font-normal text-muted">Labels the video's own embedded audio track in the player's audio menu (it otherwise shows as "Unknown" — most files don't tag this themselves). Saving here only updates the label after you also hit <strong>Reprocess</strong> below, since it's baked into the streaming files at transcode time.</span>
        </label>
        <div className="block text-sm font-bold">Moods
          <div className="mt-1 flex flex-wrap gap-2">
            {COMMON_MOODS.map((mood) => (
              <button
                key={mood}
                type="button"
                onClick={() => toggleMood(mood)}
                className={`rounded-full border px-3 py-1.5 text-xs font-bold transition ${moods.includes(mood) ? 'border-brand bg-brand/15 text-brand' : 'border-white/10 text-muted hover:text-ink'}`}
              >
                {mood}
              </button>
            ))}
          </div>
          <span className="mt-1 block text-xs font-normal text-muted">Powers "More like this mood" recommendations while watching, and a mood-based home rail.</span>
        </div>
        {save.isError && <p className="text-sm font-bold text-danger">{save.error instanceof Error ? save.error.message : 'Could not save changes.'}</p>}
        <div className="flex justify-end gap-3 pt-2"><Button type="button" variant="secondary" onClick={onClose}>Cancel</Button><Button type="submit" disabled={save.isPending}>{save.isPending ? 'Saving…' : 'Save changes'}</Button></div>
      </form>
      <SubtitlesManager videoId={item.id} initialSubtitles={item.subtitles ?? []} />
      <AudioTracksManager videoId={item.id} initialTracks={item.pendingAudioSources ?? []} videoStatus={item.status} />
    </div>
  </div>
}

function ContentTab() {
  const { data, isPending } = useContentCatalog({ pageSize: 100 })
  const queryClient = useQueryClient()
  const items = data?.data ?? []
  const [editing, setEditing] = useState<ContentCard | null>(null)
  const [reprocessingId, setReprocessingId] = useState<string | null>(null)

  const remove = async (id: string) => {
    if (!confirm('Delete this title? This cannot be undone.')) return
    await contentApi.deleteVideo(id)
    queryClient.invalidateQueries({ queryKey: ['discovery'] })
    queryClient.invalidateQueries({ queryKey: discoveryKeys.details(id) })
  }

  const reprocess = async (id: string, title: string) => {
    if (!confirm(`Reprocess "${title}"? This re-runs the current transcode pipeline (multi-quality, multi-audio) against the original upload and replaces its streaming files.`)) return
    setReprocessingId(id)
    try {
      await contentApi.reprocessVideo(id)
      // `useContentDetails` (what the player page reads) caches under
      // discoveryKeys.details(id) = ['content', id] — a completely
      // different key from the ['discovery', ...] catalog/home queries.
      // Only invalidating 'discovery' left the player page serving its
      // stale cached video object (old playback_url) for up to the
      // query's 30s staleTime, or indefinitely if the page never
      // happened to remount — which looked exactly like the reprocess
      // hadn't done anything, even once the backend genuinely had.
      queryClient.invalidateQueries({ queryKey: ['discovery'] })
      queryClient.invalidateQueries({ queryKey: discoveryKeys.details(id) })
    } finally {
      setReprocessingId(null)
    }
  }

  return <WorkspaceShell icon={FiFilm} title="Movies & series" note="Live from GET /videos/catalog — delete removes the title and its media permanently."
    action={<Link to="/admin/upload" className="rounded-xl bg-brand px-3 py-2 text-sm font-bold text-canvas">New title</Link>}>
    <Table columns={['Title', 'Type', 'Release', 'Status']}>
      {isPending && <tr><td className="px-5 py-6 text-muted" colSpan={5}>Loading…</td></tr>}
      {!isPending && items.length === 0 && <tr><td className="px-5 py-6 text-muted" colSpan={5}>No titles yet — upload one to see it here.</td></tr>}
      {items.map((item) => <tr key={item.id} className="border-t border-white/[.07] hover:bg-white/[.025]">
        <td className="px-5 py-5 font-medium text-ink">{item.title}</td>
        <td className="px-5 py-5 font-medium text-ink">{item.kind === 'series' ? 'Series' : 'Movie'}</td>
        <td className="px-5 py-5 font-medium text-ink">{item.releaseYear}</td>
        <td className="px-5 py-5"><StatusBadge value={item.status ?? 'ready'} /></td>
        <td className="px-5 py-5 text-right">
          <div className="flex items-center justify-end gap-4">
            <button onClick={() => setEditing(item)} className="inline-flex items-center gap-1 text-xs font-bold text-brand"><FiEdit2 size={14} /> Edit</button>
            {(item.status === 'ready' || item.status === 'failed') && (
              <button onClick={() => reprocess(item.id, item.title)} disabled={reprocessingId === item.id} className="inline-flex items-center gap-1 text-xs font-bold text-muted hover:text-ink disabled:opacity-50">
                <FiRefreshCw size={14} className={reprocessingId === item.id ? 'animate-spin' : ''} /> {reprocessingId === item.id ? 'Queuing…' : 'Reprocess'}
              </button>
            )}
            <button onClick={() => remove(item.id)} className="inline-flex items-center gap-1 text-xs font-bold text-danger"><FiTrash2 size={14} /> Delete</button>
          </div>
        </td>
      </tr>)}
    </Table>
    {editing && <EditTitleModal item={editing} onClose={() => setEditing(null)} />}
  </WorkspaceShell>
}

const PLAN_OPTIONS: AdminUser['plan'][] = ['essential', 'premium', 'ultimate']

function UsersTab() {
  const { data: users = [], isPending, isError } = useAdminUsers()
  const updateUser = useUpdateAdminUser()
  const deleteUser = useDeleteAdminUser()

  const remove = (id: string, email: string) => {
    if (!confirm(`Delete ${email}? This cannot be undone.`)) return
    deleteUser.mutate(id)
  }

  return <WorkspaceShell icon={FiUser} title="Users" note="Live from GET /admin/users — plan and access changes apply immediately.">
    {isPending && <div className="mt-8 space-y-2"><Skeleton className="h-14" /><Skeleton className="h-14" /></div>}
    {isError && <p className="mt-8 text-sm font-bold text-danger">Couldn't load users.</p>}
    {!isPending && !isError && <Table columns={['Viewer', 'Plan', 'Titles uploaded', 'Status', 'Streaming']}>
      {users.map((u) => <tr key={u.id} className="border-t border-white/[.07] hover:bg-white/[.025]">
        <td className="px-5 py-5 font-medium text-ink">{u.email}{u.isAdmin && <span className="ml-2 rounded-full bg-brand/15 px-2 py-0.5 text-xs font-bold text-brand">Admin</span>}</td>
        <td className="px-5 py-5">
          <select value={u.plan} disabled={updateUser.isPending} onChange={(e) => updateUser.mutate({ id: u.id, patch: { plan: e.target.value as AdminUser['plan'] } })} className="rounded-lg border border-white/10 bg-canvas px-2 py-1 text-sm capitalize outline-none focus:border-brand">
            {PLAN_OPTIONS.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
        </td>
        <td className="px-5 py-5 font-medium text-ink">{u.titlesUploaded}</td>
        <td className="px-5 py-5"><StatusBadge value={u.isActive ? 'active' : 'disabled'} /></td>
        <td className="px-5 py-5">
          <div className="flex items-center gap-2">
            {u.isAdmin ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-brand/15 px-2.5 py-1 text-xs font-bold text-brand"><FiRadio size={12} /> Always on</span>
            ) : u.canStream ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-success/15 px-2.5 py-1 text-xs font-bold text-success"><FiRadio size={12} /> Approved</span>
            ) : u.streamRequestedAt ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-brand/15 px-2.5 py-1 text-xs font-bold text-brand">Requested</span>
            ) : (
              <span className="text-xs text-muted">—</span>
            )}
            {!u.isAdmin && (
              <button
                onClick={() => updateUser.mutate({ id: u.id, patch: { canStream: !u.canStream } })}
                disabled={updateUser.isPending}
                className={`text-xs font-bold ${u.canStream ? 'text-danger' : 'text-success'}`}
              >
                {u.canStream ? 'Revoke' : 'Approve'}
              </button>
            )}
          </div>
        </td>
        <td className="px-5 py-5 text-right">
          <div className="flex items-center justify-end gap-3">
            <button onClick={() => updateUser.mutate({ id: u.id, patch: { isActive: !u.isActive } })} disabled={updateUser.isPending} className={`text-xs font-bold ${u.isActive ? 'text-danger' : 'text-success'}`}>{u.isActive ? 'Disable' : 'Enable'}</button>
            <button onClick={() => remove(u.id, u.email)} disabled={deleteUser.isPending} className="inline-flex items-center gap-1 text-xs font-bold text-danger"><FiTrash2 size={14} /> Delete</button>
          </div>
        </td>
      </tr>)}
    </Table>}
    {deleteUser.isError && <p className="mt-3 text-sm font-bold text-danger">{deleteUser.error instanceof Error ? deleteUser.error.message : 'Could not delete user.'}</p>}
  </WorkspaceShell>
}

function CategoriesTab() {
  const { data: categories = [], isPending, isError } = useAdminCategories()
  const createCategory = useCreateCategory()
  const deleteCategory = useDeleteCategory()
  const [name, setName] = useState('')

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) return
    createCategory.mutate({ name: name.trim() }, { onSuccess: () => setName('') })
  }

  return <WorkspaceShell icon={FiFolder} title="Categories" note="Live from GET /admin/categories — title counts match titles sharing that genre."
    action={<form onSubmit={submit} className="flex gap-2"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="New category" className="min-w-0 rounded-xl border border-white/10 bg-canvas px-3 py-2 text-sm outline-none focus:border-brand" /><Button type="submit" disabled={createCategory.isPending}><FiPlus /> Add</Button></form>}>
    {isPending && <div className="mt-8 space-y-2"><Skeleton className="h-14" /><Skeleton className="h-14" /></div>}
    {isError && <p className="mt-8 text-sm font-bold text-danger">Couldn't load categories.</p>}
    {!isPending && !isError && <Table columns={['Collection', 'Titles', 'Last updated', 'Visibility']}>
      {categories.length === 0 && <tr><td className="px-5 py-6 text-muted" colSpan={5}>No categories yet — add your first one.</td></tr>}
      {categories.map((c) => <tr key={c.id} className="border-t border-white/[.07] hover:bg-white/[.025]">
        <td className="px-5 py-5 font-medium text-ink">{c.name}</td>
        <td className="px-5 py-5 font-medium text-ink">{c.titleCount}</td>
        <td className="px-5 py-5 font-medium text-ink">{new Date(c.updatedAt).toLocaleDateString()}</td>
        <td className="px-5 py-5"><StatusBadge value={c.isPublic ? 'public' : 'private'} /></td>
        <td className="px-5 py-5 text-right"><button onClick={() => deleteCategory.mutate(c.id)} disabled={deleteCategory.isPending} className="inline-flex items-center gap-1 text-xs font-bold text-danger"><FiTrash2 size={14} /> Delete</button></td>
      </tr>)}
    </Table>}
    {createCategory.isError && <p className="mt-3 text-sm font-bold text-danger">{createCategory.error instanceof Error ? createCategory.error.message : 'Could not create category.'}</p>}
  </WorkspaceShell>
}

function ReportsTab() {
  const { data: reports = [], isPending, isError } = useAdminReports()
  const updateStatus = useUpdateReportStatus()

  return <WorkspaceShell icon={FiAlertCircle} title="Reports" note="Live from GET /admin/reports — filed by viewers from a title's page.">
    {isPending && <div className="mt-8 space-y-2"><Skeleton className="h-14" /><Skeleton className="h-14" /></div>}
    {isError && <p className="mt-8 text-sm font-bold text-danger">Couldn't load reports.</p>}
    {!isPending && !isError && <Table columns={['Report', 'Subject', 'Received', 'Resolution']}>
      {reports.length === 0 && <tr><td className="px-5 py-6 text-muted" colSpan={5}>No reports filed yet.</td></tr>}
      {reports.map((r) => <tr key={r.id} className="border-t border-white/[.07] hover:bg-white/[.025]">
        <td className="px-5 py-5 font-medium text-ink">{r.subject}</td>
        <td className="px-5 py-5 font-medium text-ink">{r.videoTitle ?? '—'}<span className="ml-1 text-xs text-muted">{r.reporterEmail}</span></td>
        <td className="px-5 py-5 font-medium text-ink">{new Date(r.createdAt).toLocaleString()}</td>
        <td className="px-5 py-5"><StatusBadge value={r.status} /></td>
        <td className="px-5 py-5 text-right">
          {r.status !== 'resolved' && <select value={r.status} disabled={updateStatus.isPending} onChange={(e) => updateStatus.mutate({ id: r.id, status: e.target.value as typeof r.status })} className="rounded-lg border border-white/10 bg-canvas px-2 py-1 text-xs capitalize outline-none focus:border-brand">
            <option value="open">Open</option>
            <option value="in_review">In review</option>
            <option value="resolved">Resolved</option>
          </select>}
        </td>
      </tr>)}
    </Table>}
  </WorkspaceShell>
}

const PIPELINE_LABEL: Record<string, string> = { pending_upload: 'Queued for encoding', processing: 'Encoding', failed: 'Failed — needs re-upload' }

function UploadsTab() {
  const { data, isPending } = useContentCatalog({ pageSize: 100 })
  const items = (data?.data ?? []).filter((item) => item.status !== 'ready')

  return <WorkspaceShell icon={FiUploadCloud} title="Uploads" note="Derived from the catalog's own processing status — no separate uploads model needed.">
    <Table columns={['Asset', 'Release', 'Pipeline', 'Status']}>
      {isPending && <tr><td className="px-5 py-6 text-muted" colSpan={4}>Loading…</td></tr>}
      {!isPending && items.length === 0 && <tr><td className="px-5 py-6 text-muted" colSpan={4}>Nothing in the pipeline — every title has finished processing.</td></tr>}
      {items.map((item) => <tr key={item.id} className="border-t border-white/[.07] hover:bg-white/[.025]">
        <td className="px-5 py-5 font-medium text-ink">{item.title}</td>
        <td className="px-5 py-5 font-medium text-ink">{item.releaseYear}</td>
        <td className="px-5 py-5 font-medium text-ink">{PIPELINE_LABEL[item.status ?? ''] ?? item.status}</td>
        <td className="px-5 py-5"><StatusBadge value={item.status ?? 'processing'} /></td>
      </tr>)}
    </Table>
  </WorkspaceShell>
}

export function AdminWorkspacePage() {
  const key = useLocation().pathname.slice(1)
  if (key === 'admin/content') return <ContentTab />
  if (key === 'admin/users') return <UsersTab />
  if (key === 'admin/categories') return <CategoriesTab />
  if (key === 'admin/reports') return <ReportsTab />
  if (key === 'admin/uploads') return <UploadsTab />
  return <UsersTab />
}
