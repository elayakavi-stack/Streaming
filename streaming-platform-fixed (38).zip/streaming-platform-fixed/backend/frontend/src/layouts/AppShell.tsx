import { motion } from 'framer-motion'
import { useEffect } from 'react'
import { Bell, Menu, Search } from 'lucide-react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { primaryNavigation } from '@/constants/navigation'
import { useUiStore } from '@/store/ui-store'
import { AppFooter } from '@/components/system/AppFooter'
import { AccountMenu } from '@/components/system/AccountMenu'
import { authApi } from '@/services/auth-api'
import { useCurrentUser, useNotifications } from '@/features/account/queries'

export function AppShell() {
  const { setSearchOpen, isSidebarOpen, setSidebarOpen } = useUiStore()
  const navigate = useNavigate()
  const signedIn = authApi.isSignedIn()
  const { data: user } = useCurrentUser()
  const { data: notifications } = useNotifications({ enabled: signedIn })
  const unreadCount = notifications?.filter((n) => !n.isRead).length ?? 0

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null
      if (target?.matches('input, textarea, select, [contenteditable="true"]')) return
      if (event.key === '/') { event.preventDefault(); setSearchOpen(true); navigate('/browse') }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [navigate, setSearchOpen])
  return <div className="min-h-screen bg-canvas text-ink"><header className="sticky top-0 z-50 border-b border-white/[.07] bg-canvas/75 backdrop-blur-2xl"><div className="mx-auto flex h-16 max-w-[1680px] items-center gap-3 px-4 sm:px-6"><button onClick={() => setSidebarOpen(!isSidebarOpen)} className="rounded-lg p-2 text-muted hover:bg-white/10 lg:hidden" aria-label="Open menu"><Menu size={21}/></button><NavLink to="/" className="mr-4 font-display text-xl font-black tracking-tight"><span className="text-brand">NOVA</span>PLAY</NavLink><nav className="hidden items-center gap-1 lg:flex">{primaryNavigation.map(({ label, to }) => <NavLink key={to} to={to} className={({ isActive }) => `rounded-lg px-3 py-2 text-sm font-semibold transition ${isActive ? 'bg-white/10 text-ink' : 'text-muted hover:text-ink'}`}>{label}</NavLink>)}</nav><div className="ml-auto flex items-center gap-2"><button onClick={() => { setSearchOpen(true); navigate('/browse') }} className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[.06] px-3 py-2 text-sm text-muted hover:border-brand/40 hover:text-ink"><Search size={16}/><span className="hidden sm:inline">Search</span><kbd className="hidden rounded bg-white/10 px-1.5 py-.5 text-[10px] lg:inline">/</kbd></button>{signedIn ? <><button onClick={() => navigate('/notifications')} className="relative grid h-9 w-9 place-items-center rounded-full border border-white/10 text-muted hover:border-brand/40 hover:text-ink" aria-label={unreadCount > 0 ? `Open notifications (${unreadCount} unread)` : 'Open notifications'}><Bell size={17}/>{unreadCount > 0 && <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-brand px-1 text-[10px] font-black text-canvas">{unreadCount > 9 ? '9+' : unreadCount}</span>}</button><AccountMenu user={user}/></> : <button onClick={() => navigate('/login')} className="rounded-xl bg-brand px-3 py-2 text-sm font-black text-canvas">Sign in</button>}</div></div></header>{isSidebarOpen && <div className="fixed inset-0 z-40 bg-black/65 lg:hidden" onClick={() => setSidebarOpen(false)} />}{isSidebarOpen && <aside className="fixed left-0 top-16 z-50 h-[calc(100vh-4rem)] w-72 border-r border-white/10 bg-surface p-4 lg:hidden">{primaryNavigation.map(({ label, to, icon: Icon }) => <NavLink onClick={() => setSidebarOpen(false)} key={to} to={to} className="mb-1 flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-muted hover:bg-white/10 hover:text-ink"><Icon size={18}/>{label}</NavLink>)}</aside>}<motion.main initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: .35 }}><Outlet /></motion.main><AppFooter/></div>
}
