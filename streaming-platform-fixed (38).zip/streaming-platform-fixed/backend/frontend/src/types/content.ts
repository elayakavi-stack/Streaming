export type ContentKind = 'movie' | 'series' | 'episode' | 'live'

/** A selectable audio language — only present when the source had more than
 * one audio stream at upload time (see backend transcode pipeline). */
export interface AudioTrack {
  language: string
  name: string
}

/** A raw dub/audio-track file attached to a title but not yet baked into
 * its streaming files — either because the title is still mid-upload, or
 * because it was added afterward and a reprocess just got queued for it. */
export interface PendingAudioSource {
  id: string
  language: string
  label: string
  isDefault: boolean
}

/** A WebVTT caption/subtitle track uploaded for a title. */
export interface SubtitleTrack {
  id: string
  language: string
  label: string
  url: string
  isDefault: boolean
}

export interface ContentCard {
  id: string
  kind: ContentKind
  /** Raw category string from the backend (e.g. "Sports", "Original") —
   * `kind` collapses everything that isn't "TV Show" into 'movie', so this
   * is needed anywhere the exact category matters (e.g. editing a title). */
  rawCategory?: string
  title: string
  posterUrl: string
  backdropUrl?: string
  releaseYear: number
  maturityRating: string
  durationLabel?: string
  genres: string[]
  subGenre?: string
  /** ISO 639 code for the language of the video's own embedded audio track
   * (e.g. "te"), set explicitly at upload time since most source files
   * carry no language tag in their container metadata — see
   * app/worker/transcode.py. */
  originalLanguage?: string
  /** Mood tags for this title (e.g. ["Feel-good", "Uplifting"]) — see
   * Video.moods in app/models.py. Drives the "More like this mood" player
   * rail and the mood-based home rail. */
  moods?: string[]
  progress?: number
  progressSeconds?: number
  synopsis?: string
  score?: number
  isNew?: boolean
  isInWatchlist?: boolean
  averageRating?: number
  ratingCount?: number
  userRating?: number
  userReview?: string
  playbackUrl?: string | null
  status?: 'pending_upload' | 'processing' | 'ready' | 'failed'
  director?: string
  castMembers?: string
  audioTracks?: AudioTrack[]
  subtitles?: SubtitleTrack[]
  pendingAudioSources?: PendingAudioSource[]
}

/** Future endpoint: GET /v1/content?cursor={cursor}&kind={kind} */
export interface PaginatedResponse<T> {
  data: T[]
  nextCursor: string | null
  total: number
}
