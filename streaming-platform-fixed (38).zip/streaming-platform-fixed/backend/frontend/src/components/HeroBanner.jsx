import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ChevronLeft, ChevronRight, Play, Info } from 'lucide-react'
import { posterGradient } from '../lib/poster'

export default function HeroBanner({ video, videos = [] }) {
  const heroItems = (videos.length ? videos : video ? [video] : []).slice(0, 5)
  const [index, setIndex] = useState(0)

  useEffect(() => {
    if (heroItems.length < 2) return undefined
    const timer = window.setInterval(() => setIndex((current) => (current + 1) % heroItems.length), 6500)
    return () => window.clearInterval(timer)
  }, [heroItems.length])

  const active = heroItems[index] || video
  if (!active) {
    return (
      <div className="relative flex h-[58vh] min-h-[360px] items-center justify-center bg-[radial-gradient(ellipse_at_top,#233c54_0%,#0f171e_65%)] px-6 text-center">
        <div>
          <p className="marquee-heading text-3xl text-ivory">Your next favourite is waiting</p>
          <p className="mt-3 text-ash">Add a title to start building your streaming library.</p>
        </div>
      </div>
    )
  }

  const backdrop = active.backdrop_url || active.poster_url

  return (
    <div
      className="group relative flex h-[68vh] min-h-[430px] max-h-[720px] items-end overflow-hidden"
      style={!backdrop ? { background: posterGradient(active.title) } : undefined}
    >
      {backdrop && (
        <img
          src={backdrop}
          alt={active.title}
          className="absolute inset-0 h-full w-full object-cover object-center"
        />
      )}

      <div className="absolute inset-0 animate-sweep bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-void via-void/25 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-void via-void/50 to-transparent" />

      <div className="relative z-10 max-w-2xl px-5 pb-16 sm:px-8 md:px-12 md:pb-20">
        <p className="text-xs font-bold uppercase tracking-[0.18em] text-marquee">StreamVerse original</p>
        <h2 className="marquee-heading mt-3 text-4xl leading-[0.95] text-ivory drop-shadow-2xl sm:text-5xl md:text-7xl">
          {active.title}
        </h2>
        <div className="mt-4 flex flex-wrap gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-ash">
          <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1">{active.genre}</span>
          <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1">{active.release_year}</span>
          <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1">{active.rating}</span>
        </div>
        {active.description && (
          <p className="mt-5 max-w-xl line-clamp-2 text-sm leading-6 text-slate-200 sm:text-base">{active.description}</p>
        )}

        <div className="mt-7 flex flex-wrap gap-3">
          <Link
            to={`/watch/${active.id}`}
            className="inline-flex items-center gap-2 rounded-md bg-ivory px-6 py-3 font-bold text-void transition-colors hover:bg-white/80"
          >
            <Play size={18} className="fill-void" />
            Play
          </Link>
          <Link to={`/watch/${active.id}`} className="inline-flex items-center gap-2 rounded-md bg-white/20 px-5 py-3 font-bold text-ivory backdrop-blur transition-colors hover:bg-white/30"><Info size={18} /> Details</Link>
        </div>
      </div>

      {heroItems.length > 1 && <>
        <button onClick={() => setIndex((index - 1 + heroItems.length) % heroItems.length)} aria-label="Previous featured title" className="hero-arrow left-4"><ChevronLeft /></button>
        <button onClick={() => setIndex((index + 1) % heroItems.length)} aria-label="Next featured title" className="hero-arrow right-4"><ChevronRight /></button>
        <div className="absolute bottom-6 right-6 z-20 flex items-center gap-2">
          {heroItems.map((item, itemIndex) => <button key={item.id} onClick={() => setIndex(itemIndex)} aria-label={`Show ${item.title}`} className={`hero-dot ${itemIndex === index ? 'hero-dot-active' : ''}`} />)}
        </div>
      </>}
    </div>
  )
}
