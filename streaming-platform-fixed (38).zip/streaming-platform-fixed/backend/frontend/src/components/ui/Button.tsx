import type { ComponentProps, ReactNode } from 'react'
import { motion } from 'framer-motion'

type Props = ComponentProps<typeof motion.button> & { variant?: 'primary' | 'secondary' | 'ghost'; children: ReactNode }

export function Button({ variant = 'primary', className = '', children, ...props }: Props) {
  const styles = {
    primary: 'bg-brand text-canvas shadow-glow hover:bg-[#79bbff]',
    secondary: 'border border-white/15 bg-white/10 text-ink hover:bg-white/15',
    ghost: 'text-muted hover:bg-white/8 hover:text-ink',
  }
  return <motion.button whileTap={{ scale: .97 }} whileHover={{ y: -1 }} className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-bold transition disabled:pointer-events-none disabled:opacity-50 ${styles[variant]} ${className}`} {...props}>{children}</motion.button>
}
