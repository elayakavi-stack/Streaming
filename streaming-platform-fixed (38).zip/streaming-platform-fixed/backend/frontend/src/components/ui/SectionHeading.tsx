import type { ReactNode } from 'react'

export function SectionHeading({ eyebrow, title, action, titleClassName }: { eyebrow?: string; title: string; action?: ReactNode; titleClassName?: string }) {
  return <div className="mb-4 flex items-end justify-between gap-4"><div>{eyebrow && <p className="mb-1 text-xs font-bold uppercase tracking-[.18em] text-brand">{eyebrow}</p>}<h2 className={titleClassName ?? 'font-display text-xl font-bold tracking-tight text-ink sm:text-2xl'}>{title}</h2></div>{action}</div>
}
