import type { ReactNode } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { authApi } from '@/services/auth-api'
import { useCurrentUser } from '@/features/account/queries'

export function RequireAdmin({ children }: { children: ReactNode }) {
  const location = useLocation()
  const signedIn = authApi.isSignedIn()
  // Hooks must run unconditionally on every render, in the same order — so
  // useCurrentUser is called regardless of sign-in status. `enabled` inside
  // that hook already guards against firing the request when signed out.
  const { data: user, isPending } = useCurrentUser()

  if (!signedIn) return <Navigate to={`/login?next=${encodeURIComponent(location.pathname)}`} replace />
  if (isPending) return null
  if (!user?.isAdmin) return <Navigate to="/" replace />

  return <>{children}</>
}
