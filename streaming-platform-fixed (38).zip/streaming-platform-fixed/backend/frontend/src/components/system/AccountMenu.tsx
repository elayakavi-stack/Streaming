import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronDown, LogOut, Radio, Settings, ShieldCheck, User } from 'lucide-react'
import { authApi } from '@/services/auth-api'
import type { CurrentUser } from '@/services/auth-api'

export function AccountMenu({ user }: { user: CurrentUser | undefined }) {
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const rootRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    const onOutside = (event: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(event.target as Node)) setOpen(false)
    }
    const onEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false)
    }
    document.addEventListener('mousedown', onOutside)
    document.addEventListener('keydown', onEscape)
    return () => {
      document.removeEventListener('mousedown', onOutside)
      document.removeEventListener('keydown', onEscape)
    }
  }, [open])

  const go = (path: string) => {
    setOpen(false)
    navigate(path)
  }

  const initial = user?.email ? user.email[0].toUpperCase() : '?'

  return <div className="relative" ref={rootRef}>
    <button
      type="button"
      onClick={(event) => { event.stopPropagation(); setOpen((v) => !v) }}
      aria-label="Account menu"
      aria-expanded={open}
      aria-haspopup="menu"
      className="flex items-center gap-1 rounded-full text-sm hover:ring-2 hover:ring-brand/50"
    >
      <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-brand to-violet text-sm font-black text-canvas">{initial}</span>
      <ChevronDown size={14} className="hidden text-muted sm:block" />
    </button>
    {open && <div role="menu" className="absolute right-0 top-11 z-[60] w-56 overflow-hidden rounded-xl border border-white/10 bg-surface shadow-panel">
      {user?.email && <p className="truncate border-b border-white/10 px-4 py-3 text-xs text-muted">{user.email}</p>}
      <button type="button" role="menuitem" onClick={() => go('/account')} className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-ink hover:bg-white/10"><User size={15} /> Profile</button>
      <button type="button" role="menuitem" onClick={() => go('/settings')} className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-ink hover:bg-white/10"><Settings size={15} /> Settings</button>
      {user?.isAdmin && <button type="button" role="menuitem" onClick={() => go('/admin')} className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-ink hover:bg-white/10"><ShieldCheck size={15} /> Admin</button>}
      {user && <button type="button" role="menuitem" onClick={() => go('/go-live')} className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-ink hover:bg-white/10"><Radio size={15} /> Go live</button>}
      <button type="button" role="menuitem" onClick={() => { setOpen(false); authApi.logout(); navigate('/login') }} className="flex w-full items-center gap-2 border-t border-white/10 px-4 py-2.5 text-left text-sm text-danger hover:bg-white/10"><LogOut size={15} /> Sign out</button>
    </div>}
  </div>
}
