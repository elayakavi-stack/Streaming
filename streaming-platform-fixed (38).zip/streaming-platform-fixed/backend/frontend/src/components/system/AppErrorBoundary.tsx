import { Component, type ErrorInfo, type ReactNode } from 'react'

type Props = { children: ReactNode }
type State = { error: Error | null }

export class AppErrorBoundary extends Component<Props, State> {
  state: State = { error: null }
  static getDerivedStateFromError(error: Error): State { return { error } }
  componentDidCatch(error: Error, info: ErrorInfo) { console.error('NovaPlay render error', error, info) }
  render() {
    if (!this.state.error) return this.props.children
    return <main className="grid min-h-screen place-items-center bg-canvas px-6 text-center text-ink"><section className="max-w-md rounded-3xl border border-danger/30 bg-surface p-8 shadow-panel"><p className="text-xs font-bold uppercase tracking-[.2em] text-danger">Application error</p><h1 className="mt-3 font-display text-2xl font-black">We couldn’t open NovaPlay.</h1><p className="mt-3 text-sm leading-6 text-muted">Refresh the page to try again. If the problem persists, use the message below to identify the failing module.</p><code className="mt-5 block overflow-auto rounded-xl bg-black/30 p-3 text-left text-xs text-danger">{this.state.error.message}</code><button onClick={() => window.location.reload()} className="mt-6 rounded-xl bg-brand px-4 py-2 text-sm font-bold text-canvas">Reload app</button></section></main>
  }
}
