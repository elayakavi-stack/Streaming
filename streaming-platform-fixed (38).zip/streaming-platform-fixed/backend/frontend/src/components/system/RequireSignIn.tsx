import type { ReactNode } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { authApi } from '@/services/auth-api'

export function RequireSignIn({ children }: { children: ReactNode }) {
  const location = useLocation()
  if (!authApi.isSignedIn()) return <Navigate to={`/login?next=${encodeURIComponent(location.pathname)}`} replace />
  return <>{children}</>
}
