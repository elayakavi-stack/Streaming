import { useEffect, useMemo, useRef, useState } from 'react'
import Hls from 'hls.js'
import {
  FiCheck,
  FiGlobe,
  FiMaximize,
  FiMinimize,
  FiMessageSquare,
  FiPause,
  FiPlay,
  FiRadio,
  FiSettings,
  FiSkipBack,
  FiSkipForward,
  FiSliders,
  FiVolume2,
  FiVolumeX,
} from 'react-icons/fi'
import type { SubtitleTrack } from '@/types/content'

type QualityOption = { index: number; label: string }
type AudioOption = { index: number; label: string }
type SettingsTab = 'quality' | 'audio' | 'subtitles'
const OFF_SUBTITLE = 'off'

export function OttPlayer({
  src,
  poster,
  initialPosition = 0,
  autoPlay = true,
  isLive = false,
  subtitles = [],
  onProgress,
}: {
  src: string
  poster?: string
  initialPosition?: number
  autoPlay?: boolean
  /** Live broadcasts have no seek bar/duration and use a low-latency HLS config. */
  isLive?: boolean
  /** WebVTT caption tracks for this title, if any were uploaded. */
  subtitles?: SubtitleTrack[]
  onProgress?: (currentTime: number, duration: number) => void
}) {
  const video = useRef<HTMLVideoElement>(null)
  const hlsRef = useRef<Hls | null>(null)

  const [playing, setPlaying] = useState(false)
  const [muted, setMuted] = useState(autoPlay)
  const [current, setCurrent] = useState(0)
  const [duration, setDuration] = useState(0)
  const [full, setFull] = useState(false)

  // ---- Controls visibility ----
  const [showControls, setShowControls] = useState(true)
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  // ---- Settings panel: Quality / Audio / Subtitles ----
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [settingsTab, setSettingsTab] = useState<SettingsTab>('quality')
  const [qualityOptions, setQualityOptions] = useState<QualityOption[]>([])
  const [selectedQuality, setSelectedQuality] = useState(-1)
  const [audioOptions, setAudioOptions] = useState<AudioOption[]>([])
  const [selectedAudio, setSelectedAudio] = useState(-1)

  const defaultSubtitleId = useMemo(
  () =>
    subtitles.find((s) => s.isDefault)?.id ??
    subtitles[0]?.id ??
    OFF_SUBTITLE,
  [subtitles],
)

  const [subtitleChoice, setSubtitleChoice] = useState(defaultSubtitleId)

  const [error, setError] = useState<string | null>(null)

  const revealControls = () => {
    setShowControls(true)

    if (hideTimer.current) {
      clearTimeout(hideTimer.current)
    }

    if (playing && !settingsOpen) {
      hideTimer.current = setTimeout(
        () => setShowControls(false),
        3000,
      )
    }
  }

  useEffect(() => {
    revealControls()

    return () => {
      if (hideTimer.current) {
        clearTimeout(hideTimer.current)
      }
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, settingsOpen])

  const time = (value: number) =>
    `${Math.floor(value / 60)}:${String(Math.floor(value % 60)).padStart(2, '0')}`

  const toggle = async () => {
    if (!video.current) return

    try {
      if (video.current.paused) {
        await video.current.play()
        setPlaying(true)
      } else {
        video.current.pause()
        setPlaying(false)
      }
    } catch (reason) {
      setError(
        reason instanceof Error
          ? reason.message
          : 'Playback failed.',
      )
    }
  }

  const skip = (seconds: number) => {
    if (!video.current) return

    video.current.currentTime = Math.max(
      0,
      Math.min(
        duration,
        video.current.currentTime + seconds,
      ),
    )
  }

  const toggleFull = async () => {
    const node = video.current?.parentElement
    if (!node) return

    if (!document.fullscreenElement) {
      await node.requestFullscreen()
      setFull(true)
    } else {
      await document.exitFullscreen()
      setFull(false)
    }
  }

  // Attach the HLS source whenever it changes.
  useEffect(() => {
    const el = video.current
    if (!el || !src) return

    setError(null)
    setQualityOptions([])
    setSelectedQuality(-1)
    setAudioOptions([])
    setSelectedAudio(-1)

    function handleLoadedMetadata() {
      if (
        el &&
        initialPosition > 5 &&
        initialPosition < el.duration - 5
      ) {
        el.currentTime = initialPosition
      }
    }

    let hls: Hls | undefined

    el.addEventListener(
      'loadedmetadata',
      handleLoadedMetadata,
    )

    const attemptAutoplay = () => {
      if (!autoPlay) return

      el.play().catch(() => {
        el.muted = true
        setMuted(true)

        el.play().catch(() => {
          // Browser still blocked autoplay.
        })
      })
    }

    if (Hls.isSupported()) {
      hls = new Hls(
        isLive
          ? {
              liveSyncDurationCount: 3,
              liveMaxLatencyDurationCount: 6,
            }
          : undefined,
      )

      hlsRef.current = hls

      // ---------------------------------------------
      // QUALITY DETECTION
      // ---------------------------------------------

      const updateQualityOptions = () => {
        const mapped: QualityOption[] = hls!.levels.map(
          (level, index) => ({
            index,
            label: level.height
              ? `${level.height}p`
              : `Level ${index + 1}`,
          }),
        )

        setQualityOptions([
          {
            index: -1,
            label: 'Auto',
          },
          ...mapped,
        ])
      }

      hls.on(
        Hls.Events.LEVELS_UPDATED,
        updateQualityOptions,
      )

      // ---------------------------------------------
      // AUDIO TRACKS
      // ---------------------------------------------

      hls.on(
        Hls.Events.AUDIO_TRACKS_UPDATED,
        () => {
          const tracks = hls!.audioTracks.map(
            (track, index) => ({
              index,
              label:
                track.name ||
                track.lang ||
                `Track ${index + 1}`,
            }),
          )

          setAudioOptions(tracks)
          setSelectedAudio(hls!.audioTrack)
        },
      )

      hls.on(
        Hls.Events.AUDIO_TRACK_SWITCHED,
        (_event, data) =>
          setSelectedAudio(data.id),
      )

      // ---------------------------------------------
      // MANIFEST PARSED
      // ---------------------------------------------

      hls.on(
        Hls.Events.MANIFEST_PARSED,
        () => {
          updateQualityOptions()
          attemptAutoplay()
        },
      )

      // ---------------------------------------------
      // HLS ERRORS
      // ---------------------------------------------

      let networkRetries = 0

      hls.on(
        Hls.Events.ERROR,
        (_event, data) => {
          if (!data.fatal) return

          if (
            data.type ===
            Hls.ErrorTypes.NETWORK_ERROR
          ) {
            if (networkRetries < 4) {
              networkRetries += 1

              setTimeout(
                () => hls?.startLoad(),
                1500,
              )
            } else {
              setError(
                "Couldn't load the stream. It may not be live yet, or the streaming server (MediaMTX) isn't reachable from your browser — check the server is running and that HLS_BASE_URL/CORS are set correctly.",
              )
            }
          } else if (
            data.type ===
            Hls.ErrorTypes.MEDIA_ERROR
          ) {
            hls?.recoverMediaError()
          } else {
            setError(
              data.details ||
                'Playback failed.',
            )
          }
        },
      )

      hls.loadSource(src)
      hls.attachMedia(el)
    } else {
      // Native playback fallback.
      el.src = src

      el.addEventListener(
        'loadedmetadata',
        attemptAutoplay,
        { once: true },
      )

      const handleNativeError = () => {
        const code = el.error?.code

        setError(
          (code === 2
            ? "Couldn't reach the stream. Check that the streaming server is running and reachable."
            : code === 4
              ? 'This stream URL is not playable in this browser.'
              : 'Playback failed.') +
            ` (${src})`,
        )
      }

      el.addEventListener(
        'error',
        handleNativeError,
      )

      return () => {
        el.removeEventListener(
          'loadedmetadata',
          handleLoadedMetadata,
        )

        el.removeEventListener(
          'loadedmetadata',
          attemptAutoplay,
        )

        el.removeEventListener(
          'error',
          handleNativeError,
        )
      }
    }

    return () => {
      el.removeEventListener(
        'loadedmetadata',
        handleLoadedMetadata,
      )

      hls?.destroy()

      hlsRef.current = null

      setQualityOptions([])
      setSelectedQuality(-1)

      setAudioOptions([])
      setSelectedAudio(-1)
    }
  }, [
    src,
    initialPosition,
    isLive,
    autoPlay,
  ])

  // Reset subtitles whenever the title changes.
  useEffect(() => {
    setSubtitleChoice(defaultSubtitleId)
  }, [defaultSubtitleId, src])

  // Keep the <video>'s native text tracks in sync with subtitleChoice.
  // Native <track> elements are the simplest way to render WebVTT captions
  // — the browser handles cue rendering, styling, and positioning — so
  // switching languages is just flipping each TextTrack's `mode`.
  //
  // Matched by kind + language + label rather than array index: hls.js
  // (with its default config) can inject its own native TextTrack entries
  // into el.textTracks — e.g. for ID3 timed-metadata cues — completely
  // independent of our own <track> children. Once that happens,
  // el.textTracks[i] no longer lines up 1:1 with subtitles[i], so an
  // index-based match can end up flipping `showing` on the wrong
  // TextTrack (or hls.js's own metadata track) while our actual subtitle
  // track silently stays `disabled` — captions never appear, with nothing
  // about the code looking obviously wrong. Filtering to kind === 'subtitles'
  // and matching on the language/label we ourselves set on the <track>
  // element sidesteps that entirely, regardless of what else ends up in
  // the list or in what order.
  useEffect(() => {
    const el = video.current
    if (!el) return

    for (
      let i = 0;
      i < el.textTracks.length;
      i += 1
    ) {
      const track = el.textTracks[i]

      if (track.kind !== 'subtitles' && track.kind !== 'captions') continue

      const match = subtitles.find(
        (s) => s.language === track.language && s.label === track.label,
      )

      track.mode =
        match && match.id === subtitleChoice
          ? 'showing'
          : 'disabled'
    }
  }, [subtitleChoice, subtitles])

  // Periodically report progress.
  useEffect(() => {
    const el = video.current
    if (!el) return

    let interval:
      | ReturnType<typeof setInterval>
      | undefined

    const report = () =>
      onProgress?.(
        el.currentTime,
        el.duration || 0,
      )

    const handlePlay = () => {
      setPlaying(true)

      interval = setInterval(
        report,
        5000,
      )
    }

    const handlePauseOrEnd = () => {
      setPlaying(false)

      if (interval) {
        clearInterval(interval)
      }

      report()
    }

    el.addEventListener(
      'play',
      handlePlay,
    )

    el.addEventListener(
      'pause',
      handlePauseOrEnd,
    )

    el.addEventListener(
      'ended',
      handlePauseOrEnd,
    )

    return () => {
      if (interval) {
        clearInterval(interval)
      }

      el.removeEventListener(
        'play',
        handlePlay,
      )

      el.removeEventListener(
        'pause',
        handlePauseOrEnd,
      )

      el.removeEventListener(
        'ended',
        handlePauseOrEnd,
      )
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src])

  // Keyboard shortcuts.
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (
        event.target instanceof
        HTMLInputElement
      ) {
        return
      }

      if (event.code === 'Space') {
        event.preventDefault()
        toggle()
      }

      if (
        !isLive &&
        event.key === 'ArrowRight'
      ) {
        skip(10)
      }

      if (
        !isLive &&
        event.key === 'ArrowLeft'
      ) {
        skip(-10)
      }

      if (
        event.key.toLowerCase() === 'f'
      ) {
        toggleFull()
      }
    }

    window.addEventListener(
      'keydown',
      key,
    )

    return () =>
      window.removeEventListener(
        'keydown',
        key,
      )
  })

  // ---------------------------------------------
  // QUALITY CHANGE
  // ---------------------------------------------

  const changeQuality = (
    index: number,
  ) => {
    setSelectedQuality(index)

    if (hlsRef.current) {
      hlsRef.current.currentLevel =
        index
    }
  }

  // ---------------------------------------------
  // AUDIO CHANGE
  // ---------------------------------------------

  const changeAudio = (
    index: number,
  ) => {
    setSelectedAudio(index)

    if (hlsRef.current) {
      hlsRef.current.audioTrack =
        index
    }
  }

  const hasQualityOptions =
    qualityOptions.length > 1

  const hasAudioOptions =
    audioOptions.length > 1

  const hasSubtitleOptions =
    subtitles.length > 0

  const hasAnySettings = true

  const openSettings = () => {
    if (!settingsOpen) {
      if (hasQualityOptions) {
        setSettingsTab('quality')
      } else if (hasAudioOptions) {
        setSettingsTab('audio')
      } else if (hasSubtitleOptions) {
        setSettingsTab('subtitles')
      } else {
        setSettingsTab('quality')
      }
    }

    setSettingsOpen(!settingsOpen)
  }

  return (
    <div
      className="group/player relative aspect-video overflow-hidden rounded-2xl bg-black shadow-panel"
      onMouseMove={revealControls}
      onTouchStart={revealControls}
      onClick={revealControls}
    >
      {/*
        crossOrigin="anonymous" IS required here, despite how it might look.
        hls.js fetches video segments itself (independent of this
        attribute), so it doesn't affect playback either way. But <track>
        (subtitle) files are different: unlike <video>/<img>, the browser
        has to actually read the WebVTT text to parse cues, not just play
        an opaque blob — so per spec, cross-origin track loads are blocked
        outright unless the request goes through CORS. Without this
        attribute, Chrome logs "Unsafe attempt to load URL ... Domains,
        protocols and ports must match" and never even sends the request
        (nothing in the Network tab), while TextTrack.mode still happily
        reports "showing" with an empty cue list — which looks exactly
        like a loading bug but is actually just a missing crossorigin
        request. The bucket/CDN must send Access-Control-Allow-Origin on
        GET for this to work (CORS is usually only set up for the upload
        PUT flow, so it's easy to forget the read side).
      */}
      <video
        ref={video}
        crossOrigin="anonymous"
        className="h-full w-full object-contain"
        poster={poster}
        autoPlay={autoPlay}
        muted={muted}
        playsInline
        onTimeUpdate={(event) =>
          setCurrent(
            event.currentTarget.currentTime,
          )
        }
        onLoadedMetadata={(event) =>
          setDuration(
            event.currentTarget.duration,
          )
        }
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
      >
        {subtitles.map((track) => (
          <track
            key={track.id}
            kind="subtitles"
            srcLang={track.language}
            label={track.label}
            src={track.url}
            default={
              track.id ===
              defaultSubtitleId
            }
          />
        ))}
      </video>

      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/35 opacity-0 transition group-hover/player:opacity-100" />

      {isLive && (
        <span className="absolute left-3 top-3 z-10 flex items-center gap-1.5 rounded-full bg-danger px-2.5 py-1 text-xs font-black text-white">
          <FiRadio /> LIVE
        </span>
      )}

      {error ? (
        <div className="absolute inset-0 z-20 grid place-items-center bg-black/85 px-6 text-center">
          <div>
            <p className="font-display text-lg font-black text-ink">
              Playback error
            </p>

            <p className="mx-auto mt-2 max-w-sm text-sm text-muted">
              {error}
            </p>

            <button
              onClick={() => {
                setError(null)

                if (hlsRef.current) {
                  hlsRef.current.startLoad()
                }

                video.current?.load()

                toggle()
              }}
              className="mt-4 rounded-xl bg-brand px-4 py-2 text-sm font-bold text-canvas"
            >
              Try again
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={toggle}
          className={`absolute inset-0 m-auto grid h-16 w-16 place-items-center rounded-full bg-ink/90 text-canvas shadow-panel transition ${
            showControls
              ? 'opacity-100'
              : 'opacity-0'
          }`}
          aria-label={
            playing
              ? 'Pause'
              : 'Play'
          }
        >
          {playing ? (
            <FiPause size={28} />
          ) : (
            <FiPlay
              className="ml-1"
              size={30}
            />
          )}
        </button>
      )}

      <div
        className={`absolute inset-x-0 bottom-0 p-4 transition ${
          showControls
            ? 'opacity-100'
            : 'opacity-0'
        }`}
      >
        {!isLive && (
          <input
            aria-label="Playback position"
            type="range"
            min="0"
            max={duration || 1}
            value={current}
            onChange={(event) => {
              if (video.current) {
                video.current.currentTime =
                  Number(
                    event.target.value,
                  )
              }
            }}
            className="mb-3 h-1 w-full accent-brand"
          />
        )}

        <div className="flex items-center gap-3">
          <button
            onClick={toggle}
            aria-label={
              playing
                ? 'Pause'
                : 'Play'
            }
          >
            {playing ? (
              <FiPause size={21} />
            ) : (
              <FiPlay size={21} />
            )}
          </button>

          {!isLive && (
            <button
              onClick={() => skip(-10)}
              aria-label="Back 10 seconds"
            >
              <FiSkipBack size={19} />
            </button>
          )}

          {!isLive && (
            <button
              onClick={() => skip(10)}
              aria-label="Forward 10 seconds"
            >
              <FiSkipForward size={19} />
            </button>
          )}

          <button
            onClick={() => {
              if (video.current) {
                video.current.muted =
                  !muted
              }

              setMuted(!muted)
            }}
            aria-label="Toggle sound"
          >
            {muted ? (
              <FiVolumeX />
            ) : (
              <FiVolume2 />
            )}
          </button>

          <span className="text-xs font-semibold">
            {isLive
              ? 'LIVE'
              : `${time(current)} / ${time(
                  duration || 0,
                )}`}
          </span>

          <div className="ml-auto flex items-center gap-1">
            {hasAnySettings && (
              <div className="relative">
                <button
                  onClick={openSettings}
                  className="rounded-lg px-2 py-1 text-xs font-bold text-muted hover:bg-white/10 hover:text-ink"
                  aria-label="Playback settings"
                >
                  <FiSettings size={18} />
                </button>

                {settingsOpen && (
                  <div className="absolute bottom-9 right-0 w-56 overflow-hidden rounded-xl border border-white/10 bg-surface shadow-panel">
                    <div className="flex border-b border-white/10">
                      <SettingsTabButton
                        icon={
                          <FiSliders size={13} />
                        }
                        label="Quality"
                        active={
                          settingsTab ===
                          'quality'
                        }
                        onClick={() =>
                          setSettingsTab(
                            'quality',
                          )
                        }
                      />

                      <SettingsTabButton
                        icon={
                          <FiGlobe size={13} />
                        }
                        label="Audio"
                        active={
                          settingsTab ===
                          'audio'
                        }
                        onClick={() =>
                          setSettingsTab(
                            'audio',
                          )
                        }
                      />

                      <SettingsTabButton
                        icon={
                          <FiMessageSquare
                            size={13}
                          />
                        }
                        label="Subtitles"
                        active={
                          settingsTab ===
                          'subtitles'
                        }
                        onClick={() =>
                          setSettingsTab(
                            'subtitles',
                          )
                        }
                      />
                    </div>

                    <div className="max-h-56 overflow-y-auto p-1">
                      {settingsTab ===
                        'quality' &&
                        (hasQualityOptions ? (
                          qualityOptions.map(
                            (option) => (
                              <SettingsOption
                                key={
                                  option.index
                                }
                                label={
                                  option.label
                                }
                                selected={
                                  selectedQuality ===
                                  option.index
                                }
                                onClick={() =>
                                  changeQuality(
                                    option.index,
                                  )
                                }
                              />
                            ),
                          )
                        ) : (
                          <SettingsEmpty text="Only one quality is available for this title." />
                        ))}

                      {settingsTab ===
                        'audio' &&
                        (hasAudioOptions ? (
                          audioOptions.map(
                            (option) => (
                              <SettingsOption
                                key={
                                  option.index
                                }
                                label={
                                  option.label
                                }
                                selected={
                                  selectedAudio ===
                                  option.index
                                }
                                onClick={() =>
                                  changeAudio(
                                    option.index,
                                  )
                                }
                              />
                            ),
                          )
                        ) : (
                          <SettingsEmpty text="No alternate audio tracks for this title." />
                        ))}

                      {settingsTab ===
                        'subtitles' &&
                        (hasSubtitleOptions ? (
                          <>
                            <SettingsOption
                              label="Off"
                              selected={
                                subtitleChoice ===
                                OFF_SUBTITLE
                              }
                              onClick={() =>
                                setSubtitleChoice(
                                  OFF_SUBTITLE,
                                )
                              }
                            />

                            {subtitles.map(
                              (track) => (
                                <SettingsOption
                                  key={
                                    track.id
                                  }
                                  label={
                                    track.label
                                  }
                                  selected={
                                    subtitleChoice ===
                                    track.id
                                  }
                                  onClick={() =>
                                    setSubtitleChoice(
                                      track.id,
                                    )
                                  }
                                />
                              ),
                            )}
                          </>
                        ) : (
                          <SettingsEmpty text="No subtitles are available for this title." />
                        ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            <button
              onClick={toggleFull}
              aria-label="Toggle fullscreen"
              className="p-1.5"
            >
              {full ? (
                <FiMinimize size={18} />
              ) : (
                <FiMaximize size={18} />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

function SettingsTabButton({
  icon,
  label,
  active,
  onClick,
}: {
  icon: React.ReactNode
  label: string
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-1 items-center justify-center gap-1.5 px-2 py-2 text-[11px] font-bold uppercase tracking-wide transition ${
        active
          ? 'bg-white/10 text-ink'
          : 'text-muted hover:bg-white/5 hover:text-ink'
      }`}
    >
      {icon} {label}
    </button>
  )
}

function SettingsOption({
  label,
  selected,
  onClick,
}: {
  label: string
  selected: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-xs text-muted hover:bg-white/10 hover:text-ink"
    >
      {label}

      {selected && (
        <FiCheck className="text-brand" />
      )}
    </button>
  )
}

function SettingsEmpty({
  text,
}: {
  text: string
}) {
  return (
    <p className="px-3 py-3 text-xs text-muted">
      {text}
    </p>
  )
}
