import { useLayoutEffect, useRef } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import VideoCard from './VideoCard'

export default function VideoRow({ title, videos, accent = 'text-ivory', onDeleted }) {
  const shelfRef = useRef(null)

  // Keeps this row flush with its heading instead of drifting off its 0
  // scroll position when the browser's scroll anchoring reacts to lazily
  // loaded poster images settling in — otherwise the row can render with
  // its first card cropped against the screen edge.
  useLayoutEffect(() => {
    if (shelfRef.current) shelfRef.current.scrollLeft = 0
  }, [videos])

  if (!videos.length) return null

  function scroll(direction) {
    const node = shelfRef.current
    if (!node) return
    node.scrollBy({ left: direction * 320, behavior: 'smooth' })
  }

  return (
    <section className="mb-11 px-4 md:px-6">
      <div className="mb-4 flex items-center justify-between gap-4">
        <h2 className={`marquee-heading text-xl ${accent}`}>{title}</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => scroll(-1)}
            className="rounded-full border border-white/10 bg-white/5 p-2 text-ash transition hover:border-marquee hover:text-ivory"
            aria-label={`Scroll ${title} left`}
          >
            <ChevronLeft size={18} />
          </button>
          <button
            onClick={() => scroll(1)}
            className="rounded-full border border-white/10 bg-white/5 p-2 text-ash transition hover:border-marquee hover:text-ivory"
            aria-label={`Scroll ${title} right`}
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      <div ref={shelfRef} className="shelf-scroll flex snap-x snap-mandatory gap-3 overflow-x-auto pb-5 pt-1 [overflow-anchor:none]">
        {videos.map((v) => (
          <div key={v.id} className="snap-start">
            <VideoCard video={v} onDeleted={onDeleted} />
          </div>
        ))}
      </div>
    </section>
  )
}
