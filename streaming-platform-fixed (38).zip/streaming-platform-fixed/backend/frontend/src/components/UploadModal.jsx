import { useState } from 'react'
import { X, UploadCloud } from 'lucide-react'
import { createVideo, uploadToS3, completeUpload } from '../api/client'

export default function UploadModal({ onClose, onUploaded }) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('Movie')
  const [genre, setGenre] = useState('Action')
  const [rating, setRating] = useState('U/A 16+')
  const [releaseYear, setReleaseYear] = useState(new Date().getFullYear())
  const [castMembers, setCastMembers] = useState('')
  const [director, setDirector] = useState('')
  const [file, setFile] = useState(null)
  const [progress, setProgress] = useState(0)
  const [status, setStatus] = useState('idle')

  async function handleSubmit(e) {
    e.preventDefault()
    if (!file || !title) return

    try {
      setStatus('uploading')
      const contentType = file.type || 'application/octet-stream'

      const { video_id, upload_url } = await createVideo({
        title,
        description,
        category,
        genre,
        rating,
        imdbScore: '8.5',
        releaseYear,
        castMembers,
        director,
        filename: file.name,
        contentType,
      })

      await uploadToS3(upload_url, file, setProgress, contentType)

      setStatus('processing')
      await completeUpload(video_id)

      onUploaded?.()
      onClose()
    } catch (err) {
      console.error(err)
      setStatus('error')
    }
  }

  const busy = status === 'uploading' || status === 'processing'

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-void/80 px-4 backdrop-blur-sm">
      <div className="w-full max-w-xl rounded-lg border border-panel-raised bg-panel shadow-2xl">
        <div className="flex items-center justify-between border-b border-panel-raised px-6 py-4">
          <h2 className="marquee-heading text-xl text-marquee">Add a title</h2>
          <button
            onClick={onClose}
            aria-label="Close"
            className="rounded p-1 text-ash transition-colors hover:bg-panel-raised hover:text-ivory"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="grid gap-4 px-6 py-5 md:grid-cols-2">
          <label className="flex flex-col gap-1.5 text-sm text-ash md:col-span-2">
            Title
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="rounded-md border border-panel-raised bg-void px-3 py-2 text-ivory outline-none focus:border-marquee"
              placeholder="What's this called?"
            />
          </label>

          <label className="flex flex-col gap-1.5 text-sm text-ash md:col-span-2">
            Description <span className="text-ash/60">(optional)</span>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              className="resize-none rounded-md border border-panel-raised bg-void px-3 py-2 text-ivory outline-none focus:border-marquee"
              placeholder="A line or two about it"
            />
          </label>

          <label className="flex flex-col gap-1.5 text-sm text-ash">
            Category
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="rounded-md border border-panel-raised bg-void px-3 py-2 text-ivory outline-none focus:border-marquee">
              <option>Movie</option>
              <option>TV Show</option>
              <option>Original</option>
            </select>
          </label>

          <label className="flex flex-col gap-1.5 text-sm text-ash">
            Genre
            <select value={genre} onChange={(e) => setGenre(e.target.value)} className="rounded-md border border-panel-raised bg-void px-3 py-2 text-ivory outline-none focus:border-marquee">
              <option>Action</option>
              <option>Sci-Fi</option>
              <option>Drama</option>
              <option>Comedy</option>
              <option>Thriller</option>
            </select>
          </label>

          <label className="flex flex-col gap-1.5 text-sm text-ash">
            Rating
            <input value={rating} onChange={(e) => setRating(e.target.value)} className="rounded-md border border-panel-raised bg-void px-3 py-2 text-ivory outline-none focus:border-marquee" />
          </label>

          <label className="flex flex-col gap-1.5 text-sm text-ash">
            Release year
            <input type="number" value={releaseYear} onChange={(e) => setReleaseYear(Number(e.target.value))} className="rounded-md border border-panel-raised bg-void px-3 py-2 text-ivory outline-none focus:border-marquee" />
          </label>

          <label className="flex flex-col gap-1.5 text-sm text-ash">
            Cast
            <input value={castMembers} onChange={(e) => setCastMembers(e.target.value)} className="rounded-md border border-panel-raised bg-void px-3 py-2 text-ivory outline-none focus:border-marquee" placeholder="Actor A, Actor B" />
          </label>

          <label className="flex flex-col gap-1.5 text-sm text-ash">
            Director
            <input value={director} onChange={(e) => setDirector(e.target.value)} className="rounded-md border border-panel-raised bg-void px-3 py-2 text-ivory outline-none focus:border-marquee" placeholder="Director name" />
          </label>

          <label className="flex cursor-pointer flex-col items-center gap-2 rounded-md border border-dashed border-panel-raised bg-void px-4 py-6 text-center transition-colors hover:border-marquee md:col-span-2">
            <UploadCloud size={22} className="text-ash" />
            <span className="text-sm text-ash">{file ? file.name : 'Choose a video file'}</span>
            <input type="file" accept="video/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="hidden" required />
          </label>

          {status === 'uploading' && (
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-void md:col-span-2">
              <div className="h-1.5 rounded-full bg-marquee transition-all" style={{ width: `${progress}%` }} />
            </div>
          )}
          {status === 'processing' && (
            <p className="font-mono text-xs uppercase tracking-wide text-ash md:col-span-2">Uploaded — queued for processing</p>
          )}
          {status === 'error' && (
            <p className="text-sm text-reel md:col-span-2">Something went wrong with the upload. Check your connection and try again.</p>
          )}

          <button type="submit" disabled={busy} className="mt-1 rounded-md bg-marquee px-4 py-2.5 font-semibold text-void transition-colors hover:bg-marquee-dim disabled:opacity-50 md:col-span-2">
            {status === 'uploading' ? `Uploading ${progress}%` : status === 'processing' ? 'Finishing up…' : 'Upload'}
          </button>
        </form>
      </div>
    </div>
  )
}
