import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Play, Loader2, TriangleAlert, Trash2, BookmarkPlus, BookmarkCheck } from 'lucide-react'
import { posterGradient } from '../lib/poster'
import { deleteVideo, toggleWatchlist } from '../api/client'

const STATUS_COPY = {
  pending_upload: 'Waiting to upload',
  processing: 'Processing',
  ready: null,
  failed: "Couldn't process",
}

export default function VideoCard({ video, onDeleted }) {
  const [confirming, setConfirming] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [saved, setSaved] = useState(Boolean(video.is_in_watchlist))
  const statusLabel = STATUS_COPY[video.status]
  const poster = video.poster_url || video.backdrop_url
  const hasProgress = Number(video.progress_seconds || 0) > 0 && Number(video.duration_seconds || 0) > 0
  const progressPct = hasProgress
    ? Math.min(100, (Number(video.progress_seconds) / Number(video.duration_seconds)) * 100)
    : 0

  async function handleDelete(e) {
    e.preventDefault()
    e.stopPropagation()
    if (!confirming) {
      setConfirming(true)
      return
    }
    setDeleting(true)
    try {
      await deleteVideo(video.id)
      onDeleted?.(video.id)
    } catch (err) {
      console.error(err)
      setDeleting(false)
      setConfirming(false)
    }
  }

  async function handleSave(e) {
    e.preventDefault()
    e.stopPropagation()
    try {
      const result = await toggleWatchlist(video.id)
      setSaved(result.is_in_watchlist)
    } catch (err) {
      console.error(err)
    }
  }

  return (
    <Link
      to={`/watch/${video.id}`}
      onMouseLeave={() => setConfirming(false)}
      className="group relative block w-36 shrink-0 overflow-hidden rounded-xl bg-panel ring-1 ring-white/10 transition-all duration-300 hover:z-10 hover:scale-[1.03] hover:ring-2 hover:ring-marquee/70 hover:shadow-[0_16px_60px_-18px_rgba(0,0,0,0.9)] focus-visible:z-10 focus-visible:scale-[1.03] sm:w-44 md:w-48"
    >
      <button
        type="button"
        onClick={handleDelete}
        disabled={deleting}
        aria-label={confirming ? 'Confirm delete' : 'Delete title'}
        title={confirming ? 'Click again to delete' : 'Delete title'}
        className={`absolute right-2 top-2 z-20 flex h-7 w-7 items-center justify-center rounded-full opacity-0 backdrop-blur transition-all group-hover:opacity-100 focus-visible:opacity-100 disabled:opacity-100 ${
          confirming ? 'bg-reel text-ivory opacity-100' : 'bg-void/70 text-ash hover:text-reel'
        }`}
      >
        {deleting ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
      </button>
      <button type="button" onClick={handleSave} aria-label={saved ? 'Remove from watch later' : 'Save to watch later'} title={saved ? 'Remove from watch later' : 'Watch later'} className="absolute left-2 top-2 z-20 flex h-7 w-7 items-center justify-center rounded-full bg-void/70 text-ash opacity-0 backdrop-blur transition-all hover:text-marquee group-hover:opacity-100 focus-visible:opacity-100">
        {saved ? <BookmarkCheck size={14} className="text-marquee" /> : <BookmarkPlus size={14} />}
      </button>

      <div
        className="relative flex aspect-[2/3] items-center justify-center overflow-hidden"
        style={!poster ? { background: posterGradient(video.title) } : undefined}
      >
        {poster ? (
          <img
            src={poster}
            alt={video.title}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
            loading="lazy"
          />
        ) : (
          <>
            <div
              className="absolute inset-0 opacity-[0.06]"
              style={{
                backgroundImage:
                  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
              }}
            />
            {video.status === 'processing' || video.status === 'pending_upload' ? (
              <Loader2 size={28} className="animate-spin text-ivory/70" />
            ) : video.status === 'failed' ? (
              <TriangleAlert size={28} className="text-reel" />
            ) : null}
          </>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-void/85 via-transparent to-transparent" />

        {video.status === 'ready' && (
          <div className="absolute inset-0 flex items-center justify-center bg-void/0 opacity-0 transition-opacity group-hover:bg-void/35 group-hover:opacity-100">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-ivory text-void shadow-xl">
              <Play size={22} className="ml-0.5 fill-void" />
            </span>
          </div>
        )}
      </div>

      {hasProgress && (
        <div className="absolute inset-x-0 bottom-[42px] h-1 bg-void/60">
          <div className="h-full bg-[#00a8e1]" style={{ width: `${progressPct}%` }} />
        </div>
      )}

      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-void/95 via-void/70 to-transparent p-2.5 pt-7">
        <p className="truncate text-sm font-semibold text-ivory">{video.title}</p>
        <div className="mt-1 flex items-center justify-between gap-3 text-[10px] uppercase tracking-[0.16em] text-ash">
          <span>{video.genre || video.category || 'Drama'}</span>
          <span>{video.release_year || new Date().getFullYear()}</span>
        </div>
        {statusLabel && (
          <p className="mt-1 font-mono text-[10px] uppercase tracking-wide text-ash">{statusLabel}</p>
        )}
      </div>
    </Link>
  )
}
