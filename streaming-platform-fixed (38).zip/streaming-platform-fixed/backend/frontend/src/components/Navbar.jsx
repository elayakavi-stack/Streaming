import { useState, useRef, useEffect } from 'react'
import { useNavigate, Link, useLocation } from 'react-router-dom'
import { Plus, LogOut, Settings, User, Search, Bell, ChevronDown, Clapperboard, X } from 'lucide-react'
import { currentUserEmail, logout } from '../api/client'

export default function Navbar({ onAddTitle }) {
  const navigate = useNavigate()
  const location = useLocation()
  const email = currentUserEmail()
  const [menuOpen, setMenuOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [search, setSearch] = useState('')
  const menuRef = useRef(null)

  useEffect(() => {
    function handleClickOutside(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false)
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  function handleLogout() {
    logout()
    navigate('/login')
  }

  function submitSearch(event) {
    event.preventDefault()
    if (search.trim()) navigate(`/browse?q=${encodeURIComponent(search.trim())}`)
    setSearchOpen(false)
  }

  return (
    <header className="sticky top-0 z-30 border-b border-white/5 bg-void/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-[1440px] items-center justify-between px-4 sm:px-6">
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center gap-2 text-xl font-extrabold tracking-tight text-ivory">
            <span className="flex h-7 w-7 items-center justify-center rounded bg-marquee text-sm font-black text-void">S</span>
            STREAMVERSE
          </Link>
          <nav className="hidden items-center gap-1 text-sm font-medium text-ash md:flex">
            {[['/', 'Home'], ['/browse', 'Browse'], ['/profile', 'My space']].map(([to, label]) => <Link key={to} to={to} className={`nav-link ${location.pathname === to ? 'nav-link-active' : ''}`}>{label}</Link>)}
          </nav>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <button onClick={() => setSearchOpen(true)} aria-label="Search" className="hidden rounded-full p-2 text-ash transition-colors hover:bg-white/10 hover:text-ivory sm:block"><Search size={19} /></button>
          <button onClick={() => navigate('/profile')} aria-label="Notifications" className="hidden rounded-full p-2 text-ash transition-colors hover:bg-white/10 hover:text-ivory sm:block"><Bell size={19} /></button>
          <button
            onClick={() => onAddTitle ? onAddTitle() : navigate('/', { state: { openUpload: true } })}
            className="flex items-center gap-1.5 rounded-md bg-marquee px-3 py-2 text-sm font-bold text-void transition-colors hover:bg-marquee-dim"
          >
            <Plus size={16} strokeWidth={2.5} />
            <span className="hidden sm:inline">Add title</span>
          </button>

          {email && (
            <div className="relative pl-2" ref={menuRef}>
              <button
                onClick={() => setMenuOpen((v) => !v)}
                aria-label="Account menu"
                aria-expanded={menuOpen}
                className="flex items-center gap-1 rounded-full font-display text-sm text-ivory transition-shadow hover:ring-2 hover:ring-marquee/50"
              >
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#597995] font-bold">{email[0].toUpperCase()}</span><ChevronDown size={14} className="hidden sm:block" />
              </button>

              {menuOpen && (
                <div className="absolute right-0 top-11 w-56 overflow-hidden rounded-md border border-white/10 bg-[#1b2733] shadow-2xl">
                  <p className="truncate border-b border-panel-raised px-4 py-3 text-xs text-ash">{email}</p>
                  <Link to="/browse" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm text-ivory transition-colors hover:bg-panel-raised">
                    <Clapperboard size={15} />
                    Browse catalog
                  </Link>
                  <Link to="/profile" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm text-ivory transition-colors hover:bg-panel-raised">
                    <User size={15} />
                    Profile
                  </Link>
                  <Link to="/settings" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm text-ivory transition-colors hover:bg-panel-raised">
                    <Settings size={15} />
                    Settings
                  </Link>
                  <button onClick={handleLogout} className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-reel transition-colors hover:bg-panel-raised">
                    <LogOut size={15} />
                    Sign out
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {searchOpen && <div className="absolute inset-x-0 top-0 flex h-16 items-center bg-void px-4 shadow-2xl animate-drop-in sm:px-6">
        <form onSubmit={submitSearch} className="mx-auto flex w-full max-w-3xl items-center gap-3 rounded-md border border-white/15 bg-panel px-3 py-2">
          <Search size={18} className="text-marquee" />
          <input autoFocus value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search movies, series, genres and cast" className="min-w-0 flex-1 bg-transparent text-sm text-ivory outline-none placeholder:text-ash" />
          <button type="button" onClick={() => setSearchOpen(false)} aria-label="Close search" className="rounded p-1 text-ash hover:text-ivory"><X size={18} /></button>
        </form>
      </div>}
    </header>
  )
}
