import { useEffect, useRef, useState } from 'react'
import Hls from 'hls.js'

export default function VideoPlayer({ src, initialPosition, onProgress, autoPlay = true }) {
  const videoRef = useRef(null)
  const [qualityOptions, setQualityOptions] = useState([])
  const [selectedQuality, setSelectedQuality] = useState('auto')
  const hlsRef = useRef(null)

  useEffect(() => {
    const video = videoRef.current
    if (!video || !src) return

    let hls
    let didAttach = false

    function handleLoadedMetadata() {
      if (initialPosition && initialPosition > 5 && initialPosition < video.duration - 5) {
        video.currentTime = initialPosition
      }
    }

    function handleQualityUpdate() {
      if (!hls) return
      const mapped = hls.levels.map((level, index) => {
        const height = level.height || 360
        const bitrate = Math.round(level.bitrate / 1000)
        return {
          index,
          label: `${height}p${bitrate ? ` • ${bitrate} kbps` : ''}`,
        }
      })
      setQualityOptions([{ index: -1, label: 'Auto (recommended)' }, ...mapped])
    }

    video.addEventListener('loadedmetadata', handleLoadedMetadata)

    if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = src
    } else if (Hls.isSupported()) {
      hls = new Hls()
      hlsRef.current = hls
      hls.on(Hls.Events.LEVELS_UPDATED, handleQualityUpdate)
      hls.on(Hls.Events.MANIFEST_PARSED, handleQualityUpdate)
      hls.loadSource(src)
      hls.attachMedia(video)
      didAttach = true
    }

    let progressInterval
    function handlePlay() {
      progressInterval = setInterval(() => {
        onProgress?.(video.currentTime, video.duration)
      }, 5000)
    }
    function handlePauseOrEnd() {
      clearInterval(progressInterval)
      onProgress?.(video.currentTime, video.duration)
    }

    video.addEventListener('play', handlePlay)
    video.addEventListener('pause', handlePauseOrEnd)
    video.addEventListener('ended', handlePauseOrEnd)

    return () => {
      clearInterval(progressInterval)
      video.removeEventListener('loadedmetadata', handleLoadedMetadata)
      video.removeEventListener('play', handlePlay)
      video.removeEventListener('pause', handlePauseOrEnd)
      video.removeEventListener('ended', handlePauseOrEnd)
      hls?.destroy()
      hlsRef.current = null
      if (didAttach) setQualityOptions([])
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src])

  function handleQualityChange(nextValue) {
    const hls = hlsRef.current
    if (!hls) return
    setSelectedQuality(nextValue)
    const parsed = Number(nextValue)
    hls.currentLevel = Number.isNaN(parsed) ? -1 : parsed
  }

  if (!src) {
    return (
      <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-md bg-panel text-ash">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-panel-raised border-t-marquee" />
        <p className="font-mono text-xs uppercase tracking-wide">Reel is still developing…</p>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      <div className="relative">
        <video ref={videoRef} controls autoPlay={autoPlay} className="aspect-video w-full rounded-md bg-black shadow-[0_20px_60px_-15px_rgba(0,0,0,0.7)]" />

      {qualityOptions.length > 1 && (
        <div className="absolute bottom-12 right-3 flex items-center gap-2 rounded-md bg-black/75 px-2 py-1.5 text-sm backdrop-blur">
          <label className="text-ash">Quality</label>
          <select
            value={selectedQuality}
            onChange={(e) => handleQualityChange(e.target.value)}
            className="rounded-md border border-white/10 bg-panel px-3 py-1.5 text-ivory outline-none"
          >
            {qualityOptions.map((option) => (
              <option key={option.label} value={option.index}>{option.label}</option>
            ))}
          </select>
        </div>
      )}
      </div>
    </div>
  )
}
