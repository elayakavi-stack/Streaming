import { useLayoutEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { FiChevronRight } from 'react-icons/fi'
import type { Rail } from '@/services/content-api'
import { PosterCard } from './PosterCard'
import { SectionHeading } from '@/components/ui/SectionHeading'

// How many titles show inline in a home-page rail before the rest are
// tucked behind "See all" — keeps a rail to roughly one screenful instead
// of an ever-scrolling row.
const VISIBLE_COUNT = 7

export function ContentRail({ rail, ranked = false, titleClassName }: { rail: Rail; ranked?: boolean; titleClassName?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  const hasMore = Boolean(rail.seeAllHref) && rail.items.length > VISIBLE_COUNT
  const items = hasMore ? rail.items.slice(0, VISIBLE_COUNT) : rail.items

  // Extra safety net: force scrollLeft back to 0 after layout so a rail
  // never renders mid-scroll (e.g. from a stale browser scroll restoration).
  useLayoutEffect(() => {
    if (ref.current) ref.current.scrollLeft = 0
  }, [items])

  return <section className="group/rail py-5">
    <SectionHeading
      eyebrow={rail.subtitle}
      title={rail.title}
      titleClassName={titleClassName}
    />
    <div ref={ref} className="scrollbar-hide flex snap-x snap-mandatory gap-3 overflow-x-auto pb-3 [overflow-anchor:none]">
      {items.map((item, index) => <div className="snap-start" key={item.id}><PosterCard item={item} rank={ranked ? index + 1 : undefined} /></div>)}
      {hasMore && (
        <Link
          to={rail.seeAllHref as string}
          className="group/more flex aspect-[2/3] w-[calc((100%-4*0.75rem)/5)] min-w-[104px] shrink-0 snap-start flex-col items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[.04] text-muted transition hover:border-brand/50 hover:text-ink sm:w-[132px]"
        >
          <span className="grid h-10 w-10 place-items-center rounded-full bg-white/10 transition group-hover/more:bg-brand/20"><FiChevronRight size={18} /></span>
          <span className="text-xs font-bold">See all</span>
        </Link>
      )}
    </div>
  </section>
}
