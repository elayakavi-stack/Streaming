import { useLayoutEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { FiRadio } from 'react-icons/fi'
import type { LiveStream } from '@/services/live-api'

export function LiveNowRail({ streams }: { streams: LiveStream[] }) {
  const ref = useRef<HTMLDivElement>(null)

  // Extra safety net: force scrollLeft back to 0 after layout so this rail
  // never renders mid-scroll.
  useLayoutEffect(() => {
    if (ref.current) ref.current.scrollLeft = 0
  }, [streams])

  if (!streams.length) return null
  return (
    <section className="py-5">
      <h2 className="flex items-center gap-2 font-display text-xl font-black">
        <span className="flex items-center gap-1.5 rounded-full bg-danger px-2.5 py-1 text-xs font-black text-white"><FiRadio /> LIVE</span>
        Live now
      </h2>
      <div ref={ref} className="scrollbar-hide mt-4 flex snap-x snap-mandatory gap-3 overflow-x-auto pb-3 [overflow-anchor:none]">
        {streams.map((stream) => (
          <Link
            key={stream.id}
            to={`/live/${stream.id}`}
            className="group/live relative aspect-video w-72 shrink-0 snap-start overflow-hidden rounded-xl bg-surface sm:w-96"
          >
            {stream.posterUrl ? (
              <img src={stream.posterUrl} alt={stream.title} className="h-full w-full object-cover transition duration-300 group-hover/live:scale-105" />
            ) : (
              <div className="grid h-full w-full place-items-center bg-gradient-to-br from-brand/30 to-violet/30 text-muted">
                <FiRadio size={28} />
              </div>
            )}
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
            <span className="absolute left-3 top-3 flex items-center gap-1.5 rounded-full bg-danger px-2 py-0.5 text-[10px] font-black text-white">
              <FiRadio size={10} /> LIVE
            </span>
            <div className="absolute inset-x-0 bottom-0 p-3">
              <p className="truncate text-sm font-bold text-ink">{stream.title}</p>
              {stream.ownerEmail && <p className="truncate text-xs text-muted">{stream.ownerEmail}</p>}
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}
