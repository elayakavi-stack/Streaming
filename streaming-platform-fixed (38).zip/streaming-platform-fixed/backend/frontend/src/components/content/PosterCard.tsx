import { motion } from 'framer-motion'
import { FiCheck, FiPlay, FiPlus, FiStar } from 'react-icons/fi'
import type { ContentCard } from '@/types/content'
import { useNavigate } from 'react-router-dom'
import { useToggleWatchlist } from '@/features/discovery/queries'

export function PosterCard({ item, rank }: { item: ContentCard; rank?: number }) {
  const navigate = useNavigate()
  const toggleWatchlist = useToggleWatchlist()
  const saved = item.isInWatchlist ?? false
  return <motion.article onClick={() => navigate(`/title/${item.id}`)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') navigate(`/title/${item.id}`) }} layout whileHover={{ y: -8, scale: 1.025 }} transition={{ type: 'spring', stiffness: 340, damping: 24 }} className="group relative w-[142px] shrink-0 cursor-pointer sm:w-[166px] lg:w-[186px]" tabIndex={0} role="link" aria-label={`Open ${item.title}`}>
    {rank && <span aria-hidden="true" className="absolute -left-2 bottom-0 z-10 font-display text-7xl font-black italic leading-none text-surface-raised [text-shadow:2px_0_#4ca5ff]">{rank}</span>}
    <div className="relative aspect-[2/3] overflow-hidden rounded-2xl border border-white/10 bg-surface shadow-panel transition group-hover:border-brand/60">
      {item.posterUrl ? <img src={item.posterUrl} alt="" className="h-full w-full object-cover transition duration-500 group-hover:scale-110" loading="lazy" /> : <div className="grid h-full w-full place-items-center bg-gradient-to-br from-surface-raised to-violet/30 p-4 text-center font-display text-lg font-black text-ink">{item.title}</div>}
      <div className="absolute inset-0 bg-gradient-to-t from-[#07080f] via-transparent to-transparent opacity-95" />
      {item.isNew && <span className="absolute left-2 top-2 rounded-md bg-brand px-2 py-1 text-[10px] font-black uppercase tracking-wider text-canvas">New</span>}
      <div className="absolute inset-x-0 bottom-0 p-3 opacity-0 transition duration-200 group-hover:opacity-100 group-focus-visible:opacity-100"><div className="mb-3 flex gap-2"><button onClick={(event) => { event.stopPropagation(); navigate(`/title/${item.id}?play=1`) }} className="grid h-9 w-9 place-items-center rounded-full bg-ink text-canvas" aria-label={`Play ${item.title}`}><FiPlay className="ml-0.5"/></button><button disabled={toggleWatchlist.isPending} onClick={(event) => { event.stopPropagation(); toggleWatchlist.mutate(item.id) }} className="grid h-9 w-9 place-items-center rounded-full bg-white/15 text-ink backdrop-blur hover:bg-white/25 disabled:opacity-60" aria-label={`${saved ? 'Remove' : 'Add'} ${item.title} ${saved ? 'from' : 'to'} watchlist`}>{saved ? <FiCheck/> : <FiPlus />}</button></div></div>
      {item.progress !== undefined && <div className="absolute bottom-0 left-0 h-1 w-full bg-white/20"><div className="h-full bg-brand" style={{ width: `${item.progress}%` }}/></div>}
    </div>
    <div className="px-1 pt-2"><h3 className="truncate text-sm font-bold text-ink">{item.title}</h3><p className="mt-0.5 flex items-center gap-1 truncate text-xs text-muted"><span>{item.releaseYear}</span>{item.durationLabel && <><span>•</span><span>{item.durationLabel}</span></>}{item.score && <><span>•</span><FiStar className="text-brand"/><span>{item.score}</span></>}</p></div>
  </motion.article>
}
