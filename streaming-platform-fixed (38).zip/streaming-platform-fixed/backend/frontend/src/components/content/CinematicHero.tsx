import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { FiChevronLeft, FiChevronRight, FiCheck, FiInfo, FiPlay, FiPlus, FiStar } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import type { ContentCard } from '@/types/content'
import { Button } from '@/components/ui/Button'
import { useToggleWatchlist } from '@/features/discovery/queries'

const AUTOPLAY_MS = 7000

function HeroSlide({ item }: { item: ContentCard }) {
  const navigate = useNavigate()
  const toggleWatchlist = useToggleWatchlist()
  const saved = item.isInWatchlist ?? false

  return <div className="mx-auto flex min-h-[580px] max-w-[1680px] items-end px-4 pb-16 sm:px-6 lg:px-10 lg:pb-24">
    <div className="max-w-2xl">
      <p className="mb-4 text-xs font-black uppercase tracking-[.28em] text-brand">NovaPlay original</p>
      <h1 className="hero-title font-display text-5xl font-black leading-[.98] tracking-[-.03em] text-ink sm:text-7xl lg:text-8xl">{item.title}</h1>
      <div className="mt-6 flex flex-wrap items-center gap-x-3 gap-y-2 text-sm font-semibold text-[#d4dcf0]">
        <span className="rounded-md bg-white/15 px-2 py-1">{item.maturityRating}</span>
        <span>{item.releaseYear}</span>
        {item.durationLabel && <span>{item.durationLabel}</span>}
        {item.averageRating !== undefined && <span className="flex items-center gap-1"><FiStar className="text-brand"/> {item.averageRating}</span>}
        <span>{item.genres.join(' · ')}</span>
      </div>
      <p className="mt-5 max-w-xl text-base leading-7 text-[#c3cbdd] sm:text-lg">{item.synopsis}</p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Button onClick={() => navigate(`/title/${item.id}?play=1`)}><FiPlay/> Play now</Button>
        <Button variant="secondary" disabled={toggleWatchlist.isPending} onClick={() => toggleWatchlist.mutate(item.id)}>{saved ? <FiCheck/> : <FiPlus/>} {saved ? 'In watchlist' : 'Watch later'}</Button>
        <Button variant="ghost" onClick={() => navigate(`/title/${item.id}`)}><FiInfo/> More info</Button>
      </div>
    </div>
  </div>
}

export function CinematicHero({ item, items }: { item: ContentCard; items?: ContentCard[] }) {
  const slides = useMemo(() => (items && items.length ? items : [item]), [items, item])
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const current = slides[index] ?? slides[0]

  useEffect(() => { setIndex(0) }, [slides])

  useEffect(() => {
    if (slides.length <= 1 || paused) return
    timerRef.current = setInterval(() => setIndex((i) => (i + 1) % slides.length), AUTOPLAY_MS)
    return () => { if (timerRef.current) clearInterval(timerRef.current) }
  }, [slides.length, paused])

  const goTo = (next: number) => setIndex(((next % slides.length) + slides.length) % slides.length)

  return <section
    className="group relative isolate min-h-[580px] overflow-hidden border-b border-white/5"
    onMouseEnter={() => setPaused(true)}
    onMouseLeave={() => setPaused(false)}
  >
    <AnimatePresence mode="popLayout" initial={false}>
      <motion.img
        key={current.id}
        src={current.backdropUrl || current.posterUrl}
        alt=""
        initial={{ opacity: 0, scale: 1.06 }}
        animate={{ opacity: 0.88, scale: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 1.1, ease: 'easeOut' }}
        className="absolute inset-0 -z-20 h-full w-full object-cover object-center"
      />
    </AnimatePresence>
    <div className="absolute inset-0 -z-10 bg-[linear-gradient(90deg,rgba(7,8,15,.85)_0%,rgba(7,8,15,.58)_34%,rgba(7,8,15,.16)_68%,rgba(7,8,15,.04)_100%),linear-gradient(0deg,rgba(7,8,15,.78)_0%,transparent_58%)]"/>

    <AnimatePresence mode="wait">
      <motion.div
        key={current.id}
        initial={{ opacity: 0, y: 28 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -12 }}
        transition={{ duration: .55, ease: 'easeOut' }}
      >
        <HeroSlide item={current}/>
      </motion.div>
    </AnimatePresence>

    {slides.length > 1 && <>
      <button
        onClick={() => goTo(index - 1)}
        aria-label="Previous title"
        className="absolute left-3 top-1/2 z-10 hidden -translate-y-1/2 place-items-center rounded-full border border-white/15 bg-black/30 p-2.5 text-ink/80 opacity-0 backdrop-blur transition duration-300 hover:bg-black/50 hover:text-ink group-hover:opacity-100 sm:grid"
      ><FiChevronLeft size={20}/></button>
      <button
        onClick={() => goTo(index + 1)}
        aria-label="Next title"
        className="absolute right-3 top-1/2 z-10 hidden -translate-y-1/2 place-items-center rounded-full border border-white/15 bg-black/30 p-2.5 text-ink/80 opacity-0 backdrop-blur transition duration-300 hover:bg-black/50 hover:text-ink group-hover:opacity-100 sm:grid"
      ><FiChevronRight size={20}/></button>

      <div className="absolute bottom-6 left-1/2 z-10 flex -translate-x-1/2 items-center gap-2 sm:left-auto sm:right-8 lg:right-10 sm:translate-x-0">
        {slides.map((slide, i) => <button
          key={slide.id}
          onClick={() => goTo(i)}
          aria-label={`Show ${slide.title}`}
          aria-current={i === index}
          className={`h-1.5 rounded-full transition-all ${i === index ? 'w-8 bg-brand' : 'w-3 bg-white/30 hover:bg-white/50'}`}
        />)}
      </div>
    </>}
  </section>
}
