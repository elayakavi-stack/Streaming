import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import { AppErrorBoundary } from './components/system/AppErrorBoundary'
import './index.css'

const root = document.getElementById('root')
if (!root) throw new Error('The application root element is missing.')
ReactDOM.createRoot(root).render(<React.StrictMode><AppErrorBoundary><BrowserRouter><App /></BrowserRouter></AppErrorBoundary></React.StrictMode>)
