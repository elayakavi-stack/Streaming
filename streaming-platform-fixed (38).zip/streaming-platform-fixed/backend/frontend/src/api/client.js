const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000'

function authHeaders() {
  const token = localStorage.getItem('access_token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

function buildQuery(params) {
  const search = new URLSearchParams()
  Object.entries(params || {}).forEach(([key, value]) => {
    if (value === undefined || value === null || value === '') return
    search.append(key, String(value))
  })
  const qs = search.toString()
  return qs ? `?${qs}` : ''
}

export function currentUserEmail() {
  const token = localStorage.getItem('access_token')
  if (!token) return null
  try {
    const payload = JSON.parse(atob(token.split('.')[1]))
    return payload.sub || null
  } catch {
    return null
  }
}

export function isAuthenticated() {
  return Boolean(localStorage.getItem('access_token'))
}

export function logout() {
  localStorage.removeItem('access_token')
}

export async function login(email, password) {
  const body = new URLSearchParams({ username: email, password })
  const res = await fetch(`${API_BASE}/auth/login`, { method: 'POST', body })
  if (!res.ok) throw new Error('Login failed')
  const data = await res.json()
  localStorage.setItem('access_token', data.access_token)
  return data
}

export async function register(email, password) {
  const res = await fetch(`${API_BASE}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  })
  if (!res.ok) throw new Error('Registration failed')
  return res.json()
}

export async function listVideos() {
  const res = await fetch(`${API_BASE}/videos`, { headers: authHeaders() })
  if (!res.ok) throw new Error('Failed to load videos')
  return res.json()
}

export async function getVideo(videoId) {
  const res = await fetch(`${API_BASE}/videos/${videoId}`, { headers: authHeaders() })
  if (!res.ok) throw new Error('Failed to load video')
  return res.json()
}

export async function getHome() {
  const res = await fetch(`${API_BASE}/videos/home`, { headers: authHeaders() })
  if (!res.ok) throw new Error('Failed to load home rails')
  return res.json()
}

export async function getCatalog({ q, category, genre, year, page = 1, pageSize = 24 }) {
  const res = await fetch(
    `${API_BASE}/videos/catalog${buildQuery({ q, category, genre, year, page, page_size: pageSize })}`,
    { headers: authHeaders() },
  )
  if (!res.ok) throw new Error('Failed to load catalog')
  return res.json()
}

export async function getGenres() {
  const res = await fetch(`${API_BASE}/videos/genres`, { headers: authHeaders() })
  if (!res.ok) throw new Error('Failed to load genres')
  return res.json()
}

export async function getWatchlist() {
  const res = await fetch(`${API_BASE}/videos/watchlist`, { headers: authHeaders() })
  if (!res.ok) throw new Error('Failed to load watchlist')
  return res.json()
}

export async function deleteVideo(videoId) {
  const res = await fetch(`${API_BASE}/videos/${videoId}`, {
    method: 'DELETE',
    headers: authHeaders(),
  })
  if (!res.ok) throw new Error('Failed to delete video')
}

export async function getContinueWatching() {
  const res = await fetch(`${API_BASE}/videos/continue-watching`, { headers: authHeaders() })
  if (!res.ok) throw new Error('Failed to load continue watching')
  return res.json()
}

export async function toggleWatchlist(videoId) {
  const res = await fetch(`${API_BASE}/videos/${videoId}/watchlist`, {
    method: 'POST',
    headers: authHeaders(),
  })
  if (!res.ok) throw new Error('Failed to update watchlist')
  return res.json()
}

export async function rateVideo(videoId, value, review = '') {
  const res = await fetch(`${API_BASE}/videos/${videoId}/rating`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ value, review }),
  })
  if (!res.ok) throw new Error('Failed to rate video')
  return res.json()
}

export async function saveProgress(videoId, positionSeconds, durationSeconds) {
  try {
    await fetch(`${API_BASE}/videos/${videoId}/progress`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ progress_seconds: positionSeconds, duration_seconds: durationSeconds }),
    })
  } catch {
    // Non-critical
  }
}

export async function getMe() {
  const res = await fetch(`${API_BASE}/auth/me`, { headers: authHeaders() })
  if (!res.ok) throw new Error('Failed to load account')
  return res.json()
}

export async function createVideo({
  title,
  description,
  category,
  genre,
  rating,
  imdbScore,
  releaseYear,
  castMembers,
  director,
  filename,
  contentType,
}) {
  const res = await fetch(`${API_BASE}/videos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({
      title,
      description,
      category,
      genre,
      rating,
      imdb_score: imdbScore,
      release_year: releaseYear,
      cast_members: castMembers,
      director,
      filename,
      content_type: contentType,
    }),
  })
  if (!res.ok) throw new Error('Failed to create video')
  return res.json()
}

export async function uploadToS3(uploadUrl, file, onProgress, contentType) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest()
    xhr.open('PUT', uploadUrl)
    xhr.setRequestHeader('Content-Type', contentType)
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) onProgress(Math.round((e.loaded / e.total) * 100))
    }
    xhr.onload = () => (xhr.status < 300 ? resolve() : reject(new Error('S3 upload failed')))
    xhr.onerror = () => reject(new Error('S3 upload failed'))
    xhr.send(file)
  })
}

export async function completeUpload(videoId) {
  const res = await fetch(`${API_BASE}/videos/${videoId}/complete-upload`, {
    method: 'POST',
    headers: authHeaders(),
  })
  if (!res.ok) throw new Error('Failed to mark upload complete')
  return res.json()
}
