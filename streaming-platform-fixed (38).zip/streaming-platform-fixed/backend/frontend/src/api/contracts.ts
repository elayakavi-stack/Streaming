import type { ContentCard, PaginatedResponse } from '@/types/content'

/** API boundary: replace these contracts with generated OpenAPI types when available. */
export interface ContentApi {
  listHomeRails(): Promise<PaginatedResponse<{ id: string; title: string; items: ContentCard[] }>>
  searchContent(input: { query: string; cursor?: string }): Promise<PaginatedResponse<ContentCard>>
}
