/** Mood tags are stored as fixed vocabulary (see COMMON_MOODS in
 * constants/genres.ts) that sometimes bundles two synonyms with a slash
 * (e.g. "Dark/Intense") and sometimes uses a checkbox-label form that's a
 * little stiff read aloud (e.g. "Easy-watching", "Bingeable"). Splitting on
 * "/" and lowercasing fixes the spec-sheet look ("Dark/Intense,
 * Tense/Thrilling" → "dark, intense, tense, thrilling") but still leaves
 * a flat list, not a sentence — "dark, thriller"-style word dumps don't
 * read like something a person would actually say.
 *
 * This maps each individual word to the phrase a person would use for it —
 * an adjective, not a label — so any combination of tags still reads as a
 * real sentence: "because it's dark and thrilling", not "because it's dark,
 * thriller". Unrecognized words (future vocabulary, free text) fall back to
 * a trimmed, lowercased pass-through rather than breaking. */
const MOOD_PHRASES: Record<string, string> = {
  'feel-good': 'feel-good',
  uplifting: 'uplifting',
  heartwarming: 'heartwarming',
  comforting: 'comforting',
  inspiring: 'inspiring',
  nostalgic: 'nostalgic',
  whimsical: 'whimsical',
  romantic: 'romantic',
  hilarious: 'hilarious',
  witty: 'witty',
  chill: 'laid-back',
  'easy-watching': 'easygoing',
  tense: 'tense',
  thrilling: 'thrilling',
  suspenseful: 'suspenseful',
  scary: 'scary',
  unsettling: 'unsettling',
  dark: 'dark',
  intense: 'intense',
  bittersweet: 'bittersweet',
  'thought-provoking': 'thought-provoking',
  bingeable: 'binge-worthy',
  'fast-paced': 'fast-paced',
}

function naturalWord(raw: string): string {
  const key = raw.trim().toLowerCase()
  return MOOD_PHRASES[key] ?? key
}

export function humanizeMoods(moods: string[] = [], max = 2): string {
  const words = moods
    .slice(0, max)
    .flatMap((mood) => mood.split('/'))
    .map(naturalWord)
    .filter(Boolean)

  const unique = [...new Set(words)]
  if (unique.length === 0) return ''
  if (unique.length === 1) return unique[0]
  if (unique.length === 2) return `${unique[0]} and ${unique[1]}`
  return `${unique.slice(0, -1).join(', ')} and ${unique[unique.length - 1]}`
}
