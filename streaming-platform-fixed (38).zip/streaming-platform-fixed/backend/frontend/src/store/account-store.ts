import { create } from 'zustand'

// Which profile is "active" in the UI is a local concern only — the backend
// doesn't track a current profile, it just stores the list under /profiles.
type AccountState = { activeProfileId: string | null; setActiveProfile: (id: string) => void }
export const useAccountStore = create<AccountState>((set) => ({
  activeProfileId: null,
  setActiveProfile: (activeProfileId) => set({ activeProfileId }),
}))
