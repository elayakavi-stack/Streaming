import { create } from 'zustand'

type UiStore = { isSearchOpen: boolean; setSearchOpen: (open: boolean) => void; isSidebarOpen: boolean; setSidebarOpen: (open: boolean) => void }
export const useUiStore = create<UiStore>((set) => ({
  isSearchOpen: false,
  setSearchOpen: (isSearchOpen) => set({ isSearchOpen }),
  isSidebarOpen: false,
  setSidebarOpen: (isSidebarOpen) => set({ isSidebarOpen }),
}))
