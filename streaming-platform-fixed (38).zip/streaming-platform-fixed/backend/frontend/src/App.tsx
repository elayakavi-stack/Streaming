import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import type { ReactNode } from 'react'
import { Navigate, Route, Routes, useParams } from 'react-router-dom'
import { AppShell } from '@/layouts/AppShell'
import { AuthLayout } from '@/layouts/AuthLayout'
import { RequireAdmin } from '@/components/system/RequireAdmin'
import { RequireSignIn } from '@/components/system/RequireSignIn'
import { AccountPage } from '@/pages/AccountPage'
import { AdminDashboardPage } from '@/pages/AdminDashboardPage'
import { AdminWorkspacePage } from '@/pages/AdminWorkspacePage'
import { BrowsePage } from '@/pages/BrowsePage'
import { CollectionPage } from '@/pages/CollectionPage'
import { DesignSystemPage } from '@/pages/DesignSystemPage'
import { ForgotPasswordPage, LoginPage, OtpPage, RegisterPage } from '@/pages/AuthPages'
import { GoLivePage } from '@/pages/GoLivePage'
import { HomePage } from '@/pages/HomePage'
import { LiveWatchPage } from '@/pages/LiveWatchPage'
import { NotFoundPage } from '@/pages/NotFoundPage'
import { SettingsPage } from '@/pages/SettingsPage'
import { TitleDetailsPage } from '@/pages/TitleDetailsPage'
import { UploadTitlePage } from '@/pages/UploadTitlePage'
import { UtilityPage } from '@/pages/UtilityPage'

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, staleTime: 30_000, refetchOnWindowFocus: false } } })
const admin = (element: ReactNode) => <RequireAdmin>{element}</RequireAdmin>
const signedIn = (element: ReactNode) => <RequireSignIn>{element}</RequireSignIn>

/** Old `/watch/:id` links redirect straight into the merged title page,
 * already playing — details and playback are one page now (see
 * TitleDetailsPage), not two separate routes. */
function WatchRedirect() {
  const { id = '' } = useParams()
  return <Navigate to={`/title/${id}?play=1`} replace />
}

export default function App() {
  return <QueryClientProvider client={queryClient}><Routes>
    <Route element={<AuthLayout/>}>
      <Route path="/login" element={<LoginPage/>}/><Route path="/register" element={<RegisterPage/>}/><Route path="/forgot-password" element={<ForgotPasswordPage/>}/><Route path="/otp" element={<OtpPage/>}/>
    </Route>
    <Route element={<AppShell/>}>
      <Route path="/" element={<HomePage/>}/><Route path="/browse" element={<BrowsePage/>}/><Route path="/movies" element={<CollectionPage/>}/><Route path="/series" element={<CollectionPage/>}/><Route path="/sports" element={<CollectionPage/>}/><Route path="/kids" element={<CollectionPage/>}/><Route path="/trending" element={<CollectionPage/>}/><Route path="/new-releases" element={<CollectionPage/>}/><Route path="/top-rated" element={<CollectionPage/>}/><Route path="/genres" element={<CollectionPage/>}/><Route path="/languages" element={<CollectionPage/>}/><Route path="/watchlist" element={<CollectionPage/>}/>{/* Title details and playback live on one page (OTT-style): "Play" just
          flips a `?play=1` flag on this same route, in place — it never
          navigates to a separate player page. */}
      <Route path="/title/:id" element={<TitleDetailsPage/>}/><Route path="/watch/:id" element={<WatchRedirect/>}/><Route path="/live/:id" element={<LiveWatchPage/>}/><Route path="/go-live" element={signedIn(<GoLivePage/>)}/><Route path="/account" element={<AccountPage/>}/><Route path="/settings" element={<SettingsPage/>}/>
      <Route path="/admin" element={admin(<AdminDashboardPage/>)}/><Route path="/admin/upload" element={admin(<UploadTitlePage/>)}/><Route path="/admin/users" element={admin(<AdminWorkspacePage/>)}/><Route path="/admin/content" element={admin(<AdminWorkspacePage/>)}/><Route path="/admin/categories" element={admin(<AdminWorkspacePage/>)}/><Route path="/admin/reports" element={admin(<AdminWorkspacePage/>)}/><Route path="/admin/uploads" element={admin(<AdminWorkspacePage/>)}/>
      <Route path="/downloads" element={<UtilityPage/>}/><Route path="/history" element={<UtilityPage/>}/><Route path="/notifications" element={<UtilityPage/>}/><Route path="/help" element={<UtilityPage/>}/><Route path="/subscription" element={<UtilityPage/>}/><Route path="/design-system" element={<DesignSystemPage/>}/><Route path="*" element={<NotFoundPage/>}/>
    </Route>
  </Routes></QueryClientProvider>
}
