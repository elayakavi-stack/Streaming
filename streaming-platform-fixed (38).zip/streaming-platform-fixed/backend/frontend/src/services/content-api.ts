import type { ContentCard, PaginatedResponse, SubtitleTrack } from '@/types/content'

const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:8000'

type ApiVideo = {
  id: string
  title: string
  description?: string
  category?: string
  genre?: string
  sub_genre?: string | null
  rating?: string
  imdb_score?: string
  release_year?: number
  cast_members?: string
  director?: string
  poster_url?: string
  backdrop_url?: string
  original_language?: string | null
  moods?: string | null
  progress_seconds?: number
  duration_seconds?: number
  status: string
  playback_url?: string | null
  is_in_watchlist?: boolean
  average_rating?: number | null
  rating_count?: number
  user_rating?: number | null
  user_review?: string | null
  audio_tracks?: { language: string; name: string }[]
  subtitles?: { id: string; language: string; label: string; url: string; is_default: boolean }[]
  pending_audio_sources?: { id: string; language: string; label: string; is_default: boolean }[]
}
type ApiRail = { key: string; title: string; subtitle?: string | null; items: ApiVideo[] }
type ApiCatalogPage = { items: ApiVideo[]; total: number; page: number; page_size: number }

const headers = (): Record<string, string> => {
  const token = localStorage.getItem('access_token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

const formatDuration = (seconds?: number): string | undefined => {
  if (!seconds) return undefined
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.round((seconds % 3600) / 60)
  return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`
}

const mapVideo = (video: ApiVideo): ContentCard => ({
  id: video.id,
  kind: video.category === 'TV Show' ? 'series' : 'movie',
  rawCategory: video.category,
  title: video.title,
  posterUrl: video.poster_url ?? '',
  backdropUrl: video.backdrop_url,
  releaseYear: video.release_year ?? new Date().getFullYear(),
  maturityRating: video.rating ?? 'U/A 16+',
  durationLabel: formatDuration(video.duration_seconds),
  genres: video.genre ? [video.genre] : [],
  subGenre: video.sub_genre ?? undefined,
  originalLanguage: video.original_language ?? undefined,
  moods: video.moods ? video.moods.split(',').map((m) => m.trim()).filter(Boolean) : undefined,
  score: Number(video.imdb_score ?? 0) || undefined,
  synopsis: video.description,
  progress:
    video.progress_seconds && video.duration_seconds
      ? Math.min(100, Math.round((video.progress_seconds / video.duration_seconds) * 100))
      : undefined,
  progressSeconds: video.progress_seconds || undefined,
  isInWatchlist: video.is_in_watchlist ?? false,
  averageRating: video.average_rating ?? undefined,
  ratingCount: video.rating_count ?? 0,
  userRating: video.user_rating ?? undefined,
  userReview: video.user_review ?? undefined,
  playbackUrl: video.playback_url ?? null,
  status: video.status as ContentCard['status'],
  director: video.director,
  castMembers: video.cast_members,
  audioTracks: video.audio_tracks,
  subtitles: video.subtitles?.map((s) => ({ id: s.id, language: s.language, label: s.label, url: s.url, isDefault: s.is_default })),
  pendingAudioSources: video.pending_audio_sources?.map((a) => ({ id: a.id, language: a.language, label: a.label, isDefault: a.is_default })),
})

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const error = (await response.json().catch(() => null)) as { detail?: string } | null
    throw new Error(error?.detail ?? `API request failed (${response.status})`)
  }
  return response.json() as Promise<T>
}

const request = async <T,>(path: string): Promise<T> => {
  const response = await fetch(`${API_BASE}${path}`, { headers: headers() })
  return handleResponse<T>(response)
}

const requestJson = async <T,>(path: string, method: string, body?: unknown): Promise<T> => {
  const response = await fetch(`${API_BASE}${path}`, {
    method,
    headers: { ...headers(), 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  return handleResponse<T>(response)
}

const requestVoid = async (path: string, method: string): Promise<void> => {
  const response = await fetch(`${API_BASE}${path}`, { method, headers: headers() })
  if (!response.ok) {
    const error = (await response.json().catch(() => null)) as { detail?: string } | null
    throw new Error(error?.detail ?? `API request failed (${response.status})`)
  }
}

export type Rail = { id: string; title: string; subtitle?: string; items: ContentCard[]; seeAllHref?: string }

// Where "See all" for a given home-page rail should go. Only rails that map
// cleanly onto an existing browse/collection page get one — "Recommended for
// you", "More like your recent watches", and "Continue watching" are
// personalized/algorithmic picks with no equivalent full-catalog page, so
// those stay as plain scrollable rails.
function seeAllHrefFor(key: string, title: string): string | undefined {
  if (key === 'new-releases') return '/new-releases'
  if (key.startsWith('genre-')) {
    const genreName = title.endsWith(' Movies') ? title.slice(0, -' Movies'.length) : title
    return `/genres?genre=${encodeURIComponent(genreName)}`
  }
  return undefined
}

export const contentApi = {
  async getHome(): Promise<{ hero: ContentCard | null; heroItems: ContentCard[]; rails: Rail[] }> {
    const rails = await request<ApiRail[]>('/videos/home')
    const mapped = rails
      .map((rail) => ({
        id: rail.key,
        title: rail.title,
        subtitle: rail.subtitle ?? undefined,
        items: rail.items.filter((video) => video.status === 'ready').map(mapVideo),
        seeAllHref: seeAllHrefFor(rail.key, rail.title),
      }))
      .filter((rail) => rail.items.length)
    // Pull hero candidates from the featured rail first, then backfill with other rails so the
    // banner always has a handful of titles to rotate through, without duplicates.
    const seen = new Set<string>()
    const heroItems: ContentCard[] = []
    for (const rail of mapped) {
      for (const item of rail.items) {
        if (seen.has(item.id) || !item.backdropUrl) continue
        seen.add(item.id)
        heroItems.push(item)
        if (heroItems.length >= 6) break
      }
      if (heroItems.length >= 6) break
    }
    if (!heroItems.length && mapped[0]?.items[0]) heroItems.push(mapped[0].items[0])
    return { hero: heroItems[0] ?? null, heroItems, rails: mapped }
  },

  async search(query: string): Promise<PaginatedResponse<ContentCard>> {
    const result = await request<ApiCatalogPage>(`/videos/catalog?q=${encodeURIComponent(query)}&page_size=50`)
    return { data: result.items.map(mapVideo), nextCursor: null, total: result.total }
  },

  /** Full catalog filters: category, genre, year, and pagination map straight onto GET /videos/catalog. */
  async getCatalog(params: { category?: string; genre?: string; year?: number; newReleaseDays?: number; page?: number; pageSize?: number } = {}): Promise<PaginatedResponse<ContentCard>> {
    const query = new URLSearchParams()
    if (params.category) query.set('category', params.category)
    if (params.genre) query.set('genre', params.genre)
    if (params.year) query.set('year', String(params.year))
    if (params.newReleaseDays) query.set('new_release_days', String(params.newReleaseDays))
    query.set('page', String(params.page ?? 1))
    query.set('page_size', String(params.pageSize ?? 48))
    const result = await request<ApiCatalogPage>(`/videos/catalog?${query.toString()}`)
    return { data: result.items.map(mapVideo), nextCursor: null, total: result.total }
  },

  async getRecommendations(): Promise<ContentCard[]> {
    const videos = await request<ApiVideo[]>('/videos/recommendations')
    return videos.filter((video) => video.status === 'ready').map(mapVideo)
  },

  async getGenres(): Promise<string[]> {
    return request<string[]>('/videos/genres')
  },

  async getWatchlist(): Promise<ContentCard[]> {
    const items = await request<ApiVideo[]>('/videos/watchlist')
    return items.map(mapVideo)
  },

  async getContinueWatching(): Promise<ContentCard[]> {
    const items = await request<ApiVideo[]>('/videos/continue-watching')
    return items.map(mapVideo)
  },

  async getById(id: string): Promise<ContentCard | null> {
    try {
      return mapVideo(await request<ApiVideo>(`/videos/${id}`))
    } catch (error) {
      if (error instanceof Error && error.message.includes('(404)')) return null
      throw error
    }
  },

  /** "More like this mood" rail for the player page — titles sharing mood
   * tags with the one currently playing. Empty array (not an error) when
   * the title has no moods set — see app/routers/videos.py:get_similar_mood. */
  async getSimilarMood(id: string): Promise<ContentCard[]> {
    const videos = await request<ApiVideo[]>(`/videos/${id}/similar-mood`)
    return videos.map(mapVideo)
  },

  /** "Because you watched X" rail for the player page — titles led by the
   * same director or sharing a cast member with the one currently playing,
   * falling back to genre overlap only when there's no cast/director match
   * (see app/routers/videos.py:get_because_you_watched). */
  async getBecauseYouWatched(id: string): Promise<ContentCard[]> {
    const videos = await request<ApiVideo[]>(`/videos/${id}/because-you-watched`)
    return videos.map(mapVideo)
  },

  async toggleWatchlist(id: string): Promise<{ isInWatchlist: boolean; message: string }> {
    const result = await requestJson<{ video_id: string; is_in_watchlist: boolean; message: string }>(`/videos/${id}/watchlist`, 'POST')
    return { isInWatchlist: result.is_in_watchlist, message: result.message }
  },

  async rateVideo(id: string, value: number, review?: string): Promise<{ value: number; averageRating: number; ratingCount: number }> {
    const result = await requestJson<{ video_id: string; value: number; average_rating: number; rating_count: number }>(`/videos/${id}/rating`, 'PUT', { value, review })
    return { value: result.value, averageRating: result.average_rating, ratingCount: result.rating_count }
  },

  async saveProgress(id: string, positionSeconds: number, durationSeconds?: number): Promise<void> {
    try {
      await requestJson(`/videos/${id}/progress`, 'PUT', { progress_seconds: positionSeconds, duration_seconds: durationSeconds })
    } catch {
      // Non-critical: don't interrupt playback if a progress ping fails.
    }
  },

  async deleteVideo(id: string): Promise<void> {
    await requestVoid(`/videos/${id}`, 'DELETE')
  },

  /** Re-runs the transcode pipeline for a title that's already ready or
   * failed, against the raw file still sitting in S3. Use this to bring an
   * older upload — one processed before multi-quality/multi-audio existed,
   * or before extra audio/subtitle tracks were added at upload time — up
   * to date with the current pipeline. */
  async reprocessVideo(id: string): Promise<ContentCard> {
    return mapVideo(await requestJson<ApiVideo>(`/videos/${id}/reprocess`, 'POST'))
  },

  async updateVideo(id: string, patch: {
    title?: string; description?: string; category?: string; genre?: string; subGenre?: string; rating?: string
    imdbScore?: string; releaseYear?: number; castMembers?: string; director?: string; originalLanguage?: string; moods?: string[]
    posterUrl?: string; backdropUrl?: string
  }): Promise<ContentCard> {
    const body = {
      title: patch.title, description: patch.description, category: patch.category, genre: patch.genre,
      sub_genre: patch.subGenre,
      rating: patch.rating, imdb_score: patch.imdbScore, release_year: patch.releaseYear,
      cast_members: patch.castMembers, director: patch.director,
      original_language: patch.originalLanguage,
      moods: patch.moods ? patch.moods.join(',') : undefined,
      poster_url: patch.posterUrl, backdrop_url: patch.backdropUrl,
    }
    // Only send fields that were actually provided, so a partial edit doesn't
    // accidentally null out fields the form didn't touch.
    const filtered = Object.fromEntries(Object.entries(body).filter(([, v]) => v !== undefined))
    return mapVideo(await requestJson<ApiVideo>(`/videos/${id}`, 'PATCH', filtered))
  },

  async reportVideo(id: string, subject: string, message?: string): Promise<void> {
    await requestJson(`/videos/${id}/report`, 'POST', { subject, message })
  },

  async addSubtitle(videoId: string, input: { language: string; label: string; isDefault?: boolean; file: File }): Promise<SubtitleTrack> {
    // Note: content_type sent here is advisory only — the backend derives the
    // real Content-Type from the filename extension (File.type for .vtt/.srt
    // is unreliable across browsers/OSes) and returns it below. The PUT must
    // use that returned value, since it's what was actually signed into the
    // presigned URL.
    const signed = await requestJson<{ upload_url: string; subtitle_url: string; content_type: string }>(`/videos/${videoId}/subtitles/presign`, 'POST', {
      filename: input.file.name,
      content_type: input.file.type || 'text/vtt',
    })
    const uploaded = await fetch(signed.upload_url, { method: 'PUT', headers: { 'Content-Type': signed.content_type }, body: input.file })
    if (!uploaded.ok) throw new Error('Subtitle upload to S3 failed')
    const created = await requestJson<{ id: string; language: string; label: string; url: string; is_default: boolean }>(`/videos/${videoId}/subtitles`, 'POST', {
      language: input.language,
      label: input.label,
      url: signed.subtitle_url,
      is_default: input.isDefault ?? false,
    })
    return { id: created.id, language: created.language, label: created.label, url: created.url, isDefault: created.is_default }
  },

  async removeSubtitle(videoId: string, subtitleId: string): Promise<void> {
    await requestVoid(`/videos/${videoId}/subtitles/${subtitleId}`, 'DELETE')
  },

  async uploadArtwork(file: File, purpose: 'poster' | 'backdrop'): Promise<string> {
    const signed = await requestJson<{ upload_url: string; asset_url: string }>('/videos/assets/presign', 'POST', { filename: file.name, content_type: file.type, purpose })
    const uploaded = await fetch(signed.upload_url, { method: 'PUT', headers: { 'Content-Type': file.type }, body: file })
    if (!uploaded.ok) throw new Error('Artwork upload to S3 failed')
    return signed.asset_url
  },

  /** Creates the video row and gets back a presigned URL for the raw file —
   * split out from the old single-shot `createTitle` so the caller can add
   * audio tracks / subtitles (which need the video's id) in between this
   * and `completeUpload`, before the transcode job is queued. */
  async createVideoRecord(input: { title: string; description: string; category: string; genre: string; subGenre?: string; rating: string; releaseYear: number; castMembers: string; director: string; posterUrl?: string; backdropUrl?: string; originalLanguage?: string; moods?: string[]; filename: string; contentType: string }): Promise<{ videoId: string; uploadUrl: string }> {
    const created = await requestJson<{ video_id: string; upload_url: string }>('/videos', 'POST', {
      title: input.title,
      description: input.description,
      category: input.category,
      genre: input.genre,
      sub_genre: input.subGenre || undefined,
      rating: input.rating,
      release_year: input.releaseYear,
      cast_members: input.castMembers,
      director: input.director,
      poster_url: input.posterUrl,
      backdrop_url: input.backdropUrl,
      original_language: input.originalLanguage || undefined,
      moods: input.moods && input.moods.length > 0 ? input.moods.join(',') : undefined,
      filename: input.filename,
      content_type: input.contentType || 'video/mp4',
    })
    return { videoId: created.video_id, uploadUrl: created.upload_url }
  },

  async uploadRawFile(uploadUrl: string, file: File): Promise<void> {
    const uploaded = await fetch(uploadUrl, { method: 'PUT', headers: { 'Content-Type': file.type || 'video/mp4' }, body: file })
    if (!uploaded.ok) throw new Error('Video upload to S3 failed')
  },

  /** Queues the HLS transcode job. Call once the raw video, and any extra
   * audio tracks / subtitles, have all finished uploading — the worker
   * picks up whatever's attached to the video at this point. */
  async completeUpload(videoId: string): Promise<void> {
    await requestJson(`/videos/${videoId}/complete-upload`, 'POST')
  },

  async createTitle(input: { title: string; description: string; category: string; genre: string; subGenre?: string; rating: string; releaseYear: number; castMembers: string; director: string; posterUrl?: string; backdropUrl?: string; file: File }): Promise<string> {
    const { videoId, uploadUrl } = await this.createVideoRecord({ ...input, filename: input.file.name, contentType: input.file.type || 'video/mp4' })
    await this.uploadRawFile(uploadUrl, input.file)
    await this.completeUpload(videoId)
    return videoId
  },

  /** Attaches a separate raw dub/audio-track file to a title (e.g. a
   * standalone Hindi audio file for an English-only video). Works both
   * before the title's first upload finishes and afterward — for a title
   * that's already `ready` or `failed`, the backend also queues a
   * reprocess so the track is actually muxed into the streaming files
   * rather than sitting unused (see app/routers/videos.py:add_audio_source).
   * The transcode worker downloads it and encodes it into its own
   * selectable HLS audio track alongside whatever audio is already
   * embedded in the video — see app/worker/transcode.py:transcode_to_hls. */
  async addAudioTrack(videoId: string, input: { language: string; label: string; isDefault?: boolean; file: File }): Promise<{ id: string; language: string; label: string; isDefault: boolean }> {
    const contentType = input.file.type || 'audio/mpeg'
    const signed = await requestJson<{ upload_url: string; key: string }>(`/videos/${videoId}/audio-tracks/presign`, 'POST', {
      filename: input.file.name,
      content_type: contentType,
    })
    const uploaded = await fetch(signed.upload_url, { method: 'PUT', headers: { 'Content-Type': contentType }, body: input.file })
    if (!uploaded.ok) throw new Error('Audio track upload to S3 failed')
    const created = await requestJson<{ id: string; language: string; label: string; is_default: boolean }>(`/videos/${videoId}/audio-tracks`, 'POST', {
      language: input.language,
      label: input.label,
      raw_s3_key: signed.key,
      is_default: input.isDefault ?? false,
    })
    return { id: created.id, language: created.language, label: created.label, isDefault: created.is_default }
  },

  /** Removes a pending/attached dub track. For a title that's already
   * `ready` or `failed`, the backend also queues a reprocess so the
   * removal actually takes effect in the streaming files. */
  async removeAudioTrack(videoId: string, audioSourceId: string): Promise<void> {
    await requestVoid(`/videos/${videoId}/audio-tracks/${audioSourceId}`, 'DELETE')
  },
}
