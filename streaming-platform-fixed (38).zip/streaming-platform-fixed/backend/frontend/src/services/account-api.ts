import type { ContentCard } from '@/types/content'

const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:8000'

const headers = (): Record<string, string> => {
  const token = localStorage.getItem('access_token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

async function errorMessage(response: Response) {
  const body = (await response.json().catch(() => null)) as { detail?: string } | null
  return body?.detail ?? `Request failed (${response.status})`
}

async function handle<T>(response: Response): Promise<T> {
  if (!response.ok) throw new Error(await errorMessage(response))
  if (response.status === 204) return undefined as T
  return response.json() as Promise<T>
}

const get = async <T,>(path: string): Promise<T> => handle<T>(await fetch(`${API_BASE}${path}`, { headers: headers() }))
const send = async <T,>(path: string, method: string, body?: unknown): Promise<T> =>
  handle<T>(
    await fetch(`${API_BASE}${path}`, {
      method,
      headers: { ...headers(), 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    }),
  )
const del = async <T,>(path: string): Promise<T> => handle<T>(await fetch(`${API_BASE}${path}`, { method: 'DELETE', headers: headers() }))

// ---- Preferences ----

export type Preferences = { autoplay: boolean; autoplayPreviews: boolean; dataSaver: boolean; emailNotifications: boolean }
type ApiPreferences = { autoplay: boolean; autoplay_previews: boolean; data_saver: boolean; email_notifications: boolean }

const mapPreferences = (p: ApiPreferences): Preferences => ({
  autoplay: p.autoplay,
  autoplayPreviews: p.autoplay_previews,
  dataSaver: p.data_saver,
  emailNotifications: p.email_notifications,
})

// ---- Subscription ----

export type Plan = 'essential' | 'premium' | 'ultimate'
export type Subscription = { plan: Plan; pricePerMonth: number; perks: string[] }
type ApiSubscription = { plan: Plan; price_per_month: number; perks: string[] }

const mapSubscription = (s: ApiSubscription): Subscription => ({ plan: s.plan, pricePerMonth: s.price_per_month, perks: s.perks })

// ---- Notifications ----

export type Notification = { id: string; kind: string; title: string; message?: string; isRead: boolean; createdAt: string; videoId?: string }
type ApiNotification = { id: string; kind: string; title: string; message?: string; is_read: boolean; created_at: string; video_id?: string }

const mapNotification = (n: ApiNotification): Notification => ({
  id: n.id,
  kind: n.kind,
  title: n.title,
  message: n.message,
  isRead: n.is_read,
  createdAt: n.created_at,
  videoId: n.video_id,
})

// ---- Downloads / history (reuse the same content-api video mapper shape) ----

type ApiVideo = {
  id: string
  title: string
  description?: string
  category?: string
  genre?: string
  rating?: string
  imdb_score?: string
  release_year?: number
  cast_members?: string
  director?: string
  poster_url?: string
  backdrop_url?: string
  progress_seconds?: number
  duration_seconds?: number
  status: string
  playback_url?: string | null
  is_in_watchlist?: boolean
  average_rating?: number | null
  rating_count?: number
  user_rating?: number | null
}

const formatDuration = (seconds?: number): string | undefined => {
  if (!seconds) return undefined
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.round((seconds % 3600) / 60)
  return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`
}

const mapVideo = (video: ApiVideo): ContentCard => ({
  id: video.id,
  kind: video.category === 'TV Show' ? 'series' : 'movie',
  title: video.title,
  posterUrl: video.poster_url ?? '',
  backdropUrl: video.backdrop_url,
  releaseYear: video.release_year ?? new Date().getFullYear(),
  maturityRating: video.rating ?? 'U/A 16+',
  durationLabel: formatDuration(video.duration_seconds),
  genres: video.genre ? [video.genre] : [],
  score: Number(video.imdb_score ?? 0) || undefined,
  synopsis: video.description,
  progress: video.progress_seconds && video.duration_seconds ? Math.min(100, Math.round((video.progress_seconds / video.duration_seconds) * 100)) : undefined,
  progressSeconds: video.progress_seconds || undefined,
  isInWatchlist: video.is_in_watchlist ?? false,
  averageRating: video.average_rating ?? undefined,
  ratingCount: video.rating_count ?? 0,
  userRating: video.user_rating ?? undefined,
  playbackUrl: video.playback_url ?? null,
  status: video.status as ContentCard['status'],
  director: video.director,
  castMembers: video.cast_members,
})

export type DownloadItem = { id: string; createdAt: string; video: ContentCard }
type ApiDownload = { id: string; created_at: string; video: ApiVideo }

const mapDownload = (d: ApiDownload): DownloadItem => ({ id: d.id, createdAt: d.created_at, video: mapVideo(d.video) })

export type HistoryEntry = { video: ContentCard; progressSeconds: number; durationSeconds?: number; updatedAt: string }
type ApiHistoryEntry = { video: ApiVideo; progress_seconds: number; duration_seconds?: number; updated_at: string }

const mapHistory = (h: ApiHistoryEntry): HistoryEntry => ({ video: mapVideo(h.video), progressSeconds: h.progress_seconds, durationSeconds: h.duration_seconds, updatedAt: h.updated_at })

export const accountApi = {
  async getPreferences(): Promise<Preferences> {
    return mapPreferences(await get<ApiPreferences>('/account/preferences'))
  },
  async updatePreferences(prefs: Preferences): Promise<Preferences> {
    const payload = { autoplay: prefs.autoplay, autoplay_previews: prefs.autoplayPreviews, data_saver: prefs.dataSaver, email_notifications: prefs.emailNotifications }
    return mapPreferences(await send<ApiPreferences>('/account/preferences', 'PUT', payload))
  },

  async getSubscription(): Promise<Subscription> {
    return mapSubscription(await get<ApiSubscription>('/account/subscription'))
  },
  async setSubscription(plan: Plan): Promise<Subscription> {
    return mapSubscription(await send<ApiSubscription>('/account/subscription', 'PUT', { plan }))
  },

  async getNotifications(): Promise<Notification[]> {
    return (await get<ApiNotification[]>('/account/notifications')).map(mapNotification)
  },
  async markNotificationRead(id: string): Promise<void> {
    await send(`/account/notifications/${id}/read`, 'POST')
  },
  async markAllNotificationsRead(): Promise<void> {
    await send('/account/notifications/read-all', 'POST')
  },
  async deleteNotification(id: string): Promise<void> {
    await del(`/account/notifications/${id}`)
  },

  async getDownloads(): Promise<DownloadItem[]> {
    return (await get<ApiDownload[]>('/account/downloads')).map(mapDownload)
  },
  async addDownload(videoId: string): Promise<DownloadItem> {
    return mapDownload(await send<ApiDownload>('/account/downloads', 'POST', { video_id: videoId }))
  },
  async removeDownload(videoId: string): Promise<void> {
    await del(`/account/downloads/${videoId}`)
  },

  async getHistory(): Promise<HistoryEntry[]> {
    return (await get<ApiHistoryEntry[]>('/account/history')).map(mapHistory)
  },
  async removeHistoryEntry(videoId: string): Promise<void> {
    await del(`/account/history/${videoId}`)
  },
  async clearHistory(): Promise<void> {
    await del('/account/history')
  },
}
