const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:8000'

const headers = (): Record<string, string> => {
  const token = localStorage.getItem('access_token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

async function errorMessage(response: Response) {
  const body = (await response.json().catch(() => null)) as { detail?: string } | null
  return body?.detail ?? `Request failed (${response.status})`
}

async function handle<T>(response: Response): Promise<T> {
  if (!response.ok) throw new Error(await errorMessage(response))
  if (response.status === 204) return undefined as T
  return response.json() as Promise<T>
}

const get = async <T,>(path: string): Promise<T> => handle<T>(await fetch(`${API_BASE}${path}`, { headers: headers() }))
const send = async <T,>(path: string, method: string, body?: unknown): Promise<T> =>
  handle<T>(
    await fetch(`${API_BASE}${path}`, {
      method,
      headers: { ...headers(), 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    }),
  )
const del = async <T,>(path: string): Promise<T> => handle<T>(await fetch(`${API_BASE}${path}`, { method: 'DELETE', headers: headers() }))

// ---- Users ----

export type AdminUser = {
  id: string
  email: string
  isAdmin: boolean
  isActive: boolean
  plan: 'essential' | 'premium' | 'ultimate'
  canStream: boolean
  streamRequestedAt?: string
  createdAt: string
  lastActiveAt?: string
  titlesUploaded: number
}
type ApiAdminUser = {
  id: string
  email: string
  is_admin: boolean
  is_active: boolean
  plan: 'essential' | 'premium' | 'ultimate'
  can_stream: boolean
  stream_requested_at?: string
  created_at: string
  last_active_at?: string
  titles_uploaded: number
}

const mapUser = (u: ApiAdminUser): AdminUser => ({
  id: u.id,
  email: u.email,
  isAdmin: u.is_admin,
  isActive: u.is_active,
  plan: u.plan,
  canStream: u.can_stream,
  streamRequestedAt: u.stream_requested_at,
  createdAt: u.created_at,
  lastActiveAt: u.last_active_at,
  titlesUploaded: u.titles_uploaded,
})

// ---- Categories ----

export type Category = { id: string; name: string; isPublic: boolean; updatedAt: string; titleCount: number }
type ApiCategory = { id: string; name: string; is_public: boolean; updated_at: string; title_count: number }

const mapCategory = (c: ApiCategory): Category => ({ id: c.id, name: c.name, isPublic: c.is_public, updatedAt: c.updated_at, titleCount: c.title_count })

// ---- Reports ----

export type Report = {
  id: string
  subject: string
  message?: string
  status: 'open' | 'in_review' | 'resolved'
  createdAt: string
  resolvedAt?: string
  videoId?: string
  videoTitle?: string
  reporterEmail?: string
}
type ApiReport = {
  id: string
  subject: string
  message?: string
  status: 'open' | 'in_review' | 'resolved'
  created_at: string
  resolved_at?: string
  video_id?: string
  video_title?: string
  reporter_email?: string
}

const mapReport = (r: ApiReport): Report => ({
  id: r.id,
  subject: r.subject,
  message: r.message,
  status: r.status,
  createdAt: r.created_at,
  resolvedAt: r.resolved_at,
  videoId: r.video_id,
  videoTitle: r.video_title,
  reporterEmail: r.reporter_email,
})

export const adminApi = {
  async listUsers(): Promise<AdminUser[]> {
    return (await get<ApiAdminUser[]>('/admin/users')).map(mapUser)
  },
  async updateUser(
    id: string,
    patch: { isAdmin?: boolean; isActive?: boolean; plan?: AdminUser['plan']; canStream?: boolean },
  ): Promise<AdminUser> {
    const body = { is_admin: patch.isAdmin, is_active: patch.isActive, plan: patch.plan, can_stream: patch.canStream }
    return mapUser(await send<ApiAdminUser>(`/admin/users/${id}`, 'PATCH', body))
  },
  async deleteUser(id: string): Promise<void> {
    await del(`/admin/users/${id}`)
  },

  async listCategories(): Promise<Category[]> {
    return (await get<ApiCategory[]>('/admin/categories')).map(mapCategory)
  },
  async createCategory(name: string, isPublic = true): Promise<Category> {
    return mapCategory(await send<ApiCategory>('/admin/categories', 'POST', { name, is_public: isPublic }))
  },
  async updateCategory(id: string, patch: { name?: string; isPublic?: boolean }): Promise<Category> {
    return mapCategory(await send<ApiCategory>(`/admin/categories/${id}`, 'PATCH', { name: patch.name, is_public: patch.isPublic }))
  },
  async deleteCategory(id: string): Promise<void> {
    await del(`/admin/categories/${id}`)
  },

  async listReports(): Promise<Report[]> {
    return (await get<ApiReport[]>('/admin/reports')).map(mapReport)
  },
  async updateReportStatus(id: string, status: Report['status']): Promise<Report> {
    return mapReport(await send<ApiReport>(`/admin/reports/${id}`, 'PATCH', { status }))
  },
}
