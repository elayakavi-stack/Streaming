const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:8000'

export type CurrentUser = {
  id: string
  email: string
  isAdmin: boolean
  canStream: boolean
  streamRequestedAt?: string
}

async function errorMessage(response: Response) {
  const body = (await response.json().catch(() => null)) as { detail?: string } | null
  return body?.detail ?? 'Request failed'
}

export const authApi = {
  token: () => localStorage.getItem('access_token'),
  isSignedIn: () => Boolean(localStorage.getItem('access_token')),
  logout: () => localStorage.removeItem('access_token'),

  async register(email: string, password: string) {
    const response = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    })
    if (!response.ok) throw new Error(await errorMessage(response))
  },

  async login(email: string, password: string) {
    const body = new URLSearchParams({ username: email, password })
    const response = await fetch(`${API_BASE}/auth/login`, { method: 'POST', body })
    if (!response.ok) throw new Error(await errorMessage(response))
    const data = (await response.json()) as { access_token: string }
    localStorage.setItem('access_token', data.access_token)
  },

  async me(): Promise<CurrentUser> {
    const token = localStorage.getItem('access_token')
    const response = await fetch(`${API_BASE}/auth/me`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
    if (!response.ok) {
      if (response.status === 401) localStorage.removeItem('access_token')
      throw new Error(await errorMessage(response))
    }
    const data = (await response.json()) as {
      id: string
      email: string
      is_admin: boolean
      can_stream: boolean
      stream_requested_at?: string
    }
    return {
      id: data.id,
      email: data.email,
      isAdmin: data.is_admin,
      canStream: data.can_stream,
      streamRequestedAt: data.stream_requested_at ?? undefined,
    }
  },
}
