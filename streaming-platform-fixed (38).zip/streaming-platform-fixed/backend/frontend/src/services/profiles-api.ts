const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:8000'

export type Profile = { id: string; name: string; avatarUrl?: string; isKids: boolean; maturityRating: string }
type ApiProfile = { id: string; name: string; avatar_url?: string; is_kids: boolean; maturity_rating: string }

const headers = (): Record<string, string> => {
  const token = localStorage.getItem('access_token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

async function errorMessage(response: Response) {
  const body = (await response.json().catch(() => null)) as { detail?: string } | null
  return body?.detail ?? `Request failed (${response.status})`
}

const mapProfile = (profile: ApiProfile): Profile => ({
  id: profile.id,
  name: profile.name,
  avatarUrl: profile.avatar_url,
  isKids: profile.is_kids,
  maturityRating: profile.maturity_rating,
})

export const profilesApi = {
  async list(): Promise<Profile[]> {
    const response = await fetch(`${API_BASE}/profiles`, { headers: headers() })
    if (!response.ok) throw new Error(await errorMessage(response))
    const data = (await response.json()) as ApiProfile[]
    return data.map(mapProfile)
  },

  async create(input: { name: string; isKids?: boolean; maturityRating?: string; avatarUrl?: string }): Promise<Profile> {
    const response = await fetch(`${API_BASE}/profiles`, {
      method: 'POST',
      headers: { ...headers(), 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: input.name,
        is_kids: input.isKids ?? false,
        maturity_rating: input.maturityRating ?? 'A',
        avatar_url: input.avatarUrl,
      }),
    })
    if (!response.ok) throw new Error(await errorMessage(response))
    return mapProfile((await response.json()) as ApiProfile)
  },

  async remove(id: string): Promise<void> {
    const response = await fetch(`${API_BASE}/profiles/${id}`, { method: 'DELETE', headers: headers() })
    if (!response.ok && response.status !== 204) throw new Error(await errorMessage(response))
  },
}
