const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:8000'

export type LiveStatus = 'idle' | 'live' | 'ended'

export type LiveStream = {
  id: string
  title: string
  description?: string
  posterUrl?: string
  posterIsManual: boolean
  status: LiveStatus
  hlsUrl: string
  dashUrl?: string
  ownerEmail?: string
  createdAt: string
  startedAt?: string
  endedAt?: string
}

type ApiLiveStream = {
  id: string
  title: string
  description?: string | null
  poster_url?: string | null
  poster_is_manual?: boolean
  status: LiveStatus
  hls_url: string
  dash_url?: string | null
  owner_email?: string | null
  created_at: string
  started_at?: string | null
  ended_at?: string | null
}

const headers = (): Record<string, string> => {
  const token = localStorage.getItem('access_token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

export type StreamAccessStatus = { canStream: boolean; streamRequestedAt?: string }
type ApiStreamAccessStatus = { can_stream: boolean; stream_requested_at?: string | null }

const mapAccessStatus = (s: ApiStreamAccessStatus): StreamAccessStatus => ({
  canStream: s.can_stream,
  streamRequestedAt: s.stream_requested_at ?? undefined,
})

const mapStream = (s: ApiLiveStream): LiveStream => ({
  id: s.id,
  title: s.title,
  description: s.description ?? undefined,
  posterUrl: s.poster_url ?? undefined,
  posterIsManual: s.poster_is_manual ?? false,
  status: s.status,
  hlsUrl: s.hls_url,
  dashUrl: s.dash_url ?? undefined,
  ownerEmail: s.owner_email ?? undefined,
  createdAt: s.created_at,
  startedAt: s.started_at ?? undefined,
  endedAt: s.ended_at ?? undefined,
})

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const error = (await response.json().catch(() => null)) as { detail?: string } | null
    throw new Error(error?.detail ?? `API request failed (${response.status})`)
  }
  return response.json() as Promise<T>
}

const request = async <T,>(path: string): Promise<T> => {
  const response = await fetch(`${API_BASE}${path}`, { headers: headers() })
  return handleResponse<T>(response)
}

const requestJson = async <T,>(path: string, method: string, body?: unknown): Promise<T> => {
  const response = await fetch(`${API_BASE}${path}`, {
    method,
    headers: { ...headers(), 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  return handleResponse<T>(response)
}

export const liveApi = {
  /** Currently-live broadcasts, for the "Live now" rail. */
  async listLive(): Promise<LiveStream[]> {
    const items = await request<ApiLiveStream[]>('/live')
    return items.map(mapStream)
  },

  /** The signed-in admin's own recent broadcasts (idle/live/ended). */
  async mine(): Promise<LiveStream[]> {
    const items = await request<ApiLiveStream[]>('/live/mine')
    return items.map(mapStream)
  },

  async getById(id: string): Promise<LiveStream> {
    return mapStream(await request<ApiLiveStream>(`/live/${id}`))
  },

  async create(input: { title: string; description?: string; posterUrl?: string }): Promise<LiveStream> {
    return mapStream(
      await requestJson<ApiLiveStream>('/live', 'POST', {
        title: input.title,
        description: input.description,
        poster_url: input.posterUrl,
      }),
    )
  },

  /** The RTMP server address, WHIP endpoint (for in-browser broadcasting), and private stream key. */
  async getIngest(id: string): Promise<{ id: string; rtmpUrl: string; whipUrl: string; streamKey: string }> {
    const result = await request<{ id: string; rtmp_url: string; whip_url: string; stream_key: string }>(`/live/${id}/ingest`)
    return { id: result.id, rtmpUrl: result.rtmp_url, whipUrl: result.whip_url, streamKey: result.stream_key }
  },

  async start(id: string): Promise<LiveStream> {
    return mapStream(await requestJson<ApiLiveStream>(`/live/${id}/start`, 'POST'))
  },

  async end(id: string): Promise<LiveStream> {
    return mapStream(await requestJson<ApiLiveStream>(`/live/${id}/end`, 'POST'))
  },

  /** Uploads an image straight to S3 via a presigned URL, then returns the
   * public asset URL to pass to setThumbnail. Mirrors the admin artwork
   * upload flow, but open to any approved streamer. */
  async uploadThumbnail(file: File): Promise<string> {
    const signed = await requestJson<{ upload_url: string; asset_url: string }>('/live/assets/presign', 'POST', {
      filename: file.name,
      content_type: file.type,
    })
    const uploaded = await fetch(signed.upload_url, { method: 'PUT', headers: { 'Content-Type': file.type }, body: file })
    if (!uploaded.ok) throw new Error('Thumbnail upload to S3 failed')
    return signed.asset_url
  },

  /** Sets (or replaces) a broadcast's thumbnail by hand — works before,
   * during, or after the stream, and stops the auto-capture job from
   * touching this broadcast's poster going forward. */
  async setThumbnail(id: string, posterUrl: string): Promise<LiveStream> {
    return mapStream(await requestJson<ApiLiveStream>(`/live/${id}/thumbnail`, 'PATCH', { poster_url: posterUrl }))
  },

  /** Whether the signed-in user is allowed to go live yet, and whether a
   * request is already pending admin approval. */
  async accessStatus(): Promise<StreamAccessStatus> {
    return mapAccessStatus(await request<ApiStreamAccessStatus>('/live/access/status'))
  },

  /** Ask an admin to approve this account for live streaming. */
  async requestAccess(): Promise<StreamAccessStatus> {
    return mapAccessStatus(await requestJson<ApiStreamAccessStatus>('/live/access/request', 'POST'))
  },
}
