import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { adminApi, type AdminUser, type Category, type Report } from '@/services/admin-api'

export const adminKeys = {
  users: ['admin', 'users'] as const,
  categories: ['admin', 'categories'] as const,
  reports: ['admin', 'reports'] as const,
}

export const useAdminUsers = () => useQuery({ queryKey: adminKeys.users, queryFn: adminApi.listUsers })

export const useUpdateAdminUser = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Parameters<typeof adminApi.updateUser>[1] }) => adminApi.updateUser(id, patch),
    onSuccess: (updated) => {
      queryClient.setQueryData<AdminUser[]>(adminKeys.users, (prev) => prev?.map((u) => (u.id === updated.id ? updated : u)))
    },
  })
}

export const useDeleteAdminUser = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => adminApi.deleteUser(id),
    onSuccess: (_result, id) => {
      queryClient.setQueryData<AdminUser[]>(adminKeys.users, (prev) => prev?.filter((u) => u.id !== id))
    },
  })
}

export const useAdminCategories = () => useQuery({ queryKey: adminKeys.categories, queryFn: adminApi.listCategories })

export const useCreateCategory = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ name, isPublic }: { name: string; isPublic?: boolean }) => adminApi.createCategory(name, isPublic),
    onSuccess: (created) => {
      queryClient.setQueryData<Category[]>(adminKeys.categories, (prev) => [created, ...(prev ?? [])])
    },
  })
}

export const useUpdateCategory = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Parameters<typeof adminApi.updateCategory>[1] }) => adminApi.updateCategory(id, patch),
    onSuccess: (updated) => {
      queryClient.setQueryData<Category[]>(adminKeys.categories, (prev) => prev?.map((c) => (c.id === updated.id ? updated : c)))
    },
  })
}

export const useDeleteCategory = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => adminApi.deleteCategory(id),
    onSuccess: (_result, id) => {
      queryClient.setQueryData<Category[]>(adminKeys.categories, (prev) => prev?.filter((c) => c.id !== id))
    },
  })
}

export const useAdminReports = () => useQuery({ queryKey: adminKeys.reports, queryFn: adminApi.listReports })

export const useUpdateReportStatus = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, status }: { id: string; status: Report['status'] }) => adminApi.updateReportStatus(id, status),
    onSuccess: (updated) => {
      queryClient.setQueryData<Report[]>(adminKeys.reports, (prev) => prev?.map((r) => (r.id === updated.id ? updated : r)))
    },
  })
}
