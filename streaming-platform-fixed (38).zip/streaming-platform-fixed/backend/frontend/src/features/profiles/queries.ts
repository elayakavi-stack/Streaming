import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { profilesApi } from '@/services/profiles-api'

export const profileKeys = { all: ['profiles'] as const }

export const useProfiles = () => useQuery({ queryKey: profileKeys.all, queryFn: profilesApi.list })

export const useCreateProfile = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: profilesApi.create,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: profileKeys.all }),
  })
}

export const useDeleteProfile = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: profilesApi.remove,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: profileKeys.all }),
  })
}
