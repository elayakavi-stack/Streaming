import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { authApi } from '@/services/auth-api'
import { accountApi, type Plan, type Preferences } from '@/services/account-api'

export const useCurrentUser = () =>
  useQuery({
    queryKey: ['account', 'me'],
    queryFn: authApi.me,
    enabled: authApi.isSignedIn(),
    retry: false,
  })

export const accountKeys = {
  preferences: ['account', 'preferences'] as const,
  subscription: ['account', 'subscription'] as const,
  notifications: ['account', 'notifications'] as const,
  downloads: ['account', 'downloads'] as const,
  history: ['account', 'history'] as const,
}

export const usePreferences = () => useQuery({ queryKey: accountKeys.preferences, queryFn: accountApi.getPreferences })

export const useUpdatePreferences = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (prefs: Preferences) => accountApi.updatePreferences(prefs),
    onSuccess: (data) => queryClient.setQueryData(accountKeys.preferences, data),
  })
}

export const useSubscription = () => useQuery({ queryKey: accountKeys.subscription, queryFn: accountApi.getSubscription })

export const useSetSubscription = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (plan: Plan) => accountApi.setSubscription(plan),
    onSuccess: (data) => queryClient.setQueryData(accountKeys.subscription, data),
  })
}

export const useNotifications = (options: { enabled?: boolean } = {}) => useQuery({ queryKey: accountKeys.notifications, queryFn: accountApi.getNotifications, enabled: options.enabled ?? true })

export const useMarkNotificationRead = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => accountApi.markNotificationRead(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: accountKeys.notifications }),
  })
}

export const useMarkAllNotificationsRead = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: () => accountApi.markAllNotificationsRead(),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: accountKeys.notifications }),
  })
}

export const useDeleteNotification = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => accountApi.deleteNotification(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: accountKeys.notifications }),
  })
}

export const useDownloads = () => useQuery({ queryKey: accountKeys.downloads, queryFn: accountApi.getDownloads })

export const useAddDownload = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (videoId: string) => accountApi.addDownload(videoId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: accountKeys.downloads }),
  })
}

export const useRemoveDownload = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (videoId: string) => accountApi.removeDownload(videoId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: accountKeys.downloads }),
  })
}

export const useWatchHistory = () => useQuery({ queryKey: accountKeys.history, queryFn: accountApi.getHistory })

export const useRemoveHistoryEntry = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (videoId: string) => accountApi.removeHistoryEntry(videoId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: accountKeys.history }),
  })
}

export const useClearHistory = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: () => accountApi.clearHistory(),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: accountKeys.history }),
  })
}
