import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { contentApi } from '@/services/content-api'

export const discoveryKeys = {
  home: ['discovery', 'home'] as const,
  search: (query: string) => ['discovery', 'search', query] as const,
  catalog: (params: { category?: string; genre?: string; year?: number; newReleaseDays?: number; pageSize?: number }) => ['discovery', 'catalog', params] as const,
  watchlist: ['discovery', 'watchlist'] as const,
  continueWatching: ['discovery', 'continue-watching'] as const,
  details: (id: string) => ['content', id] as const,
}

export const useHomeDiscovery = () => useQuery({ queryKey: discoveryKeys.home, queryFn: contentApi.getHome })
export const useRecommendations = () => useQuery({ queryKey: ['discovery', 'recommendations'], queryFn: contentApi.getRecommendations })
export const useGenres = () => useQuery({ queryKey: ['discovery', 'genres'], queryFn: contentApi.getGenres, staleTime: 5 * 60_000 })
export const useContentSearch = (query: string) => useQuery({ queryKey: discoveryKeys.search(query), queryFn: () => contentApi.search(query) })
export const useContentDetails = (id: string) =>
  useQuery({
    queryKey: discoveryKeys.details(id),
    queryFn: () => contentApi.getById(id),
    enabled: Boolean(id),
    // While a title is mid-(re)processing there's otherwise no signal that
    // tells the page to look again — the viewer would have to guess when
    // it's done and manually reload. Poll every few seconds only in that
    // window so "still processing" resolves into a playable state (with
    // its fresh, cache-busted playback_url) on its own.
    refetchInterval: (query) => (query.state.data?.status === 'processing' ? 4000 : false),
  })
export const useContentCatalog = (params: { category?: string; genre?: string; year?: number; newReleaseDays?: number; pageSize?: number } = {}) =>
  useQuery({ queryKey: discoveryKeys.catalog(params), queryFn: () => contentApi.getCatalog(params) })
export const useWatchlist = () => useQuery({ queryKey: discoveryKeys.watchlist, queryFn: contentApi.getWatchlist })
export const useContinueWatching = () => useQuery({ queryKey: discoveryKeys.continueWatching, queryFn: contentApi.getContinueWatching })
/** "More like this mood" rail for the player page. Separate query key from
 * `details` since it's keyed on the video currently playing but returns a
 * *list* of other titles, not the title's own details. */
export const useSimilarMood = (id: string) =>
  useQuery({ queryKey: ['discovery', 'similar-mood', id], queryFn: () => contentApi.getSimilarMood(id), enabled: Boolean(id) })
/** "Because you watched X" rail for the player page — same-cast /
 * same-director picks for the video currently playing. Separate query key
 * from `similar-mood` since it's a distinct rail with a distinct ranking. */
export const useBecauseYouWatched = (id: string) =>
  useQuery({ queryKey: ['discovery', 'because-you-watched', id], queryFn: () => contentApi.getBecauseYouWatched(id), enabled: Boolean(id) })

export const useToggleWatchlist = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => contentApi.toggleWatchlist(id),
    onSuccess: (_result, id) => {
      queryClient.invalidateQueries({ queryKey: discoveryKeys.details(id) })
      queryClient.invalidateQueries({ queryKey: discoveryKeys.watchlist })
      queryClient.invalidateQueries({ queryKey: discoveryKeys.home })
    },
  })
}

export const useRateVideo = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, value, review }: { id: string; value: number; review?: string }) => contentApi.rateVideo(id, value, review),
    onSuccess: (_result, { id }) => {
      queryClient.invalidateQueries({ queryKey: discoveryKeys.details(id) })
    },
  })
}

export const useAddSubtitle = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ videoId, language, label, isDefault, file }: { videoId: string; language: string; label: string; isDefault?: boolean; file: File }) =>
      contentApi.addSubtitle(videoId, { language, label, isDefault, file }),
    onSuccess: () => {
      // Subtitles surface in the catalog, the title page, and the player,
      // so invalidate broadly rather than just this one video's details.
      queryClient.invalidateQueries({ queryKey: ['discovery'] })
    },
  })
}

export const useRemoveSubtitle = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ videoId, subtitleId }: { videoId: string; subtitleId: string }) => contentApi.removeSubtitle(videoId, subtitleId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['discovery'] })
    },
  })
}

/** Attaches a dub/audio-track file to a title that's already been
 * uploaded. For a `ready` or `failed` title, the backend also queues a
 * reprocess so the track actually lands in the streaming files rather
 * than sitting unused (see contentApi.addAudioTrack). Rejected with a 409
 * if the title is mid-transcode already. */
export const useAddAudioTrack = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ videoId, language, label, isDefault, file }: { videoId: string; language: string; label: string; isDefault?: boolean; file: File }) =>
      contentApi.addAudioTrack(videoId, { language, label, isDefault, file }),
    onSuccess: () => {
      // A reprocess may have just been queued server-side, which flips the
      // title's status to "processing" — invalidate broadly so the
      // catalog/admin views pick that up rather than showing stale status.
      queryClient.invalidateQueries({ queryKey: ['discovery'] })
    },
  })
}

export const useRemoveAudioTrack = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ videoId, audioSourceId }: { videoId: string; audioSourceId: string }) => contentApi.removeAudioTrack(videoId, audioSourceId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['discovery'] })
    },
  })
}
