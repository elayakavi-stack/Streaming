import { create } from 'zustand'

/** Publishes this device's camera/mic to MediaMTX over WHIP (WebRTC-HTTP
 * Ingestion Protocol) — the browser side of "go live from this device".
 *
 * This lives in a Zustand store (rather than component state/useRef, as a
 * plain hook would) *on purpose*: the Go Live page is one Route among many,
 * so it unmounts the instant the person taps to another tab in the app —
 * News, Home, their profile, wherever. If the RTCPeerConnection and camera
 * MediaStream lived inside that page's component tree, navigating away
 * would strand them with nothing left to keep them alive (and the next
 * visit to Go Live would spin up a second, competing WHIP session). Putting
 * them here instead means they're owned by the module, not any particular
 * screen, so the broadcast keeps running no matter where the person
 * browses to — it only ends when they explicitly end it, the stream is
 * kicked/expires server-side, or the tab/app actually closes (which is also
 * the only time a getUserMedia + RTCPeerConnection pair can't help but end).
 *
 * RTMP (what OBS/ffmpeg use) needs a raw TCP socket, which browsers can't
 * open, so in-browser broadcasting instead uses WebRTC: capture the camera
 * with getUserMedia, build an SDP offer, POST it to MediaMTX's WHIP
 * endpoint (<whipUrl>, e.g. http://localhost:8889/live/<key>/whip), and set
 * the SDP answer MediaMTX sends back as the connection's remote
 * description. MediaMTX treats this exactly like any other publisher on
 * that path, so the existing runOnReady/runOnNotReady hooks in
 * routers/live.py fire the same way they do for RTMP.
 */

export type WhipBroadcastState = 'idle' | 'starting' | 'live' | 'error'

// Not part of the Zustand state on purpose — these are imperative handles,
// not data to diff/re-render on, and only ever touched from start()/stop().
let pc: RTCPeerConnection | null = null
let media: MediaStream | null = null
let resourceUrl: string | null = null

function warnBeforeUnload(e: BeforeUnloadEvent) {
  // The one case this store genuinely can't survive: the tab/app actually
  // closing (or a full page reload) kills getUserMedia + the RTCPeerConnection
  // outright, so give the person a chance to back out of that.
  e.preventDefault()
  e.returnValue = ''
}

/** Reorders a transceiver's codec preferences so `mimeType` is tried first,
 * falling back to whatever the browser would otherwise have chosen if that
 * codec isn't actually available. Safe no-op in browsers/environments
 * without setCodecPreferences support. */
function preferCodec(transceiver: RTCRtpTransceiver, kind: 'video' | 'audio', mimeType: string) {
  if (!('setCodecPreferences' in transceiver)) return
  const capabilities = RTCRtpSender.getCapabilities(kind)
  if (!capabilities) return
  const preferred = capabilities.codecs.filter((codec) => codec.mimeType.toLowerCase() === mimeType)
  if (!preferred.length) return
  const rest = capabilities.codecs.filter((codec) => codec.mimeType.toLowerCase() !== mimeType)
  transceiver.setCodecPreferences([...preferred, ...rest])
}

type BroadcastStore = {
  cameraState: WhipBroadcastState
  cameraError: string | null
  previewStream: MediaStream | null
  startCamera: (whipUrl: string) => Promise<void>
  stopCamera: () => Promise<void>
}

export const useBroadcastStore = create<BroadcastStore>((set, get) => ({
  cameraState: 'idle',
  cameraError: null,
  previewStream: null,

  startCamera: async (whipUrl: string) => {
    set({ cameraError: null, cameraState: 'starting' })
    try {
      media = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: true,
      })
      set({ previewStream: media })

      pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] })
      // Explicit transceivers (not addTrack) so we can set codec
      // preferences below. This matters because MediaMTX's HLS output only
      // remuxes H264 video — if the browser's WebRTC offer leads with
      // VP8/VP9 (a common default depending on hardware encoder support),
      // MediaMTX still accepts the WHIP connection and reports the stream
      // as live/connected, but the HLS output ends up with no usable video
      // (and often no audio either, since the whole publish is treated as
      // unusable) — "live" in the dashboard, blank and silent for viewers.
      // Forcing H264 (and Opus for audio, which MediaMTX's fMP4 low-latency
      // HLS variant does support) up front avoids that silently-broken
      // state entirely.
      const videoTrack = media.getVideoTracks()[0]
      const audioTrack = media.getAudioTracks()[0]

      if (videoTrack) {
        const videoTransceiver = pc.addTransceiver(videoTrack, { direction: 'sendonly' })
        preferCodec(videoTransceiver, 'video', 'video/h264')
      }
      if (audioTrack) {
        const audioTransceiver = pc.addTransceiver(audioTrack, { direction: 'sendonly' })
        preferCodec(audioTransceiver, 'audio', 'audio/opus')
      }

      const offer = await pc.createOffer()
      await pc.setLocalDescription(offer)

      const response = await fetch(whipUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/sdp' },
        body: offer.sdp,
      })
      if (!response.ok) {
        throw new Error(`MediaMTX rejected the connection (${response.status})`)
      }
      const location = response.headers.get('Location')
      resourceUrl = location ? new URL(location, whipUrl).toString() : null

      const answerSdp = await response.text()
      await pc.setRemoteDescription({ type: 'answer', sdp: answerSdp })

      pc.onconnectionstatechange = () => {
        if (pc && (pc.connectionState === 'failed' || pc.connectionState === 'disconnected')) {
          set({ cameraState: 'error', cameraError: 'Connection to the streaming server was lost.' })
          window.removeEventListener('beforeunload', warnBeforeUnload)
        }
      }

      window.addEventListener('beforeunload', warnBeforeUnload)
      set({ cameraState: 'live' })
    } catch (reason) {
      await get().stopCamera()
      set({
        cameraState: 'error',
        cameraError:
          reason instanceof DOMException && reason.name === 'NotAllowedError'
            ? 'Camera/microphone access was denied. Allow access and try again.'
            : reason instanceof Error
              ? reason.message
              : 'Could not start broadcasting from this device.',
      })
    }
  },

  stopCamera: async () => {
    window.removeEventListener('beforeunload', warnBeforeUnload)
    // Best-effort WHIP teardown so MediaMTX drops the publisher immediately
    // instead of waiting on an ICE timeout — if this fails, ending the
    // broadcast server-side (kick_stream in rtmp_stream.py) still cleans it
    // up, so it's safe to ignore errors here.
    if (resourceUrl) {
      try {
        await fetch(resourceUrl, { method: 'DELETE' })
      } catch {
        // ignored — see comment above
      }
      resourceUrl = null
    }
    pc?.close()
    pc = null
    media?.getTracks().forEach((track) => track.stop())
    media = null
    set({ previewStream: null, cameraState: 'idle', cameraError: null })
  },
}))
