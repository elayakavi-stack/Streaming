import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { liveApi } from '@/services/live-api'

export const liveKeys = {
  now: ['live', 'now'] as const,
  mine: ['live', 'mine'] as const,
  details: (id: string) => ['live', id] as const,
  access: ['live', 'access'] as const,
}

/** Whether the signed-in user is approved to go live yet. */
export const useStreamAccess = () => useQuery({ queryKey: liveKeys.access, queryFn: liveApi.accessStatus })

export const useRequestStreamAccess = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: liveApi.requestAccess,
    onSuccess: (status) => queryClient.setQueryData(liveKeys.access, status),
  })
}

/** Polls so the home page's "Live now" rail picks up new/ended broadcasts without a refresh. */
export const useLiveNow = (options: { enabled?: boolean } = {}) =>
  useQuery({
    queryKey: liveKeys.now,
    queryFn: liveApi.listLive,
    refetchInterval: 30_000,
    enabled: options.enabled ?? true,
  })

export const useMyLiveStreams = () => useQuery({ queryKey: liveKeys.mine, queryFn: liveApi.mine })

export const useLiveStream = (id: string, options: { poll?: boolean } = {}) =>
  useQuery({
    queryKey: liveKeys.details(id),
    queryFn: () => liveApi.getById(id),
    enabled: Boolean(id),
    refetchInterval: options.poll ? 10_000 : false,
  })

/** Fetches the RTMP server URL + stream key for a broadcast — only ever
 * called by the stream's owner, right after creating it, to fill in OBS. */
export const useLiveIngest = (id: string | null) =>
  useQuery({
    queryKey: id ? ['live', id, 'ingest'] : ['live', 'ingest', 'disabled'],
    queryFn: () => liveApi.getIngest(id as string),
    enabled: Boolean(id),
    staleTime: Infinity,
  })

export const useCreateLiveStream = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: liveApi.create,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: liveKeys.mine }),
  })
}

export const useStartLiveStream = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => liveApi.start(id),
    onSuccess: (_result, id) => {
      queryClient.invalidateQueries({ queryKey: liveKeys.details(id) })
      queryClient.invalidateQueries({ queryKey: liveKeys.now })
      queryClient.invalidateQueries({ queryKey: liveKeys.mine })
    },
  })
}

export const useEndLiveStream = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => liveApi.end(id),
    onSuccess: (_result, id) => {
      queryClient.invalidateQueries({ queryKey: liveKeys.details(id) })
      queryClient.invalidateQueries({ queryKey: liveKeys.now })
      queryClient.invalidateQueries({ queryKey: liveKeys.mine })
    },
  })
}

/** Uploads a file straight to S3, then sets it as the broadcast's
 * thumbnail — works whether the broadcast is still being set up, waiting
 * to connect, or already live. */
export const useSetLiveThumbnail = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: async ({ id, file }: { id: string; file: File }) => {
      const assetUrl = await liveApi.uploadThumbnail(file)
      return liveApi.setThumbnail(id, assetUrl)
    },
    onSuccess: (_result, { id }) => {
      queryClient.invalidateQueries({ queryKey: liveKeys.details(id) })
      queryClient.invalidateQueries({ queryKey: liveKeys.now })
      queryClient.invalidateQueries({ queryKey: liveKeys.mine })
    },
  })
}
