import { FiCompass, FiFilm, FiHome, FiMonitor, FiStar, FiTv } from 'react-icons/fi'

export const primaryNavigation = [
  { label: 'Home', to: '/', icon: FiHome },
  { label: 'Browse', to: '/browse', icon: FiCompass },
  { label: 'Movies', to: '/movies', icon: FiFilm },
  { label: 'Series', to: '/series', icon: FiTv },
  { label: 'Live & Sports', to: '/sports', icon: FiMonitor },
  { label: 'My List', to: '/watchlist', icon: FiStar },
] as const
