// Suggestions only (via <datalist>) — any value can still be typed.
// Keeping names consistent here helps titles land in the right "X Movies"
// home-page rail instead of fragmenting into near-duplicate genres.
export const COMMON_GENRES = [
  'Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary',
  'Drama', 'Family', 'Fantasy', 'Horror', 'Musical', 'Mystery', 'Romance',
  'Sci-Fi', 'Sports', 'Thriller', 'War', 'Western',
]

// Fixed vocabulary (checkboxes, not free text) so mood-based
// recommendations — see app/recommendations.py — can group/rank titles
// instead of the tag set fragmenting into near-duplicates like "Uplifting"
// vs "Feel good" vs "Feels good". Deliberately not a genre list — a comedy
// and a horror movie can both be "Thought-provoking"; mood is a separate
// axis from genre/sub_genre, not a replacement for them.
export const COMMON_MOODS = [
  'Feel-good', 'Uplifting', 'Heartwarming', 'Comforting', 'Inspiring',
  'Nostalgic', 'Whimsical', 'Romantic', 'Hilarious', 'Witty',
  'Chill/Easy-watching', 'Tense/Thrilling', 'Suspenseful', 'Scary/Unsettling',
  'Dark/Intense', 'Bittersweet', 'Thought-provoking', 'Bingeable/Fast-paced',
]
