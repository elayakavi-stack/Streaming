# Streaming platform skeleton

React + FastAPI + PostgreSQL + Redis + S3 + CloudFront + FFmpeg. The platform runs
locally with SQLite and has a streaming-service catalog API, while its deployment
configuration supports PostgreSQL, Redis, S3, CloudFront, and a transcoding worker.

## What's here

```
backend/
  app/
    main.py            FastAPI entrypoint
    models.py           Account, profile, catalog, progress, and rating models
    routers/
      auth.py            register / login / current account (JWT)
      profiles.py         account viewing profiles
      videos.py           upload, catalog search, home rails, ratings, watchlist, resume
    worker/
      celery_app.py       Celery config (Redis as broker)
      tasks.py             the transcode_video task
      transcode.py         actual ffmpeg commands, S3 download/upload
    s3.py                 presigned upload URLs
    cdn.py                CloudFront signed playback URLs
  Dockerfile              API container
  Dockerfile.worker       worker container (includes ffmpeg binary)
frontend/
  src/
    api/client.js         fetch wrappers for every backend call
    components/
      UploadForm.jsx       drives presign -> S3 PUT -> complete-upload
      VideoPlayer.jsx       hls.js player
      VideoList.jsx
    pages/
      Home.jsx, Watch.jsx
docker-compose.yml        postgres + redis + api + worker
```

## Running it locally

1. Copy the env file and fill in AWS credentials:
   ```
   cp backend/.env.example backend/.env
   ```
2. Start Postgres, Redis, the API, and the worker:
   ```
   docker compose up --build
   ```
3. In a separate terminal, run the frontend:
   ```
   cd frontend
   npm install
   npm run dev
   ```
4. API is on `http://localhost:8000`, frontend on `http://localhost:5173`.

## AWS setup this code assumes (not automated here)

- **S3 bucket**: needs CORS enabled for browser PUT uploads from your frontend origin
  (allow `PUT`, `GET`, header `*`, origin `http://localhost:5173` for local dev).
- **CloudFront distribution**: origin pointed at the S3 bucket, with a **trusted key
  group** configured so it will honor signed URLs. You generate an RSA key pair,
  upload the public key to CloudFront, and keep the private key on the API server
  (referenced by `CLOUDFRONT_PRIVATE_KEY_PATH`).
- **IAM user/role** for the API and worker with least-privilege S3 access
  (`GetObject`, `PutObject` on the bucket, scoped by prefix if you want to separate
  raw uploads from transcoded output).

## Streaming API capabilities

- `GET /videos/home` returns ready-to-render rails: continue watching, new releases,
  and genre rails.
- `GET /videos/catalog?q=&category=&genre=&year=&page=&page_size=` provides paginated
  search and filters; `GET /videos/genres` returns available genres.
- `PUT /videos/{id}/rating` saves a viewer rating (1–5) and returns aggregate stats.
- `GET/POST/DELETE /profiles` manages up to six account viewing profiles.
- Upload completion, edits, and deletion are restricted to the title owner or an
  administrator. Local uploads use the development-only `PUT /local-upload/{key}`.

## Production work still required

- Alembic migrations (the app uses `create_all` for simplicity — swap this in before
  you touch a real database)
- S3 event notifications triggering the transcode job automatically (currently the
  client calls `/videos/{id}/complete-upload` after the PUT succeeds — fine for a v1,
  but an S3 → SNS/SQS → worker path is more reliable in production, since it doesn't
  depend on the client staying online)
- Payments/subscriptions, DRM and license-server integration, regional rights,
  parental-PIN enforcement, and production entitlement checks
- Rate limiting, refresh tokens, password reset, email verification, audit logs,
  secrets management, HTTPS, and CSRF protections

Each of these is a reasonable next slice to build out.
