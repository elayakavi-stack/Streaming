# What changed

## Backend (`backend/app/`)

- **`dependencies.py`** — `get_current_user` used to silently fall back to a
  shared "guest" account for any request with a missing/invalid token. That
  meant your login system wasn't actually enforced. It now returns `401` when
  there's no valid token, matching what the frontend's `RequireSignIn` gate
  and `Authorization` headers assume.
- **`dependencies.py` / `routers/videos.py`** — `user.is_admin != "true"` was
  comparing a boolean DB column to a string, so admin checks could never
  actually pass (`require_admin` always rejected; the owner-or-admin check on
  editing/deleting titles could never fall through to "admin"). Fixed to
  `not user.is_admin`.
- **`schemas.py`** — `UserOut.is_admin` was typed `str`, now `bool`, matching
  the model.
- **`schemas.py` / `routers/videos.py`** — `VideoOut` now includes
  `average_rating`, `rating_count`, `user_rating`, and `duration_seconds`
  (from watch history, or the video's own duration as a fallback) so the
  frontend can show real ratings and compute an accurate resume position.

## Frontend (`backend/frontend/src/`)

The app has two page sets; only the one wired into `App.tsx`'s router is
live. That live set used `services/content-api.ts` + `services/auth-api.ts`
for some things but had several pages using local mock state instead of the
backend even though the backend already supported them.

- **`services/content-api.ts`** — added `toggleWatchlist`, `rateVideo`,
  `saveProgress`, `getCatalog` (filtered), `getGenres`, `getWatchlist`,
  `getContinueWatching`, `deleteVideo`; `mapVideo` now carries watchlist
  state, ratings, playback URL, status, director/cast.
- **`services/auth-api.ts`** — added `me()` (`GET /auth/me`).
- **`services/profiles-api.ts`** (new) — `GET/POST/DELETE /profiles`.
- **`features/profiles/queries.ts`**, **`features/account/queries.ts`** (new)
  — React Query hooks for the above.
- **`features/discovery/queries.ts`** — added watchlist/rating mutations and
  a real catalog query hook.
- **`components/player/OttPlayer.tsx`** — was hardcoded to a sample trailer
  video with no real source prop. Now takes `src`/`poster`/`initialPosition`
  and streams the actual HLS `playback_url` via `hls.js` (already an
  installed dependency, just never wired in), with quality levels pulled
  from the real manifest.
- **`pages/PlayerPage.tsx`** — was fully hardcoded (fake episode list,
  ignored the `:id` param). Now loads the real title, handles
  processing/failed/no-playback states, and pings
  `PUT /videos/{id}/progress` periodically + on pause/end for resume.
- **`pages/TitleDetailsPage.tsx`**, **`components/content/PosterCard.tsx`**,
  **`components/content/CinematicHero.tsx`** — Play/Watch-later buttons were
  either inert or only updated local component state. Now call the real
  watchlist/rating mutations and reflect server state.
- **`pages/AccountPage.tsx`** / **`store/account-store.ts`** — profiles were
  two hardcoded fake people ("Ari", "Mila") in a Zustand store. Now backed by
  `GET/POST/DELETE /profiles`; the store only keeps which profile is
  "active" locally (the backend has no such concept).
- **`pages/AdminDashboardPage.tsx`** — stats were fabricated numbers
  (48,291 viewers etc.). Now computed from the real catalog.
- **`pages/AdminWorkspacePage.tsx`** — the "Movies & series" tab now lists
  real titles from `GET /videos/catalog` with working delete. The
  Users/Categories/Reports/Uploads tabs are left as labeled placeholders —
  see "Not connected" below.
- **`pages/CollectionPage.tsx`** — Movies/Series pages now filter through
  the real catalog API by category + genre; the Watchlist page shows your
  actual watchlist instead of the same static list re-filtered.
- **`vite-env.d.ts`** (new) — was missing, so `import.meta.env.VITE_API_BASE`
  didn't type-check.

Verified with `tsc --noEmit` (clean) after every change.

## Not connected to a backend (because there's no backend for it yet)

These would need new backend models/endpoints, not just wiring, so I left
them as clearly-labeled demo data rather than guessing at a design:

- `AdminWorkspacePage`: Users, Categories, Reports, Uploads-pipeline tabs.
- `SettingsPage`: playback/notification preferences aren't persisted.
- `UtilityPage`: downloads, notifications, subscription plans/billing.

If any of these matter to you, say which one and I'll design the backend
model + endpoints for it too.

## Recommendation rails — tightened to actually be "similar" (later change)

Three rails were recommending titles that weren't really related to what the
user was watching. Fixed each one independently:

- **`app/recommendations.py` — `similar_mood_videos`** (player page "More
  like this mood" rail): used to match on mood tags only. Now a candidate
  has to share a mood tag *or* a genre with the title playing to be
  considered at all, and is ranked by mood overlap first, genre overlap
  second, IMDb score as a final tiebreak.
- **`app/recommendations.py` — new `because_you_watched_videos`**, wired up
  behind a new **`GET /videos/{id}/because-you-watched`** endpoint (player
  page "More Like This" / "Because you watched X" rail): this rail used to
  be built client-side in `PlayerPage.tsx` from a plain same-genre catalog
  query, backfilled with the user's generic "Recommended for you" list when
  short — which is how unrelated titles (different genre, cast, everything)
  ended up in a "Because you watched Leo" rail. It's now server-side and
  ranks on shared director first, then shared cast members, only falling
  back to genre overlap when a title has no cast/director credits to match
  on — never on generic unrelated recommendations.
- **`app/recommendations.py` — `recommend_videos`** (home page "Recommended
  for you" rail): when there weren't enough genre-matched titles to fill
  the rail, it topped up with catalog-wide highest-rated titles regardless
  of genre. Removed that top-up — the rail is now allowed to be shorter
  than `limit` rather than padded with unrelated titles. (The cold-start
  path, for a brand-new account with no signal at all yet, still falls back
  to catalog-wide popular, since there's no "similar" to anchor to yet.)

Frontend: `content-api.ts` / `features/discovery/queries.ts` gained
`getBecauseYouWatched` / `useBecauseYouWatched`; `PlayerPage.tsx`'s related-
titles rail now just calls that instead of hand-rolling a genre-catalog +
recommendations blend.

## Recommendation rails — round 2, stricter matching

The first pass still let loosely-related titles through. Tightened further:

- **`similar_mood_videos`** ("More like this mood"): was OR (mood tag *or*
  genre tag). Now AND — a candidate must share at least one mood tag AND
  at least one genre tag with the playing title (the AND requirement only
  drops for whichever side, if any, the playing title has no data for).
- **`because_you_watched_videos`** ("Because you watched X" / "More Like
  This"): dropped the genre fallback entirely. This rail is now strictly
  same-director-or-shared-cast-member. If a title has no cast/director
  credits, or nothing else in the catalog shares one, the rail is empty
  (the frontend already hides it when empty) rather than showing
  genre-only matches that undermined the "because you watched this actor's
  film" framing.
- **`recommend_videos`** (home "Recommended for you"): added
  `mood_interest_scores` (same signal sources as genre — ratings + review
  sentiment, watchlist, watch history) alongside the existing genre
  affinity. Once a user has any mood signal, candidates must match a liked
  genre AND a liked mood, not genre alone — two titles can share a genre
  tag ("Drama") while being tonally nothing alike. Falls back to
  genre-only only if the combined AND filter comes up completely empty
  (sparse catalog safety valve), and still has no catalog-wide top-up.

## Watch page — combined player + title info, real-OTT style

Playback already lived on its own route (`/watch/:id`, distinct from the
`/title/:id` info page — `PosterCard`, `CollectionPage`, and the hero all
already sent "Play" to `/watch/:id` and clicking the poster itself to
`/title/:id`), but the watch page itself was thin: just the player, a
title, and a synopsis. On Netflix/Prime/Hotstar, the watch page carries
everything you'd want without leaving — cast, director, genres, your
rating, watchlist/download actions — not just the info page.

**`pages/PlayerPage.tsx`**: brought in the info-page content (genres,
director, cast, watchlist toggle, download toggle, report, star rating +
review) that previously only existed on `TitleDetailsPage`, laid out
alongside the "Playback shortcuts" card, above the "More like this mood"
and "Because you watched X" rails. Watching, rating, and deciding what to
watch next can now all happen on one page instead of bouncing back to
`/title/:id` mid-session.
